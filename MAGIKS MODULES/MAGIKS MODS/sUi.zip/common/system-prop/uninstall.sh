# © 2025 magiks Vexiro. All rights reserved.
# Version 3.6.0
#
# magiks Vexiro
# A lightweight utility app designed to enhance user experience through various system tweaks and optimizations.
#
# Developer: @traatweak
# Email: magiksvexiro@gmail.com
# Website: https://magiksvexiro.pages.dev
#
# This app is developed with a focus on efficiency, stability, and ease of use.
# All components and features are independently built to ensure maximum performance across devices.
#
# Copyright & License
# All contents within this app are protected by copyright laws.
# It is strictly prohibited to copy, modify, or redistribute this app, in whole or in part, without written permission from the developer.
# Violations will be prosecuted under applicable law.
#
# Disclaimer
# This application is provided "as is" without any warranty, express or implied.
# The user assumes full responsibility for the use of this application.
#
# Contact & Support
# For issues, suggestions, or contributions, feel free to contact us via email or visit our official website.
#
# Privacy Policy | Terms of Service
#versi1
setprop debug.composition.type gpu
setprop debug.hwui.renderer skiagl
setprop debug.renderengine.backend skiaglthreaded
setprop debug.sf.hw 1
setprop debug.egl.hw 1
setprop debug.sf.auto_latch_unsignaled 1
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1
setprop debug.mdpcomp.logs 1
setprop debug.hwui.render_thread true
setprop debug.skia.threaded_mode true
setprop debug.hwui.show_dirty_regions false
setprop debug.hwui.fps_divisor 1
setprop debug.hwui.use_hint_manager false
setprop debug.hwui.target_cpu_time_percent 0
setprop debug.hwui.skia_tracing_enabled false
setprop debug.hwui.skia_use_perfetto_track_events false
setprop debug.hwui.capture_skp_enabled false
setprop debug.hwui.trace_gpu_resources false
setprop debug.hwui.show_layers_updates false
setprop debug.hwui.skip_empty_damage true
setprop debug.hwui.use_buffer_age false
setprop debug.hwui.use_partial_updates false
setprop debug.hwui.use_gpu_pixel_buffers false
setprop debug.hwui.filter_test_overhead false
setprop debug.hwui.overdraw false
setprop debug.hwui.skp_filename false
setprop debug.hwui.level 0
setprop debug.hwui.clip_surfaceviews false
setprop debug.hwui.nv_profiling false
setprop debug.hwui.disable_draw_defer true
setprop debug.hwui.disable_draw_reorder true
setprop debug.hwui.app_memory_policy false
setprop  debug.hwui.renderer skiagl
setprop  debug.renderengine.backend skiaglthreaded
setprop  debug.skia.threaded_mode true
setprop  debug.skia.render_thread_priority true
setprop  debug.skia.num_render_threads 1
setprop  debug.hwui.render_thread true
setprop  debug.hwui.render_thread_count 1
setprop  debug.egl.hw 1
setprop  debug.egl.force_gpu 1
setprop  debug.egl.profiler 0
setprop  debug.egl.swapinterval 0
setprop  debug.graphics.default_frame_rate.disabled true
setprop  debug.sf.hw 1
setprop  debug.sf.auto_latch_unsignaled 1
setprop  debug.sf.disable_client_composition_cache 0
setprop  debug.sf.latch_unsignaled 1
setprop  debug.sf.disable_backpressure 1
setprop  debug.sf.enable_traces 0
setprop  debug.sf.use_phase_offsets_as_durations 1
setprop  debug.sf.enable_gl_backpressure 1
setprop  debug.sf.enable_hwc_vds 1
setprop  debug.sf.force_higher_fps 1
setprop  debug.sf.layer_caching_active_layer_timeout_ms 500
setprop  debug.sf.no_hw_vsync 1
setprop  debug.sf.vsync 0
setprop  debug.sf.vsync_phase_offset_ns 0
setprop  debug.sf.enable_adpf_cpu_hint true
setprop  debug.sf.enable_advanced_sf_phase_offset 1
setprop  debug.sf.showbackground 0
setprop  debug.sf.showcpu 0
setprop  debug.sf.showfps 0
setprop  debug.sf.showupdates 0
setprop  debug.sf.gpu_freq_indeks 7
setprop  debug.hwui.use_gpu_pixel_buffers 1
setprop  debug.hwui.use_hw_layers 1
setprop  debug.hwui.render_thread true
setprop  debug.hwui.optimized_texture_upload true
setprop  debug.hwui.app_memory_policy false
setprop  debug.hwui.level 2
setprop  debug.hwui.disable_vsync true
setprop  debug.hwui.show_dirty_regions false
setprop  debug.hwui.fps_divisor 1
setprop  debug.hwui.webview_overlays_enabled true
setprop  debug.hwui.use_hint_manager false
setprop  debug.hwui.target_cpu_time_percent 1
setprop  debug.hwui.skia_tracing_enabled false
setprop  debug.hwui.skia_use_perfetto_track_events false
setprop  debug.hwui.capture_skp_enabled false
setprop  debug.hwui.trace_gpu_resources false
setprop  debug.hwui.show_layers_updates false
setprop  debug.hwui.skip_empty_damage true
setprop  debug.hwui.use_buffer_age false
setprop  debug.hwui.use_partial_updates false
setprop  debug.hwui.filter_test_overhead false
setprop  debug.hwui.overdraw false
setprop  debug.hwui.skp_filename false
setprop  debug.hwui.clip_surfaceviews false
setprop  debug.hwui.nv_profiling false
setprop  debug.hwui.disable_draw_defer true
setprop  debug.hwui.disable_draw_reorder true
setprop  debug.hwui.8bit_hdr_headroom false
setprop  debug.performance.tuning 1
setprop  debug.qc.hardware true
setprop  debug.enable.wl_log 0
setprop  debug.cpurend.vsync false
setprop  debugtool.anrhistory 0
setprop  debug.mdpcomp.logs 0
setprop  debug.fps.divisor 1
setprop  debug.game.fps 1
setprop  debug.game.renderer 1
setprop  debug.qualcomm.perf_coex 0
setprop  debug.qualcomm.sns.daemon 0
setprop  debug.qualcomm.sns.libsensor 0
setprop  debug.qctwa.preservebuf 1
setprop  debug.qctwa.statusbar 1
setprop  debug.qsg.renderer 1
setprop  debug.hwc.force_gpu 1
setprop  debug.gr.swapinterval 0

for a in $(cmd package list packages | cut -f 2 -d ":" | grep -E 'systemui|^android$'); do
pm compile -m extract -f "$a" --primary-dex --include-dependencies
      pm compile -r vdex -f "$app" --primary-dex --include-dependencies
      pm compile -r bg-dexopt -f "$app" --secondary-dex --include-dependencies
      pm reconcile-secondary-dex-files -f "$a"
      pm compile --compile-layouts -f "$a"
      pm compile -m everything-profile -f "$a" --primary-dex --include-dependencies
      pm compile -m everything-profile -f "$a" --secondary-dex --include-dependencies
      pm compile -m everything-profile --check-prof false -f "$a" --primary-dex --include-dependencies
    done