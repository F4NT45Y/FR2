#!/system/bin/sh
# Frame Rate Extreme Mode - By ChatGPT

reresetprop debug.hwc.dynThreshold 6.0
resetprop debug.sf.frame_rate_multiple_threshold 60
resetprop debug.sf.high_fps_early_phase_offset_ns -99999999
resetprop debug.sf.high_fps_early_gl_phase_offset_ns -99999999
resetprop debug.sf.high_fps_late_app_phase_offset_ns -99999999
resetprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 0

echo "[✓] Performance Mode: EXTREME Activated!"

cmd notification post -S bigtext -t "Extreme Frame Rate Module has been successfully uninstall!"