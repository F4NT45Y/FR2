# © 2025 magiks Vexiro. All rights reserved.
# Version 3.6.0
#
# magiks Vexiro
# A lightweight utility app designed to enhance user experience through various system tweaks and optimizations.
#
# Developer: @traatweak
# Email: magiksvexiro@gmail.com
# Website: https://magiksvexiro.pages.dev
#
# This app is developed with a focus on efficiency, stability, and ease of use.
# All components and features are independently built to ensure maximum performance across devices.
#
# Copyright & License
# All contents within this app are protected by copyright laws.
# It is strictly prohibited to copy, modify, or redistribute this app, in whole or in part, without written permission from the developer.
# Violations will be prosecuted under applicable law.
#
# Disclaimer
# This application is provided "as is" without any warranty, express or implied.
# The user assumes full responsibility for the use of this application.
#
# Contact & Support
# For issues, suggestions, or contributions, feel free to contact us via email or visit our official website.
#
# Privacy Policy | Terms of Service
(
for sensor in cpu0 gpu0 npu0 apu0 dsp0 tpu0 vpu0 isp0 spu0 dpu0 pim0 skin pmic0 ddr0 ufs0 modem0 battery
do
    type=$(echo $sensor | tr a-z A-Z)
    cmd thermalservice inject-temperature $type light $sensor 120000
done
) > /dev/null 2>&1
(
    cmd power set-fixed-performance-mode-enabled true
    settings put system POWER_PERFORMANCE_MODE_OPEN 1
    cmd thermalservice override-status 0
    setprop debug.performance.tuning 1
    setprop debug.sf.perf_mode 1
    setprop debug.thermal.cpu_thermal_throttle.disable 1
    setprop debug.power.throttling.disable 1
    setprop persist.sys.gpu_perf_mode 1
    setprop sys.force_boost_cpu true
    setprop debug.thermal.shutdown.disable 1
    # spoof suhu
    cmd thermalservice inject-temperature CPU light cpu0 120.000
    cmd thermalservice inject-temperature GPU light gpu0 120.000
    setprop debug.gpu.thermal.temp 150
    settings put system battery.temp_high 90
    settings put global vendor.dfps.enable false
    settings put global vendor.smart_dfps.enable false
    settings put system virtual_thermal_thermal_zone false
    settings put global thermal_throttling 0
    settings put global thermal_pwrlevel 0
    #Disabled Thermal No Root (Gimick)
    setprop debug.init.svc.thermald stopped
    setprop debug.init.svc_debug_pid.vendor.thermal-hal-2-0.mtk stopped
    setprop debug.init.svc.thermal_manager stopped
    setprop debug.init.svc.thermal_mnt_hal_service stopped
    setprop debug.init.svc.thermal-engine stopped
    setprop debug.init.svc.vendor.thermal-hal-2-0.mtk stopped
    setprop debug.init.svc.thermal_core stopped
    setprop debug.ro.boottime.thermal_core stopped
    setprop debug.ro.boottime.vendor.thermal-hal-2-0.mtk stopped
    setprop debug.ro.vendor.mtk_thermal_2_0 stopped
    setprop debug.ro.boottime.thermal_core stopped
    setprop debug.ro.boottime.thermald stopped
    setprop debug.ro.boottime.vendor.thermal-hal-2-0.mtk stopped
    setprop debug.ro.vendor.mtk_thermal_2_0 stopped
    #Ultra Gaming Thermal Tuning (Non Root)
settings put system bench_mark_mode 0
setprop debug.thermal_status 0
setprop debug.performance.tuning 3
setprop debug.thermal.cpu_thermal_throttle.disable 1
setprop debug.thermal.ambient_sensor.disable 1
setprop debug.cooling_name_thermal-devfreq 0
setprop debug.pid.sec-thermal-1-0 disabled
setprop debug.thermal_zone.display_hotplug_control 0
setprop debug.thermal_zone.battery_hotplug_control 0
setprop debug.mediatek.appgamepq_compress 0
setprop debug.mediatek.disp_decompress 2
setprop debug.mtk_tflite.target_nnapi 31
setprop debug.thermal_zone.gpu_threshold_temp 95
setprop debug.thermal_zone.cpu_threshold_temp 90
setprop debug.thermal_zone.display_threshold_temp 85
setprop debug.thermal_zone.camera_hotplug_control 0
setprop debug.thermal_zone.battery_threshold_temp 75
setprop debug.thermal_zone.camera_threshold_temp 90
setprop debug.thermal_zone.cpu_hotplug_control 0
setprop debug.thermal_zone.gpu_hotplug_control 0
setprop debug.power.throttling.disable 1
setprop debug.thermal.gpu_shader_clock_throttle.disable 1
setprop debug.thermal.gpu_core_clock_throttle.disable 1
setprop debug.thermal.gpu_power_throttle.disable 1
setprop debug.thermal.gpu_thermal_throttle.disable 1
setprop debug.thermal.gpu_memory_throttle.disable 1
setprop debug.thermal.gpu_fan_control.disable 1
setprop debug.thermal.gpu_boost.disable 0
setprop debug.thermal.gpu_control.disable 1
setprop debug.thermal.gpu_throttle.disabled 1
setprop debug.thermal.backlight.disabled 1
setprop debug.thermal.boost.disabled 0
setprop debug.thermal.inactive_delay.disabled 1
setprop debug.thermal.throttling.disable 1
setprop debug.thermal.profile.disable 1
setprop debug.thermal.throttle_ratio.disable 1
setprop debug.thermal.turbo_ratio_limit.disable 1
setprop debug.thermal.cooling_device_state.disable 1
setprop debug.thermal.dynamic_scheduling.disable 1
setprop debug.thermal.critical_temp.disable 1
setprop debug.thermal.threshold.disable 1
setprop debug.thermal.overheat_protection.disable 1
setprop debug.thermal.alert.disable 1
setprop debug.thermal.fan.disable 1
setprop debug.thermal.shutdown.disable 1
setprop debug.thermal.balance_algorithm -1
setprop debug.thermal.performance_mode.disable 1
setprop debug.thermal.force_fan_on.disable 0
setprop debug.thermal.critical_trip_point.disable 1
setprop debug.thermal.auto_thermal_disable 1
setprop debug.thermal.zone.disabled 1
setprop debug.thermal.trip_point.disabled 1
setprop debug.thermal.suspend.disabled 1
setprop debug.thermal.thermal_policy.disable 1
setprop debug.thermal.fan_disable 1
#Peformance Stability
setprop debug.performance.tuning 1 
setprop debug.egl.force_msaa false
setprop debug.hwui.use_gpu_pixel_buffers 1
setprop debug.hwui.target_cpu_time_percent 10
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.disable_vsync true
setprop debug.hwui.level 0
setprop debug.kill_allocating_task 0
setprop debug.gralloc.gfx_ubwc_disable 0
setprop debug.rs.default-CPU-driver 1
setprop debug.rs.forcecompat 1
setprop debug.rs.max-threads 8
setprop debug.choreographer.skipwarning 30
setprop debug.choreographer.frametime false
setprop debug.display.allow_non_native_refresh_rate_override 1
setprop debug.display.render_frame_rate_is_physical_refresh_rate 1
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.enable_transaction_tracing false
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.gpu_freq_indeks 7
setprop debug.sf.use_frame_rate_priority 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_gl_backpressure 1
setprop debug.atrace.tags.enableflags 0
setprop debug.cpurend.vsync false
setprop debug.composition.type gpu
setprop debug.checkjni 0
setprop debug.atrace.tags.enableflags 0
setprop debug.gr.numframebuffers 3
) > /dev/null 2>&1
(
#Thermal Unlock
setprop debug.sys.thermal.level 0
setprop debug.sys.thermal.protection 0
setprop debug.sys.thermal.enable_detailed 0
) > /dev/null 2>&1