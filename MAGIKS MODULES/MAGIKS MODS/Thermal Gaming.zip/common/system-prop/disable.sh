# © 2025 magiks Vexiro. All rights reserved.
# Version 3.6.0
#
# magiks Vexiro
# A lightweight utility app designed to enhance user experience through various system tweaks and optimizations.
#
# Developer: @traatweak
# Email: magiksvexiro@gmail.com
# Website: https://magiksvexiro.pages.dev
#
# This app is developed with a focus on efficiency, stability, and ease of use.
# All components and features are independently built to ensure maximum performance across devices.
#
# Copyright & License
# All contents within this app are protected by copyright laws.
# It is strictly prohibited to copy, modify, or redistribute this app, in whole or in part, without written permission from the developer.
# Violations will be prosecuted under applicable law.
#
# Disclaimer
# This application is provided "as is" without any warranty, express or implied.
# The user assumes full responsibility for the use of this application.
#
# Contact & Support
# For issues, suggestions, or contributions, feel free to contact us via email or visit our official website.
#
# Privacy Policy | Terms of Service
#versi1
(
   cmd thermalservice reset
   cmd power set-fixed-performance-mode-enabled false
   settings put system POWER_PERFORMANCE_MODE_OPEN 0
   settings delete system POWER_PERFORMANCE_MODE_OPEN
   settings delete system battery.temp_high
   settings delete system bench_mark_mode
   settings delete system virtual_thermal_thermal_zone
   settings delete global vendor.dfps.enable
   settings delete global vendor.smart_dfps.enable
   settings delete global thermal_throttling
   settings delete global thermal_pwrlevel
) > /dev/null 2>&1
(
#Disabled Thermal No Root (Gimick)
    setprop debug.init.svc.thermald ""
    setprop debug.init.svc_debug_pid.vendor.thermal-hal-2-0.mtk ""
    setprop debug.init.svc.thermal_manager ""
    setprop debug.init.svc.thermal_mnt_hal_service ""
    setprop debug.init.svc.thermal-engine ""
    setprop debug.init.svc.vendor.thermal-hal-2-0.mtk ""
    setprop debug.init.svc.thermal_core ""
    setprop debug.ro.boottime.thermal_core stopped
    setprop debug.ro.boottime.vendor.thermal-hal-2-0.mtk ""
    setprop debug.ro.vendor.mtk_thermal_2_0 ""
    setprop debug.ro.boottime.thermal_core ""
    setprop debug.ro.boottime.thermald stopped
    setprop debug.ro.boottime.vendor.thermal-hal-2-0.mtk ""
    setprop debug.ro.vendor.mtk_thermal_2_0 ""
    #Ultra Gaming Thermal Tuning (Non Root)
settings put system bench_mark_mode ""
setprop debug.thermal_status ""
setprop debug.performance.tuning ""
setprop debug.thermal.cpu_thermal_throttle.disable ""
setprop debug.thermal.ambient_sensor.disable ""
setprop debug.cooling_name_thermal-devfreq ""
setprop debug.pid.sec-thermal-1-0 ""
setprop debug.thermal_zone.display_hotplug_control 
setprop debug.thermal_zone.battery_hotplug_control
setprop debug.mediatek.appgamepq_compress ""
setprop debug.mediatek.disp_decompress ""
setprop debug.mtk_tflite.target_nnapi ""
setprop debug.thermal_zone.gpu_threshold_temp ""
setprop debug.thermal_zone.cpu_threshold_temp ""
setprop debug.thermal_zone.display_threshold_temp ""
setprop debug.thermal_zone.camera_hotplug_control ""
setprop debug.thermal_zone.battery_threshold_temp ""
setprop debug.thermal_zone.camera_threshold_temp ""
setprop debug.thermal_zone.cpu_hotplug_control ""
setprop debug.thermal_zone.gpu_hotplug_control ""
setprop debug.power.throttling.disable ""
setprop debug.thermal.gpu_shader_clock_throttle.disable ""
setprop debug.thermal.gpu_core_clock_throttle.disable ""
setprop debug.thermal.gpu_power_throttle.disable ""
setprop debug.thermal.gpu_thermal_throttle.disable ""
setprop debug.thermal.gpu_memory_throttle.disable ""
setprop debug.thermal.gpu_fan_control.disable ""
setprop debug.thermal.gpu_boost.disable ""
setprop debug.thermal.gpu_control.disable ""
setprop debug.thermal.gpu_throttle.disabled ""
setprop debug.thermal.backlight.disabled ""
setprop debug.thermal.boost.disabled ""
setprop debug.thermal.inactive_delay.disabled ""
setprop debug.thermal.throttling.disable ""
setprop debug.thermal.profile.disable ""
setprop debug.thermal.throttle_ratio.disable ""
setprop debug.thermal.turbo_ratio_limit.disable ""
setprop debug.thermal.cooling_device_state.disable ""
setprop debug.thermal.dynamic_scheduling.disable ""
setprop debug.thermal.critical_temp.disable ""
setprop debug.thermal.threshold.disable ""
setprop debug.thermal.overheat_protection.disable ""
setprop debug.thermal.alert.disable ""
setprop debug.thermal.fan.disable ""
setprop debug.thermal.shutdown.disable ""
setprop debug.thermal.balance_algorithm ""
setprop debug.thermal.performance_mode.disable ""
setprop debug.thermal.force_fan_on.disable ""
setprop debug.thermal.critical_trip_point.disable ""
setprop debug.thermal.auto_thermal_disable ""
setprop debug.thermal.zone.disabled ""
setprop debug.thermal.trip_point.disabled ""
setprop debug.thermal.suspend.disabled ""
setprop debug.thermal.thermal_policy.disable ""
setprop debug.thermal.fan_disable ""
#Peformance Stability
setprop debug.performance.tuning ""
setprop debug.egl.force_msaa ""
setprop debug.hwui.use_gpu_pixel_buffers ""
setprop debug.hwui.target_cpu_time_percent ""
setprop debug.hwui.render_dirty_regions ""
setprop debug.hwui.disable_vsync ""
setprop debug.hwui.level ""
setprop debug.kill_allocating_task ""
setprop debug.gralloc.gfx_ubwc_disable ""
setprop debug.rs.default-CPU-driver ""
setprop debug.rs.forcecompat ""
setprop debug.rs.max-threads ""
setprop debug.choreographer.skipwarning ""
setprop debug.choreographer.frametime ""
setprop debug.display.allow_non_native_refresh_rate_override ""
setprop debug.display.render_frame_rate_is_physical_refresh_rate ""
setprop debug.sf.use_phase_offsets_as_durations ""
setprop debug.sf.predict_hwc_composition_strategy ""
setprop debug.sf.enable_transaction_tracing ""
setprop debug.sf.disable_client_composition_cache ""
setprop debug.sf.gpu_freq_indeks ""
setprop debug.sf.use_frame_rate_priority ""
setprop debug.sf.disable_backpressure ""
setprop debug.sf.enable_gl_backpressure ""
setprop debug.atrace.tags.enableflags ""
setprop debug.cpurend.vsync ""
setprop debug.composition.type ""
setprop debug.checkjni ""
setprop debug.atrace.tags.enableflags ""
setprop debug.gr.numframebuffers ""
) > /dev/null 2>&1
(
#Thermal Unlock
setprop debug.sys.thermal.level ""
setprop debug.sys.thermal.protection ""
setprop debug.sys.thermal.enable_detailed ""
) > /dev/null 2>&1