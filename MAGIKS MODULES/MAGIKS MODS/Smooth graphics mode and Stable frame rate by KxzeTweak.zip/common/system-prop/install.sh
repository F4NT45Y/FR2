#kaze

#!/system/bin/sh

# Mode Game
setprop persist.game.mode 1

# Grafik halus
setprop persist.graphics.smooth_mode 1
setprop persist.graphics.performance_boost 1
setprop persist.graphics.low_latency 1

# Rendering halus
setprop debug.hwui.renderer skiagl
setprop debug.hwui.use_vulkan true
setprop debug.sf.enable_hwc_vds true

# Atur FPS (ubah jika layar mendukung 90Hz/120Hz)
setprop persist.sys.fps 120
setprop vendor.display.fps.switch 1

# Sinkronisasi vsync & refresh rate adaptif
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_gl_backpressure 1

# Output UBWC status for verification
getprop | grep ubwc
getprop | grep alloc

# Notifikasi Sukses
cmd notification post -S bigtext -t 'Enjoy your device'