# Changelog

Moltengl+dyn 120 fps is a graphics setting that includes 
special graphic effects (Moltengl and Dyn) with a high frame 
rate (120 fps) to produce a smooth and responsive visual 
experience in games or applications