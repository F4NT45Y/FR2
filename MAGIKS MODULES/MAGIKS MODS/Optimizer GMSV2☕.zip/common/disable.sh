#!/system/bin/sh

cmd appops reset com.google.android.gms