#!/system/bin/sh

cmd appops set com.google.android.gms RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.gms RUN_ANY_IN_BACKGROUND ignore
cmd appops set com.google.android.gms START_FOREGROUND ignore
cmd appops set com.google.android.googlequicksearchbox RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.googlequicksearchbox RUN_ANY_IN_BACKGROUND ignore
cmd appops set com.google.android.googlequicksearchbox START_FOREGROUND ignore