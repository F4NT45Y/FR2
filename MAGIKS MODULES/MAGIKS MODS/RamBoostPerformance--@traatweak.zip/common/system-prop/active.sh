# Game Booster
cmd device_confg get game_overlay "$app"
cmd thermalservice override-status 0 > /dev/null 2>&1
cmd power set-fixed-performance-mode-enabled 1 > /dev/null 2>&1
cmd power set-adaptive-power-saver-enabled 0 > /dev/null 2>&1
cmd power set-mode 0 > /dev/null 2>&1
cmd shortcut reset-throttling "$app" > /dev/null 2>&1
cmd shortcut reset-all-throttling "$app" > /dev/null 2>&1

# Remove cache and logs
rm -rf /storage/emulated/0/android/data/"$app"/cache > /dev/null 2>&1
rm -rf /data/dalvik-cache/* > /dev/null 2>&1
rm -rf /data/system/usagestats/* > /dev/null 2>&1
rm -rf /data/system/cache/* > /dev/null 2>&1
rm -rf /data/system/log/* > /dev/null 2>&1

# Trim caches
cmd package trim-caches 999G $UUID "$app" > /dev/null 2>&1
pm trim-caches 999G $UUID "$app" > /dev/null 2>&1

# Stop and kill app
cmd activity force-stop --user $USER_ID "$app" > /dev/null 2>&1
cmd activity kill --user $USER_ID "$app" > /dev/null 2>&1
cmd activity stop-app --user $USER_ID "$app" > /dev/null 2>&1
cmd activity kill-all --user $USER_ID "$app" > /dev/null 2>&1
am force-stop --user $USER_ID "$app" > /dev/null 2>&1
am kill --user $USER_ID "$app" > /dev/null 2>&1
am stop-app --user $USER_ID "$app" > /dev/null 2>&1
am kill-all --user $USER_ID "$app" > /dev/null 2>&1

# Sync
sync > /dev/null 2>&1

# Check for errors and run backup tweak if needed
if [[ $? -ne 0 ]]; then
    # Backup Tweak
    cmd thermalservice override-status 0 > /dev/null 2>&1
    cmd power set-fixed-performance-mode-enabled 1 > /dev/null 2>&1
    cmd power set-adaptive-power-saver-enabled 0 > /dev/null 2>&1
    cmd power set-mode 0 > /dev/null 2>&1
    cmd shortcut reset-throttling "$app" > /dev/null 2>&1
    cmd shortcut reset-all-throttling "$app" > /dev/null 2>&1
    
    # Remove cache and logs
    rm -rf /storage/emulated/0/android/data/"$app"/cache > /dev/null 2>&1
    rm -rf /data/dalvik-cache/* > /dev/null 2>&1
    rm -rf /data/system/usagestats/* > /dev/null 2>&1
    rm -rf /data/system/cache/* > /dev/null 2>&1
    rm -rf /data/system/log/* > /dev/null 2>&1

    # Trim caches
    cmd package trim-caches 999G "$app" > /dev/null 2>&1
    pm trim-caches 999G "$app" > /dev/null 2>&1

    # Stop and kill app for backup user
    cmd activity force-stop --user 2000 "$app" > /dev/null 2>&1
    cmd activity kill --user 2000 "$app" > /dev/null 2>&1
    cmd activity stop-app --user 2000 "$app" > /dev/null 2>&1
    cmd activity kill-all --user 2000 "$app" > /dev/null 2>&1
    am force-stop --user 2000 "$app" > /dev/null 2>&1
    am kill --user 2000 "$app" > /dev/null 2>&1
    am stop-app --user 2000 "$app" > /dev/null 2>&1
    am kill-all --user 2000 "$app" > /dev/null 2>&1
fi