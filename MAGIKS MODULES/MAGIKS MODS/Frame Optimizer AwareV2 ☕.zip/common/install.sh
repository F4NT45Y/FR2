#!/system/bin/sh
# Frame Rate Extreme Mode - By ChatGPT

# mempercepat pemerosesan lapisan gpu
setprop debug.hwc.dynThreshold 1.0
setprop debug.sf.frame_rate_multiple_threshold 999

# Phase offset untuk sinkronisasi super cepat
setprop debug.sf.early_phase_offset_ns -9999999999
setprop debug.sf.early_app_phase_offset_ns -9999999999
setprop debug.sf.early_gl_phase_offset_ns -9999999999
setprop debug.sf.early_gl_app_phase_offset_ns -9999999999
setprop debug.sf.high_fps_early_phase_offset_ns -9999999999
setprop debug.sf.high_fps_early_gl_phase_offset_ns -9999999999
setprop debug.sf.high_fps_late_app_phase_offset_ns -9999999999

# Nonaktifkan pembagi FPS, paksa maksimal
setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.use_phase_offsets_as_durations 1

# RenderEngine paksa ke GL langsung, tidak Vulkan lambat
setprop debug.renderengine.backend skiagl
setprop debug.hwui.renderer opengl
setprop debug.hwui.use_vulkan false

# Optimizasi HWUI
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.disable_scissor_opt true
setprop debug.hwui.force_dark false
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 0

echo "[✓] Game Mode: EXTREME Activated!"


cmd notification post -S bigtext -t 'SUCCESS🔥' 'Tag' "Module active ⚡