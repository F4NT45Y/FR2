#magiks Vexiro 
#UNIVERSAL GAMING PERF is a tweak or modification 
#designed to enhance performance and gaming experience on 
#Android devices Its purpose is to optimize system settings, 
#increase frame rates, and reduce lag or other issues, 
#providing a smoother and more responsive gaming experience

settings put global gaming_network_constants "low_latency_mode=true, max_network_retries=3, net_reconnect_timeout=5000, disable_auto_network_switch=true, network_bandwidth_optimize=true, enable_5g_network=true, disable_background_data=false, enable_data_compression=true, disable_network_throttling=false, use_high_priority_network=true" > /dev/null 2>&1
# Gaming Performance
settings put global cpu_gpu_constants "cpu_boost_threshold=100, gpu_boost_threshold=100, cpu_max_freq=3000000, gpu_max_freq=1000000000, cpu_min_freq=300000, gpu_min_freq=300000000, cpu_affinity=0,1,2,3,4,5,6,7, gpu_affinity=0,1,2,3" > /dev/null 2>&1

service call SurfaceFlinger 1035 i32 0 > /dev/null 2>&1
android_properties() {
# Vsync & Interval
setprop debug.hwui.disable_vsync true
setprop debug.cpurend.vsync false
setprop debug.gpurend.vsync false
setprop debug.hwui.force_no_vsync true
setprop debug.hwui.skip_vsync true
setprop debug.hwc.fakevsync 0
setprop debug.hwc.logvsync 0
setprop debug.hwc.force_gpu_vsync false
setprop debug.sf.phase_offset_threshold_ns 0
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 0
setprop debug.sf.hwc_hotplug_error_via_neg_vsync 0
setprop debug.sf.hwc_hdcp_via_neg_vsync 0
setprop debug.sf.no_hw_vsync 1
setprop debug.sf.vsync_reactor false
setprop debug.sf.vsync_reactor_ignore_present_fences 0
setprop debug.sf.show_predicted_vsync false
setprop persist.sys.vsync_optimization_enable false
setprop persist.sys.hwui.dyn_vsync 0
setprop persist.sys.vsync false
setprop debug.egl.swapinterval 0
setprop debug.gr.swapinterval 0
setprop debug.sf.swapinterval 0
setprop debug.oculus.swapInterval 0
setprop debug.gr.numframebuffers 3
setprop debug.sf.numframebuffers 3
setprop persist.sys.egl.swapinterval 0
setprop persist.sys.gr.swapinterval 0
setprop persist.sys.sf.swapinterval 0
}
android_properties > /dev/null 2>&1

android_properties() {
# Menghindari overhead proses gabungan jika tidak diperlukan
setprop debug.renderer.process_compound false

# Graphite meningkatkan pipeline rendering baru di Skia
setprop debug.renderengine.graphite true

# Nonaktifkan capture Skia untuk mengurangi overhead
setprop debug.renderengine.capture_skia_ms 0

# Nonaktifkan capture filename untuk debug
setprop debug.renderengine.capture_filename 0

# Nonaktifkan Perfetto tracking untuk performa lebih baik
setprop debug.renderengine.skia_use_perfetto_track_events false

# Nonaktifkan tracing untuk mengurangi beban sistem
setprop debug.renderengine.skia_tracing_enabled false

# Gunakan Skiagl untuk stabilitas
setprop debug.renderengine.backend skiaglthreaded

# Membagi tugas operasi secara agresif
setprop debug.renderthread.skia.reduceopstasksplitting true

# Mengaktifkan mode rendering multi-threaded untuk meningkatkan kinerja
setprop debug.skia.threaded_mode true

# Menentukan jumlah thread rendering (sesuaikan dengan jumlah big cores CPU)
setprop debug.skia.num_render_threads 4

# Meningkatkan prioritas thread rendering untuk responsivitas yang lebih baik
setprop debug.skia.render_thread_priority true

# Menggunakan Opengl sebagai backend rendering untuk ANGLE, meningkatkan performa jika perangkat mendukung Metal.
setprop debug.angle.backend opengl

# Menonaktifkan Overlay
setprop debug.angle.overlay ""

# Optimasi Composition Performa Rendering.
setprop debug.angle.feature_overrides_enabled disableFlipping:forceDirectComposition

# Menentukan aturan kustom untuk ANGLE berdasarkan file JSON, memungkinkan optimasi tambahan sesuai perangkat atau aplikasi.
setprop debug.angle.rules /data/local/tmp/a4a_rules.json

# Membagi tugas operasi secara agresif
setprop renderthread.skia.reduceopstasksplitting true
}
android_properties > /dev/null 2>&1

# Cek chipset berdasarkan Build.BRAND
BRAND=$(getprop ro.product.brand)

if [[ "$BRAND" == *"MTK"* || "$BRAND" == *"Mediatek"* ]]; then
    android_properties=(
        "debug.mediatek.performance_mode 1"
        "debug.mediatek.cpu_boost 1"
        "debug.mediatek.scheduler_optimize 1"
        "debug.mediatek.big_core_turbo 1"
        "debug.mediatek.small_core_efficiency 1"
        "debug.mediatek.thermal_control 0"
        "debug.mediatek.fast_charging 1"
        "debug.mediatek.memory_optimization 1"
        "debug.mediatek.io_boost 1"
        "debug.mediatek.task_limit 0"
        "debug.mediatek.composition.type gpu"
        "debug.mediatek.composition_type gpu"
        "debug.mediatek.appgamepq_compress true"
        "debug.mediatek.disp_decompress true"
        "debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 120"
        "debug.mtk_tflite.target_nnapi 29"
        "debug.mtk.performancemode true"
        "debug.mtk.dynfps.enable false"
        "debug.mediatek.dyn.mf_enable false"
        "debug.mediatek.game_mode.enable true"
        "debug.mediatek.game_mode.optimization true"
        "debug.mediatek.gpu_boost true"
        "debug.mediatek.wifiboost.enable true"
        "debug.mediatek.cpu_scaling true"
        "debug.mediatek.gpu_render_mode performance"
        "debug.mtk.qos.enable true"
    )

elif [[ "$BRAND" == *"QTI"* || "$BRAND" == *"Qualcomm"* ]]; then
    android_properties=(
        "debug.qc.performance_mode 1"
        "debug.qc.cpu_boost 1"
        "debug.qc.scheduler_optimize 1"
        "debug.qc.big_core_turbo 1"
        "debug.qc.small_core_efficiency 1"
        "debug.qc.thermal_control 0"
        "debug.qc.fast_charging 1"
        "debug.qc.memory_optimization 1"
        "debug.qc.io_boost 1"
        "debug.qc.task_limit 0"
    )

elif [[ "$BRAND" == *"Samsung"* ]]; then
    android_properties=(
        "debug.exynos.boost 1"
        "debug.exynos.performance_mode 1"
        "debug.exynos.scheduler_optimize 1"
        "debug.exynos.cpu_limiter 0"
        "debug.exynos.big_core_boost 1"
        "debug.exynos.small_core_efficiency 1"
        "debug.exynos.thermal_control 0"
        "debug.exynos.fast_charging 1"
        "debug.exynos.memory_tuning 1"
        "debug.exynos.background_task_limit 0"
    )

else
    android_properties=(
        "debug.generic.performance_mode 1"
        "debug.generic.cpu_boost 1"
        "debug.generic.scheduler_optimize 1"
        "debug.generic.big_core_turbo 1"
        "debug.generic.small_core_efficiency 1"
        "debug.generic.thermal_control 0"
        "debug.generic.fast_charging 1"
        "debug.generic.memory_optimization 1"
        "debug.generic.io_boost 1"
        "debug.generic.task_limit 0"
    )
fi

# Terapkan tweak yang sesuai
for prop in "${android_properties[@]}"; do
    setprop $prop > /dev/null 2>&1
done

(
# Lock Fps
settings put system user_refresh_rate 120
settings put system fps_limit 120
settings put system max_refresh_rate_for_ui 120
settings put system hwui_refresh_rate 120
settings put system display_refresh_rate 120
settings put system max_refresh_rate_for_gaming 120
settings put system fstb_target_fps_margin_high_fps 20
settings put system fstb_target_fps_margin_low_fps 20
settings put system gcc_fps_margin 10
settings put global tran_low_battery_60hz_refresh_rate.support 0
settings put display.refresh_rate 120
settings put system sf.refresh_rate 120
setprop persist.vendor.display.refresh_rate 120
settings put system user_refresh_rate 120
settings put secure user_refresh_rate 120
settings put secure miui_refresh_rate 120
settings put system min_frame_rate 120
settings put system max_frame_rate 120
settings put system tran_refresh_mode 120
settings put system last_tran_refresh_mode_in_refresh_setting 120
settings put global min_fps 120
settings put global max_fps 120
settings put system tran_need_recovery_refresh_mode 120
settings put system display_min_refresh_rate 120
settings put system min_refresh_rate 120
settings put system max_refresh_rate 120
settings put system peak_refresh_rate 120
settings put secure refresh_rate_mode 120
settings put system user_refresh_rate 120
settings put system thermal_limit_refresh_rate 120
settings put system NV_FPSLIMIT 120
settings put system fps.limit.is.now locked
) > /dev/null 2>&1 &

{
# ==========================
# Optimalisasi CPU & GPU
# ==========================
setprop debug.performance.tuning 1
setprop debug.sf.hw 1
setprop debug.egl.hw 1
setprop debug.gralloc.enable_fb_ubwc 1
setprop debug.hwui.renderer opengl
setprop debug.sf.disable_backpressure 1
setprop persist.sys.NV_FPSLIMIT 0
setprop persist.sys.force_highend_gpu 1
setprop persist.sys.force_fast_cpu 1
setprop persist.sys.performance_mode 1
settings put global game_mode_on 1
settings put global sustained_performance_mode 1
settings put global oneplus_fan_enabled 1

# ==========================
# Nonaktifkan MSAA & FXAA (Disable Anti-Aliasing)
# ==========================
setprop debug.egl.force_msaa 0
setprop debug.egl.force_fxaa 0
setprop debug.egl.disable_msaa true
setprop debug.egl.disable_fxaa true
setprop debug.hwui.msaa 0
setprop debug.hwui.fxaa 0
setprop persist.sys.disable_msaa 1
setprop persist.sys.disable_fxaa 1

# ==========================
# Optimalisasi RAM & Background Process
# ==========================
settings put global activity_manager_constants max_cached_processes=6
settings put global app_ops_constants max_num_cached_background_processes=4
settings put global background_process_limit 4
setprop persist.sys.purgeable_assets 1
setprop persist.sys.trim_cache 1
setprop ro.config.max_starting_bg 3
setprop ro.sys.fw.bg_apps_limit 5
setprop persist.sys.fw.use_trim_settings true
setprop ro.lmk.kill_heaviest_task true
setprop ro.lmk.use_new_strategy true
setprop ro.lmk.boost_prio 1

# ==========================
# Mencegah Thermal Throttling & Tetap Dingin
# ==========================
setprop persist.sys.NV_THERMAL 0
setprop persist.sys.disable_thermal_engine 1
setprop persist.sys.thermal.danger_level 75
setprop persist.sys.thermal.critical_level 85
setprop persist.vendor.thermal.engine true
settings put global thermal_event_screen_off true
settings put global thermal_event_performance_mode high
settings put system power_mode_performance true
setprop persist.sys.cooling.device 1
setprop persist.sys.cooling.thermal 1
setprop persist.sys.cooling.system true
setprop persist.sys.cooling.game_boost true
setprop persist.vendor.enable_cooling 1
setprop persist.sys.thermal_policy aggressive

# ==========================
# Mengurangi Latensi Input & Lag
# ==========================
setprop persist.sys.input.delay 0
setprop touch.size.calibration geometric
setprop touch.size.scale 1.2
setprop persist.sys.game.touch_boost 1
setprop ro.input.resample 1
setprop ro.input.resample_distance 1
setprop ro.input.filter 1
setprop persist.vendor.touch_boost 1
settings put global pointer_speed 2

# ==========================
# Clear RAM Cache & Buffers Secara Otomatis
# ==========================
echo 3 > /proc/sys/vm/drop_caches
echo 1 > /proc/sys/vm/compact_memory
setprop persist.sys.trim_empty_mem true
setprop persist.sys.trim_cache true
setprop persist.sys.zygote.keep_warm true

# ==========================
# Meningkatkan Stabilitas & Mengurangi Lag & Stutter
# ==========================
setprop persist.sys.scrollingcache 0
setprop persist.sys.ui.hw true
setprop persist.sys.strictmode.disable true
setprop persist.sys.powersave.disabled 1
setprop persist.sys.fw.bservice_enable 1
setprop persist.sys.fw.bservice_limit 8
setprop persist.sys.fw.bservice_age 5000
setprop persist.sys.use_dithering 1
settings put global disable_configstore 1
settings put global disable_background_apps 1
} > /dev/null 2>&1

# Daftar package game
game_packages="com.dts.freefiremax
com.dts.freefireth
com.dts.freefireadv
com.garena.game.lmjx
com.garena.game.codm
com.garena.game.kgid
com.garena.game.kgtw
com.garena.game.kgvn
com.RoamingStar.BlueArchive
com.HoYoverse.hkrpgoversea
com.miHoYo.GenshinImpact
com.miHoYo.Yuanshen
com.miHoYo.bh3
com.miHoYo.bh3global
com.miHoYo.bh3oversea
com.miHoYo.bh3oversea_vn
com.miHoYo.enterprise.NGHSoD
com.miHoYo.hkrpg
com.miHoYo.ys
com.HoYoverse.Nap
com.mojang.hostilegg
com.mojang.minecraftpe
com.mojang.minecraftpe.patch
com.nexon.bluearchive
com.nexon.kartdrift
com.tencent.ig
com.tencent.KiHan
com.tencent.jkchess
com.tencent.lolm
com.tencent.mf.uam
com.tencent.tmgp.WePop
com.tencent.tmgp.bh3
com.tencent.tmgp.cf
com.tencent.tmgp.cod
com.tencent.tmgp.dfjs
com.tencent.tmgp.ffom
com.tencent.tmgp.gnyx
com.tencent.tmgp.kr.codm
com.tencent.tmgp.pubgmhd
com.tencent.tmgp.sgame
com.tencent.tmgp.speedmobile
com.tencent.tmgp.wuxia
com.tencent.tmgp.yys.zqb
com.tencent.toaa
com.xd.rotaeno.googleplay
com.xd.rotaeno.tapcn
com.vng.mlbbvn
com.vng.pubgmobile
com.vng.speedvn
com.nebulajoy.act.dmcpoc
com.nebulajoy.act.dmcpoc.asia
com.pubg.imobile
com.pubg.krmobile
com.pubg.newstate
com.netease.AVALON
com.netease.EVE
com.netease.aceracer
com.netease.dfjs
com.netease.dwrg
com.netease.eve.en
com.netease.frxyna
com.netease.race
com.netease.onmyoji
com.netease.yhtj
com.gameloft.android.ANMP.GloftA9HM
com.gameloft.android.ANMP.GloftMVHM
com.Sunborn.SnqxExilium
com.YoStar.AetherGazer
com.YoStarEN.Arknights
com.YoStarEN.MahjongSoul
com.YoStarJP.MajSoul
com.YostarJP.BlueArchive
com.roblox.client
com.rockstargames.gtasa
com.mobile.legends
com.mobilelegends.hwag
com.mobilelegends.mi
com.nekki.shadowfight
com.nekki.shadowfight3
com.levelinfinite.hotta.gp
com.levelinfinite.sgameGlobal
com.levelinfinite.sgameGlobal.midaspay
com.jacksparrow.jpmajiang
com.je.supersus
com.riotgames.league.teamfighttactics
com.riotgames.league.teamfighttacticsvn
com.riotgames.league.wildrift
com.ondi.shadowslayer
com.mojang.minecraftpe.mbl2
com.mojang.minecraftpe"

# Variabel untuk menyimpan package yang terinstal
installed_packages=""

# Loop untuk mengecek package yang terinstal
for pkg in $game_packages; do
    if pm list packages | grep -q "$pkg"; then
        installed_packages="$installed_packages $pkg"
    fi
done

# Jika ada game yang terinstal, jalankan tweak
if [ -n "$installed_packages" ]; then
    for pkg in $installed_packages; do
        device_config put game_overlay $pkg mode=2,downscaleFactor=0.9,fps=120:mode=3,downscaleFactor=0.9,fps=120
    done
fi

{
# Mematikan fitur yang mengganggu performa
settings put global auto_sync 0
settings put global ble_scan_always_enabled 0
settings put global wifi_scan_always_enabled 0
settings put global hotword_detection_enabled 0
settings put global activity_starts_logging_enabled 0
settings put global network_recommendations_enabled 0
settings put secure adaptive_sleep 0
settings put secure screensaver_enabled 0
settings put secure send_action_app_error 0
settings put system motion_engine 0
settings put system master_motion 0
settings put system air_motion_engine 0
settings put system air_motion_wake_up 0
settings put system send_security_reports 0
settings put system intelligent_sleep_mode 0
settings put system nearby_scanning_enabled 0
settings put system nearby_scanning_permission_allowed 0
setprop debug.sf.high_fps_early_gl_phase_offset_ns 8900000
setprop debug.sf.high_fps_early_phase_offset_ns 7500000
setprop debug.sf.high_fps_early_phase_offset_ns 6100000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 9000000
} > /dev/null 2>&1

#Unlock Peforma Maximal
(
setprop debug.performance.tuning 1
cmd thermalservice override-status 0
cmd power set-fixed-performance-mode-enabled true
cmd power set-adaptive-power-saver-enabled false
cmd power set-mode 0
cmd device_config put thermal high_temp_limit 150
cmd device_config put thermal low_temp_limit 150
cmd shortcut reset-throttling
cmd shortcut reset-all-throttling
) > /dev/null 2>&1 &

android_properties=(
   "debug.mediatek.composition.type dyn"
   "debug.egl.composition_type dyn"
   "debug.hwui.composition_type dyn"
   "debug.hwui.render_type dyn"
   "debug.composition.type dyn"
   "debug.sf.composition_type dyn"
   "debug.gr.composition_type dyn"
   "debug.composition.7x27A.type dyn"
   "debug.composition.7x25A.type dyn"
   "debug.composition.8x25.type dyn"
   "debug.gles.composition_type dyn"
   "debug.gles.render_type dyn"
   "debug.hwui.use_gpu_pixel_buffers true"
   "debug.hwui.disable_vsync true"
   "debug.cpurend.vsync false"
   "debug.gpurend.vsync false"
   "debug.hwui.force_no_vsync true"
   "debug.hwui.skip_vsync true"
   "debug.hwc.force_gpu_vsync false"
   "debug.egl.swapinterval 0"
   "debug.gr.swapinterval 0"
   "debug.sf.swapinterval 0"
   "debug.vulkan.swapinterval 0"
   "debug.renderengine.swap_interval 0"
   "debug.composition.enable_egl_swap_interval 0"
   "debug.hwui.profile true"
   "debug.renderengine.backend_threaded true"
   "debug.renderengine.gles_backend gles3"
   "debug.renderengine.gles_fbo_format RGB_565"
   "debug.egl.force_vr_api 1"
   "debug.egl.hw 1"
   "debug.egl.surfaceless_context true"
   "debug.egl.disable_fallback 1"
   "debug.egl.enable_frontbuffer 1"
   "debug.hwui.drop_shadow_cache false"
   "debug.hwui.texture_cache_size 100"
   "debug.hwui.layer_cache_size 50"
   "debug.hwui.r_buffer_cache_size 10"
   "debug.hwui.gradient_cache_size 5"
   "debug.hwui.shape_cache_size 5"
   "debug.hwui.text_large_cache_height 2048"
   "debug.hwui.text_large_cache_width 2048"
   "debug.hwui.filter_cache_size 20"
   "debug.hwui.font_cache_size 4"
   "debug.renderengine.multithread true"
   "debug.sf.hw 1"
   "debug.sf.latch_unsignaled 1"
   "debug.sf.disable_backpressure 1"
   "debug.sf.enable_gl_backpressure 0"
   "debug.sf.disable_client_composition_cache 1"
   "debug.sf.early_phase_offset_ns 0"
   "debug.sf.late_phase_offset_ns 0"
   "debug.fb.linear 1"
   "debug.fb.early_display 1"
   "debug.fb.disable_dyn_overlay 1"
   "debug.hwui.overdraw false"
   "debug.hwui.fps_overlay 0"
   "debug.egl.disable_triple_buffering false"
   "debug.egl.triple_buffering true"
   "debug.hwc.dynThreshold 0"
   "debug.hwui.profile_gpu_render true"
   "debug.hwui.force_gpu_for_2d true"
   "debug.hwui.force_gpu_for_3d false"
   "debug.hwui.force_gpu 1"
   "debug.hwui.target_gpu_time_percent 0"
   "debug.egl.trace 0"
   "debug.egl.profiler 0"
   "debug.egl.enable_hwc_vsync false"
   "debug.overlayui.enable_gpu true"
   "debug.IOMFB.wait_for_gpu 0"
   "debug.sf.gpuoverlay 0"
   "debug.sf.gpu_freq_index 7"
   "debug.sf.enable_egl_image_tracker 0"
   "debug.sf.disable_gl_fence true"
   "debug.hwui.trace_gpu_resources false"
   "debug.hwui.skip_eglmanager_telemetry true"
   "debug.force_rtl 0"
   "debug.renderer.process_compound true"
   "debug.renderthread.reduceopstasksplitting true"
   "debug.renderthread.skia.reduceopstasksplitting true"
   "debug.egl.native_scaling false"
   "debug.sf.force_cursor_gpu 1"
   "debug.sf.enable_gpu_security 1"
   "debug.graphics.game_default_frame_rate.disabled true"
   "debug.sf.dyn_comp_tiling 1"
   "debug.dyncomp.enable 1"
   "debug.dyncomp.maxlayer 4"
   "debug.dyncomp.cache 1"
   "debug.dyncomp.perf 1"
   "debug.dyncomp.logs 0"
   "debug.dyncomp.maxpermixer -1"
   "debug.dyncomp.mixedmode.disable 1"
   "debug.dyncomp.idletime 0"
   "debug.dyncomp.4k2kSplit 0"
   "debug.qctwa.preservebuf 1"
   "debug.qctwa.statusbar 1"
   "debug.qc.hardware 1"
   "debug.hwui.fbo_cache_size 16"
   "debug.disable.bwc 1"
   "debug.egl.force_msaa false"
   "debug.egl.force_fxaa false"
   "debug.egl.force_taa false"
   "debug.egl.force_ssaa false"
   "debug.egl.force_smaa false"
   "debug.egl.force_mlaa false"
   "debug.egl.force_txaa false"
   "debug.egl.force_csaa false"
   "debug.egl.disallow_fp16 0"
   "debug.gralloc.enable_fb_ubwc 0"
   "debug.gralloc.gfx_ubwc_disable 1"
   "debug.sf.numframebuffers 3"
   "debug.gr.numframebuffers 3"
   "debug.sf.earlyGl.app.duration 0"
   "debug.sf.earlyGl.sf.duration 0"
   "debug.sf.high_fps.earlyGl.sf.duration 0"
   "debug.sf.high_fps.earlyGl.app.duration 0"
   "debug.sf.120_fps.earlyGl.sf.duration 0"
   "debug.sf.120_fps.earlyGl.app.duration 0"
)
for prop in "${android_properties[@]}"; do
   setprop $prop > /dev/null 2>&1
done

dumpsys deviceidle force-idle  > /dev/null 2>&1

settings put global cpu_gpu_constants "cpu_boost_threshold=100, gpu_boost_threshold=100, cpu_max_freq=3000000, gpu_max_freq=1000000000, cpu_min_freq=300000, gpu_min_freq=300000000, cpu_affinity=0,1,2,3,4,5,6,7, gpu_affinity=0,1,2,3" > /dev/null 2>&1
settings put global dynamic_frequency_scaling_constants "cpu_scaling_max=3000000, gpu_scaling_max=700000000, cpu_scaling_min=300000, gpu_scaling_min=200000000, cpu_interactive_target_load=100, gpu_interactive_target_load=100" > /dev/null 2>&1
settings put global gaming_memory_constants "gaming_memory_alloc_size=4096, gaming_memory_optimize=true, memory_gc_threshold=50000, memory_swap_enable=true, large_cache_threshold=500000, low_memory_threshold_game=256000, gaming_memory_pinning=true, memory_prefetch_enable=true, gaming_memory_dynamic_allocation=true, gaming_memory_swap_size=1024000" > /dev/null 2>&1
settings put global gaming_power_constants "gaming_performance_mode=true, max_cpu_performance=100, max_gpu_performance=100, cpu_power_saving_mode=false, gpu_power_saving_mode=false, disable_background_services=true, aggressive_power_save_mode=false, enable_high_performance_graphics=true, disable_vsync=true, disable_surface_view=false, disable_fullscreen=false, enable_cpu_boost=true, enable_gpu_boost=true, disable_power_save=true" > /dev/null 2>&1
settings put global app_process_constants "bg_start_timeout=1000, fg_start_timeout=300, app_process_max=2048, service_restart_duration=1000, service_restart_duration_factor=1, bg_anr_timeout=3000, fg_anr_timeout=4000" > /dev/null 2>&1

set_android() {
cmd device_config put input filtered_accel_event_rate_hz 200
cmd device_config put surfaceflinger set_max_frame_rate_multiplier 0.5
cmd device_config put surfaceflinger refresh_rate 120
cmd device_config put surfaceflinger min_swap_interval 0
cmd device_config put surfaceflinger vsync_eventphase_offset_ns 1200000
cmd device_config put surfaceflinger vsync_sfoffset_ns 1200000
cmd device_config put activity_manager force_high_refresh_rate true
cmd device_config put systemui accelerate_refresh_rate true
cmd device_config put systemui min_refresh_rate_for_fps_boost 120
cmd device_config put systemui max_refresh_rate_for_fps_boost 120
cmd device_config put graphics refresh_rate 120
cmd device_config put graphics_sf swapinterval 0
settings put system db_screen_rate 2
settings put system miui_home_animation_rate 2
settings put system refresh_default_rate 120
settings put system default_refresh_rate 120
settings put system default_refresh_mode 2
settings put system min_refresh_rate 120
settings put system min_frame_rate 120
settings put system thermal_limit_refresh_rate 120
settings put system user_refresh_rate 120
settings put system peak_refresh_rate 120
settings put system miui_refresh_rate 120
settings put system last_tran_refresh_mode_in_refresh_setting 120
settings put system tran_settings_long_battery_swith_60hz 0
settings put system tran_low_battery_60hz_refresh_rate_support 0
settings put system tran_need_recovery_refresh_mode 120
settings put system tran_refresh_mode 120
settings put system refresh_rate 120
settings put system table_framerate 120
settings put system high_fps_mode 2
settings put system sem_power_mode_refresh_rate 0,0,-1,0,2
settings put system sem_power_mode_refresh_rate_cover 0,0,-1,0,2
settings put system SEM_VIBRATION_FORCE_TOUCH_INTENSITY 4
settings put system RUS_DDS_SWITCH_FEATURE_DAILY_LIMIT_RATE 0.95
settings put system RUS_DDS_SWITCH_FEATURE_MONTH_LIMIT_RATE 0.95
settings put system SMART_CONTROLS_SUPPORT 0
settings put system persist_games_spoof 1
settings put system is_smart_fps 0
settings put system comp_hint_fps 120
settings put system screen_mode_type 2
settings put system fps.limit.is.now locked
settings put system tran_settings_long_battery_action_gesture 1
settings put system tran_settings_long_battery_mode 0
settings put system tran_settings_long_battery_super_ps_overlay 0
settings put system PointerVelocityControlParameters 0
settings put system SpeedControlPara ver_num=4;enable=true;thermal=120;limit_level=120,120,120,120;limit_level_up=120,120,120,120;prohibittimer=3600;boost_mode=1;cooldown_time=300;fps_stabilizer=true;vsync_control=0
settings put system QuietInterval 0
settings put system TapInterval 0
settings put system pointer_gesture_duration 40
settings put system rt_enable_templimit false
settings put system touchpanel_oplus_tp_limit_enable 0
settings put system touchscreen_pointer_speed 15
settings put system type_touch_speed 1
settings put system full_pss_lowered_interval 0
settings put system full_pss_min_interval 0
settings put system gc_min_interval 0
settings put system touchscreen_threshold 0
settings put system power_check_interval 0
settings put system tran_cpupower_mode 1
settings put system surface_palm_touch 0
settings put system surface_palm_swipe 1
settings put system power_save_pre_refresh_state 0
settings put system power_save_screen_refresh_rate 0
settings put system power_save_coloros_screen_refresh_rate 0
settings put system multi_device_decrease_refresh_rate_backup -1
settings put system touchpanel_oplus_tp_limit_enable 0
settings put system touchpanel_oppo_tp_limit_enable 0
settings put system settings_thermal_high 0
settings put secure miui_refresh_rate 120
settings put secure support_highfps 1
settings put secure user_refresh_rate 120
settings put secure tts_default_pitch 400
settings put secure tts_default_rate 600
settings put secure refresh_rate_mode 2
settings put secure spoof_storage_encryption_status 1
settings put secure touch_exploration_enabled 0
settings put secure tencent_game_haptic_state 1
settings put secure oplus_customize_screen_refresh_rate 3
settings put secure oplus_customize_min_refresh_rate 1
settings put secure oplus_customize_peak_refresh_rate 1
settings put secure coloros_screen_refresh_rate 3
settings put secure oppo_gesture_double_touch 1
settings put secure tap_duration_threshold 0.0
settings put secure touch_blocking_period 0.0
settings put secure long_press_timeout 400
settings put secure multi_press_timeout 300
settings put global allow_signature_fake 1
settings put global fpsgo_support_status enable
settings put global remove_animations 1
settings put global reduce_transitions 1
settings put global reduce_animations 1
settings put global slider_animation_duration 250
settings put global shadow_animation_scale 0
settings put global window_animation_scale 0.3
settings put global transition_animation_scale 0.3
settings put global animator_duration_scale 0.0
settings put global window_focus_timeout 250
settings put global tran_settings_all_animation_scale 0.3
settings put global sys.rotation.animscale 0.3
settings put global fancy_ime_animations 0
settings put global tran_low_battery_60hz_refresh_rate_support 0
settings put global tran_settings_long_battery_swith_60hz 0
settings put global ingress_rate_limit_bytes_per_second -1
settings put global vivo_screen_refresh_rate_mode 120
settings put global tran_limited_frequency 0
settings put global FPSTUNER_SWITCH false
settings put global ScreenRefreshRateController_resultFps 120
settings put global double_frame_flag 0
settings put global drop_frame_flag 0
settings put global screen_refresh_rate 120
settings put global isSupportGyroSen 1
settings put global SpeedControlPara ver_num=4;enable=true;thermal=120;limit_level=120,120,120,120;limit_level_up=120,120,120,120;prohibittimer=3600;boost_mode=1;cooldown_time=300;fps_stabilizer=true;vsync_control=0
settings put global scrollshot_switch 0
settings put global ENFORCE_PROCESS_LIMIT false
settings put global sys.refresh.dirty 0
settings put global sys.surfaceflinger.idle_reduce_framerate_enable no
settings put global sys.fps_unlock_allowed 120
settings put global oneplus_screen_refresh_rate 0
settings put global 6ecb9657_screen_refresh_rate 0
settings put global tran_high_temperature_fps_support 1
settings put global job_scheduler_quota_controller_constants max_job_count_per_rate_limiting_window=999999,rate_limiting_window_ms=0,max_job_count_active=999999,max_session_count_active=999999
settings put global speedModeToggle 1
settings put global touchSamplingToggle 1
}
set_android > /dev/null 2>&1
android_properties() {
setprop sys.refresh.dirty 0
setprop dev.pm.dyn_samplingrate 1
setprop dev.pm.dyn_sample_period 0
setprop persist.sys.fpsctrl.enable 0
setprop persist.sys.autofps.mode 0
setprop persist.sys.smartfps 0
setprop persist.sys.NV_FPSLIMIT 120
setprop persist.sys.fps.max 120
setprop persist.sys.display.gamecustomfps 120
setprop persist.sys.vsync_optimization_enable true
setprop persist.sys.hwui.dyn_vsync 1
setprop persist.sys.vsync true
setprop debug.sf.show_predicted_vsync true
setprop debug.hwui.disable_vsync false
setprop debug.cpurend.vsync true
setprop debug.gpurend.vsync true
setprop debug.hwui.force_no_vsync false
setprop debug.hwui.skip_vsync false
setprop debug.egl.swapinterval 1
setprop debug.gr.swapinterval 1
setprop debug.sf.swapinterval 1
setprop debug.oculus.swapInterval 1
setprop debug.vulkan.swapinterval 1
setprop debug.gr.numframebuffers 3
setprop debug.sf.numframebuffers 3
setprop debug.hwc.fakevsync 1
setprop debug.hwc.logvsync 1
setprop debug.hwc.force_gpu_vsync true
setprop debug.sf.phase_offset_threshold_ns 1200000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 1200000
setprop debug.sf.hwc_hotplug_error_via_neg_vsync true
setprop debug.sf.hwc_hdcp_via_neg_vsync true
setprop debug.sf.no_hw_vsync 0
setprop debug.sf.vsync_reactor_ignore_present_fences 1
setprop debug.sf.vsync_reactor true
setprop debug.sf.disable_vsync 0
setprop debug.sf.native_vsync 1
setprop debug.sf.early.app.duration 1200000
setprop debug.sf.early.sf.duration 1200000
setprop debug.sf.earlyGl.app.duration 1200000
setprop debug.sf.earlyGl.sf.duration 1200000
setprop debug.sf.late.app.duration 1200000
setprop debug.sf.late.sf.duration 1200000
setprop debug.sf.hwc.min.duration 1200000
setprop debug.sf.high_fps.late.sf.duration 1200000
setprop debug.sf.high_fps.late.app.duration 1200000
setprop debug.sf.high_fps.early.sf.duration 1200000
setprop debug.sf.high_fps.early.app.duration 1200000
setprop debug.sf.high_fps.earlyGl.sf.duration 1200000
setprop debug.sf.high_fps.earlyGl.app.duration 1200000
setprop debug.sf.high_fps.hwc.min.duration 1200000
setprop debug.sf.120_fps.late.sf.duration 1200000
setprop debug.sf.120_fps.late.app.duration 1200000
setprop debug.sf.120_fps.early.sf.duration 1200000
setprop debug.sf.120_fps.early.app.duration 1200000
setprop debug.sf.120_fps.earlyGl.sf.duration 1200000
setprop debug.sf.120_fps.earlyGl.app.duration 1200000
setprop debug.sf.120_fps.hwc.min.duration 1200000
setprop debug.perf_event_max_sample_rate 240
setprop debug.sf.layer_smoothness 1
setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 0
setprop debug.oculus.refreshRate 120
setprop debug.hwui.fps_divisor 0
setprop debug.javafx.animation.framerate 120
setprop debug.graphics.game_default_frame_rate.disabled true
setprop debug.redroid.fps 120
setprop debug.hwui.profile.maxframes 120
setprop debug.OVRPlugin.systemDisplayFrequency 120
setprop debug.sf.max_frame_latency 1
setprop debug.sf.swaprect 1
setprop debug.sf.showbackground 0
setprop debug.sf.showcpu 0
setprop debug.sf.showfps 0
setprop debug.sf.showupdates 0
setprop debug.sf.enable_vrr_config false
setprop debug.sf.scroll_boost_refreshrate 120
setprop debug.sf.touch_boost_refreshrate 120
setprop debug.sf.enable_refresh_rate_restriction_for_app_switch 0
setprop debug.sf.refreshrate_multi_group 0
setprop debug.sf.region_sampling_timer_timeout_ns 0
setprop debug.sf.region_sampling_period_ns 0
setprop debug.sf.show_refresh_rate_overlay_spinner 0
setprop debug.sf.show_refresh_rate_overlay_render_rate 0
setprop debug.sf.show_refresh_rate_overlay_in_middle 0
setprop debug.sf.frame_rate_category_mrr 0
setprop debug.sf.present_timestamp false
setprop debug.sf.present_time_offset_ns 0
setprop debug.sf.predicted_present_timestamp 0
setprop debug.sf.disable_frame_fences true
setprop debug.sf.disable_gl_fence true
setprop debug.fps.render.fast 1
setprop debug.refresh_rate.view_override 0
setprop debug.sf.prim_perf_120hz_base_brightness_zone 120:120:120,120:120:120
setprop debug.sf.prim_perf_120hz_base_brightness_zone 120:120:120,120:120:120,120:120:120
setprop debug.sf.prim_std_brightness_zone 120:120:120,120:120:120
setprop debug.sf.cli_perf_brightness_zone 120:120:120
setprop debug.sf.cli_std_brightness_zone 120:120:120
setprop debug.sf.1hz_nit_lower_limit 900
setprop debug.sf.10hz_nit_lower_limit 100
setprop sys.surfaceflinger.idle_reduce_framerate_enable no
setprop sys.fps_unlock_allowed 120
setprop sys.refresh.dirty 0
}
android_properties > /dev/null 2>&1