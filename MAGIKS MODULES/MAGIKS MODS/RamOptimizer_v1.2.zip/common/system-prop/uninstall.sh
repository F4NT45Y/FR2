echo "╔═══╗╔═══╗╔═╗╔═╗ 
║╔═╗║║╔═╗║║║╚╝║║ 
║╚═╝║║║─║║║╔╗╔╗║ 
║╔╗╔╝║╚═╝║║║║║║║ 
║║║╚╗║╔═╗║║║║║║║ 
╚╝╚═╝╚╝─╚╝╚╝╚╝╚╝ 
╔═══╗╔═══╗╔════╗╔══╗╔═╗╔═╗╔══╗╔════╗╔═══╗╔═══╗ 
║╔═╗║║╔═╗║║╔╗╔╗║╚╣╠╝║║╚╝║║╚╣╠╝╚══╗═║║╔══╝║╔═╗║ 
║║─║║║╚═╝║╚╝║║╚╝─║║─║╔╗╔╗║─║║───╔╝╔╝║╚══╗║╚═╝║ 
║║─║║║╔══╝──║║───║║─║║║║║║─║║──╔╝╔╝─║╔══╝║╔╗╔╝ 
║╚═╝║║║─────║║──╔╣╠╗║║║║║║╔╣╠╗╔╝═╚═╗║╚══╗║║║╚╗ 
╚═══╝╚╝─────╚╝──╚══╝╚╝╚╝╚╝╚══╝╚════╝╚═══╝╚╝╚═╝ 
"
echo ""
echo "uninstall Ram-Optimizer v1.2 Please Waite"
(
#Reset Zram
settings put  global zram_enabled  0
settings delete global ram_expand_size 
#Maximal Zram Config Delete
settings delete global activity_manager_constants max_cached_processes 
settings delete global app_standby_enabled
settings delete global cached_app_lru_limit 
) > /dev/null 2>&1
(
#NEW
settings delete global config.spcm_enable
settings delete global config.spcm_kill_skip
settings delete global config.samp_spcm_enable
settings delete global config.spcm_db_enable
settings delete global config.spcm_db_launcher
settings delete global config.spcm_preload_enable
settings delete global config.spcm_gcm_kill_enable
settings delete global config.dha_cached_max
settings delete global config.dha_empty_max
settings delete global config.dha_empty_init
settings delete global config.dha_lmk_scale
settings delete global config.dha_th_rate
settings delete global config.sdha_apps_bg_max
settings delete global config.sdha_apps_bg_min
settings delete global transition_animation_scale
settings delete global window_animation_scale
settings delete global animator_duration_scale
#Menghapus Configurasi Ram 6-12
settings delete global activity_manager_constants
settings delete global low_ram
settings delete global force_low_ram_device
settings delete system sys.haptic.low_ram
settings delete global swap_free_low_percentage
settings delete global zram_enable
settings delete global zram_size
settings delete global lmk_minfree
settings delete global lmk_upgrade_pressure
settings delete global lmk_downgrade_pressure
settings delete global activity_manager_constants max_cached_processes
settings delete global activity_manager_constants max_phantom_processes
settings delete global activity_manager_constants bg_low_mem_mult
settings delete global activity_manager_constants cur_max_cached_processes
settings delete global limit_background_processes  
settings delete system vm_drop_caches 
# Start kembali Tombstoned
start tombstoned
pm enable com.android.shell.tombstoned
settings delete system force_all_apps_stopped 
# Mengembalikan pengaturan ke nilai default atau mengaktifkan kembali fitur yang dinonaktifkan
settings delete system air_motion_engine
settings delete system air_motion_wake_up
settings delete global activity_starts_logging_enabled
settings delete global ble_scan_always_enabled
settings delete global hotword_detection_enabled
settings delete global mobile_data_always_on
settings delete global network_recommendations_enabled
settings delete global wifi_scan_always_enabled
settings delete secure adaptive_sleep
settings delete secure screensaver_activate_on_dock
settings delete secure screensaver_activate_on_sleep
settings delete secure screensaver_enabled
settings delete secure send_action_app_error
settings delete system intelligent_sleep_mode
settings delete system master_motion
settings delete system motion_engine
settings delete system nearby_scanning_enabled
settings delete system nearby_scanning_permission_allowed
settings delete system rakuten_denwa
settings delete system send_security_reports
) > /dev/null 2>&1 &

sleep 2

for app in $(cmd package list packages -3 | cut -f 2 -d ":"); do
if [[ ! "$app" == "me.piebridge.brevent" ]] && \
   [[ ! "$app" == "eu.sisik.hackendebug" ]] && \
   [[ ! "$app" == "com.whatsapp" ]] && \
   [[ ! "$app" == "com.omarea.vtools" ]] && \
   [[ ! "$app" == "com.miHoYo.GenshinImpact" ]] && \
   [[ ! "$app" == "com.dts.freefiremax" ]] && \
   [[ ! "$app" == "com.dts.freefireth" ]] && \
   [[ ! "$app" == "com.tencent.ig" ]] && \
   [[ ! "$app" == "com.vexiro.tweak" ]] && \
   [[ ! "$app" == "com.mobile.legends" ]]; then
   echo "Stop killing $app"
   # Tidak perlu melakukan apa-apa, aplikasi tidak akan di-force stop lagi
   sleep 1
   echo ""
fi
done
) > /dev/null 2>&1 &
echo "Repacking Zip File"
sleep 2
echo "Menghapus Storage Database Module"
sleep 3
echo "uninstall Module Done"