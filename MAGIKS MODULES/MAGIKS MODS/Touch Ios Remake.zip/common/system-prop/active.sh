# © 2025 magiks Vexiro. All rights reserved.
# Version 1.0
#
# magiks Vexiro
# A lightweight utility app designed to enhance user experience through various system tweaks and optimizations.
#
# Developer: @traatweak
# Email: magiksvexiro@gmail.com
# Website: https://magiksvexiro.github.io/revox/
#
# This app is developed with a focus on efficiency, stability, and ease of use.
# All components and features are independently built to ensure maximum performance across devices.
#
# Copyright & License
# All contents within this app are protected by copyright laws.
# It is strictly prohibited to copy, modify, or redistribute this app, in whole or in part, without written permission from the developer.
# Violations will be prosecuted under applicable law.
#
# Disclaimer
# This application is provided "as is" without any warranty, express or implied.
# The user assumes full responsibility for the use of this application.
#
# Contact & Support
# For issues, suggestions, or contributions, feel free to contact us via email or visit our official website.
#
# Privacy Policy | Terms of Service
{
setprop debug.sf.display-fps 120
setprop debug.sf.hwui.enable 1
setprop debug.sf.prim_perf_120hz_base_brightness_zone 120:120:120,120:120:120
setprop debug.sf.prim_perf_120hz_base_brightness_zone 120:120:120,120:120:120,120:120:120
setprop debug.sf.prim_std_brightness_zone 120:120:120,120:120:120
setprop debug.sf.cli_perf_brightness_zone 120:120:120
setprop debug.sf.cli_std_brightness_zone 120:120:120
setprop debug.sf.1hz_nit_lower_limit 900
setprop debug.sf.10hz_nit_lower_limit 100
setprop debug.sf.refreshrate_multi_group 1
setprop debug.sf.dim_in_gamma_in_enhanced_screenshots 1
setprop debug.sf.log_expensive_rendering 1
setprop debug.sf.scroll_boost_refreshrate 120
setprop debug.sf.touch_boost_refreshrate 120
setprop debug.sf.high_speed_scroll_factor 25
setprop debug.sf.force_p3_to_srgb_oem 1
setprop debug.sf.supports_desired_transition_mode 1
setprop debug.sf.enable_refresh_rate_restriction_for_app_switch 1
setprop debug.sf.support_hdr_by_wide_color_gamut 1
setprop debug.sf.enable_triple_buffer 1
setprop debug.sf.log 0
setprop debug.sf.log_repaint 0
setprop debug.sf.cpu_comp_tiling 1
setprop debug.sf.enable_adpf_gpu_hint 1
setprop debug.sf.layer_timeout 0
setprop debug.sf.layer_smoothness 1
setprop debug.sf.swaprect 1
setprop debug.sf.nobootanimation 0
setprop debug.sf.buffer_fence_tracker 0
setprop debug.sf.display_dejitter_log 0
setprop debug.sf.display_dejitter 0
setprop debug.sf.dump_buffers 0
setprop debug.sf.log_transaction 0
setprop debug.sf.dump_buffers.sample 0
setprop debug.sf.stats 0
setprop debug.sf.stc_interval 1
setprop debug.sf.wdthreshold 0
setprop debug.sf.wdlog 0
setprop debug.sf.wdtimer 0
setprop debug.sf.perf_uclamp_min 130
setprop debug.sf.nativedump 0
setprop debug.sf.compbypass.enable 0
setprop debug.sf.compbypass.count 0
setprop debug.sf.enable_hgl 0
setprop debug.sf.ddms 0
setprop debug.sf.dump 0
setprop debug.sf.max_igbp_list_size 0
setprop debug.sf.kernel_idle_timer_update_overlay 0
setprop debug.sf.support_kernel_idle_timer_enabled 1
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.hw 1
setprop debug.sf.peak_refresh_rate 120
setprop debug.sf.min_refresh_rate 120
setprop debug.sf.max_refresh_rate 120
setprop debug.sf.fps 120
setprop debug.sf.showupdates 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.showfps 0
setprop debug.sf.120hz_mode 1
setprop debug.sf.frame_rate 120
setprop debug.sf.hwui.fps 120
setprop debug.sf.hwui.framerate 120
setprop debug.sf.hwui.refresh_rate 120
setprop debug.sf.hwui.sampling_rate 120
setprop debug.sf.hwui.render_fps 120
setprop debug.sf.hwui.update_rate 120
setprop debug.sf.hwui.detail_fps 120
setprop debug.sf.hwui_refresh_rate 120
setprop debug.sf.hwui_max_fps 120
setprop debug.sf.hwui_min_fps 120
setprop debug.sf.hwui_force_refresh_rate 120
setprop debug.sf.hwui_frame_rate 120
setprop debug.sf.hwui_frame_rate_multiple 120
setprop debug.sf.hwui_fps_boost 120
setprop debug.sf.hwui_fps_throttle 120
setprop debug.sf.frame_rate_multiple_fences 120
setprop debug.sf_frame_rate_multiple_fences 120
setprop debug.sf.frame_rate_multiple_threshold 120
setprop debug.sf.treat_170m_as_sRGB 1
setprop debug.sf.latch_unsignaled true
setprop debug.sf.auto_latch_unsignaled true
setprop debug.sf.luma_sampling 0
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.enable_layer_caching 0
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.disable_hwc_vds 0
setprop debug.sf.enable_hwc 1
setprop debug.sf.disable_hwc 0
setprop debug.sf.recomputecrop 0
setprop debug.sf.numFramebuffers 3
setprop debug.sf.numFramebuffer 3
setprop debug.sf.numframebuffers 3
setprop debug.sf.numframebuffer 3
setprop debug.sf.enable_transaction_tracing 0
setprop debug.sf.swapinterval 1
setprop debug.sf.swap_interval 1
setprop debug.sf.force_gpu_composition 1
setprop debug.sf.hwui.gpu_perf 1
setprop debug.sf.force_hwc_vds_off 0
setprop debug.sf.force_hwc_vds_on 1
setprop debug.sf.gpuoverlay 0
setprop debug.sf.hwui.gpu 1
setprop debug.sf.perf_mode 1
setprop debug.sf.hwui.force_hw 1
setprop debug.sf.gpu_comp_tiling 1
setprop debug.sf.set_binder_thread_rt 1
setprop debug.sf.ignore_hwc_physical_display_orientation 0
setprop debug.sf.enable_adpf_cpu_hint 1
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.enable_advanced_sf_phase_offset 1
setprop debug.sf.no_hw_vsync 0
setprop debug.sf.disable_hw_vsync 0
setprop debug.sf.enable_hw_vsync 1
setprop debug.sf.show_predicted_vsync 1
setprop debug.sf.disable_vsync_timestamps 0
setprop debug.sf.enable_vsync_timestamps 1
setprop debug.sf.enabled_vsync_timestamps 1
setprop debug.sf.disable_phase_offset_for_vsync 0
setprop debug.sf.enable_phase_offset_for_vsync 1
setprop debug.sf.no_vsync_phase_adjustment 0
setprop debug.sf.vsync_threshold 23000000
setprop debug.sf.enable_vsync 1
setprop debug.sf.disable_vsync 0
setprop debug.sf.hwc.min.duration 23000000
setprop debug.sf.late.sf.duration 27600000
setprop debug.sf.late.app.duration 20000000
setprop debug.sf.early.sf.duration 27600000
setprop debug.sf.early.app.duration 20000000
setprop debug.sf.earlyGl.sf.duration 27600000
setprop debug.sf.earlyGl.app.duration 20000000
setprop debug.sf.high_fps.late.sf.duration 27600000
setprop debug.sf.high_fps.late.app.duration 20000000
setprop debug.sf.high_fps.early.sf.duration 27600000
setprop debug.sf.high_fps.early.app.duration 20000000
setprop debug.sf.high_fps.earlyGl.sf.duration 27600000
setprop debug.sf.high_fps.earlyGl.app.duration 20000000
setprop debug.sf.high_fps.hwc.min.duration 23000000
setprop debug.sf.120_fps.late.sf.duration 27600000
setprop debug.sf.120_fps.late.app.duration 20000000
setprop debug.sf.120_fps.early.sf.duration 27600000
setprop debug.sf.120_fps.early.app.duration 20000000
setprop debug.sf.120_fps.earlyGl.sf.duration 27600000
setprop debug.sf.120_fps.earlyGl.app.duration 20000000
setprop debug.sf.120_fps.hwc.min.duration 23000000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 23000000
setprop debug.sf.send_early_power_session_hint 1
setprop debug.sf.send_late_power_session_hint 1
setprop debug.sf.vsync_threshold_ns 23000000
setprop debug.sf.present_time_offset_ns 23000000
setprop debug.sf.present_offset_ns 23000000
setprop debug.sf.vsync_phase_offset_ns 23000000
setprop debug.sf.early_vsync_offset_ns 20000000
setprop debug.sf.late_vsync_offset_ns 27600000
setprop debug.sf.force_hwc_vsync 1
setprop debug.sf.early_phase_offset_ns 20000000
setprop debug.sf.early_gl_phase_offset_ns 20000000
setprop debug.sf.early_app_phase_offset_ns 20000000
setprop debug.sf.region_sampling_timer_timeout_ns 27600000
setprop debug.sf.region_sampling_period_ns 23000000
setprop debug.sf.layer_caching_active_layer_timeout_ms 20
setprop debug.sf.vsync_reactor_ignore_present_fences 1
setprop debug.sf.hwc_hotplug_error_via_neg_vsync 0
setprop debug.sf.hwc_hdcp_via_neg_vsync 0
setprop debug.sf.vsync_offset_ns 23000000
setprop debug.sf.early_phase_offset_ns 20000000
setprop debug.sf.early_app_phase_offset_ns 20000000
setprop debug.sf.early_gl_phase_offset_ns 20000000
setprop debug.sf.early_gl_app_phase_offset_ns 20000000
setprop debug.sf.high_fps_late_sf_phase_offset_ns 27600000
setprop debug.sf.high_fps_early_phase_offset_ns 20000000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 20000000
setprop debug.sf.high_fps_late_app_phase_offset_ns 27600000
setprop debug.sf.vsync_min_work_duration 23000000
setprop debug.sf.perf_fps_early_gl_phase_offset_ns 20000000
setprop debug.sf.set_display_power_timer_ms 50
setprop debug.sf.set_touch_timer_ms 100
setprop debug.sf.set_idle_timer_ms 1000
setprop debug.sf.support_kernel_idle_timer 1
setprop debug.sf.vsync_event_phase_offset_ns 23000000
setprop debug.sf.vsync_sf_event_phase_offset_ns 23000000
setprop debug.sf.disable_idle_timeout 0
setprop debug.sf.present_timestamp 23000000
setprop debug.sf.display_update_imminent_timeout_ms 50
setprop debug.sf.vsync_mode 1
setprop debug.sf.vsync_buffer_size 3
setprop debug.sf.vsync_disable_on_idle 1
setprop debug.sf.vsync_enable_on_idle 0
setprop debug.sf.hwc.vsync_mode 1
setprop debug.sf.disable_vsync_interrupt 0
setprop debug.sf.enable_vsync_interrupt 1
setprop debug.sf.sync_vsync_hwc 1
setprop debug.sf.avoid_vsync_jitter 1
setprop debug.sf.default_refresh_rate 120
setprop debug.sf.latch_all_layers 0
setprop debug.sf.enable_hwc_vsync 1
setprop debug.sf.disable_hwc_vsync 0
setprop debug.sf.trace_enabled 0
setprop debug.sf.use_hardware_layer 0
setprop debug.sf.texture_cache_limit 256MB
setprop debug.sf.vsync_source 1
setprop debug.sf.hwvsync 1
setprop debug.sf.enable_sdr_dimming 1
setprop debug.sf.enable_gpu_fence 0
setprop debug.sf.enable_cpu_fence 0
setprop debug.sf.disable_gpu_fence 0
setprop debug.sf.disable_cpu_fence 0
setprop debug.sf.mem_freq_index 7
setprop debug.sf.cpu_freq_index 7
setprop debug.sf.gpu_freq_index 7
setprop debug.sf.max_framebuffers 3
setprop debug.sf.protected_contents 0
setprop debug.sf.enable_layer_caching 0
setprop debug.sf.use_content_detection_for_refresh_rate 1
setprop debug.sf.max_frame_buffer_acquired_buffers 3
setprop debug.sf.supports_background_blur 1
setprop debug.sf.has_wide_color_display 1
setprop debug.sf.has_HDR_display 1
setprop debug.sf.use_color_management 1
setprop debug.sf.max_frame_buffer_blit_buffers 3
setprop debug.sf.max_triple_buffer 3
setprop debug.sf.primary_display_orientation ORIENTATION_0
setprop debug.sf.force_hwc_copy_for_virtual_displays 1
setprop debug.sf.uclamp.min 130
setprop debug.sf.game_default_frame_rate_override 120
setprop debug.sf.ignore_hdr_camera_layers 0
setprop debug.sf.use_smart_90_for_video 1
setprop debug.sf.enable_frame_rate_override 1
setprop debug.sf.max_refresh_rate 120
setprop debug.sf.min_refresh_rate 120
setprop debug.sf.peak_refresh_rate 120
setprop debug.sf.default_refresh_rate 120
setprop debug.sf.render_early 1
setprop debug.sf.default_frame_rate 120
setprop debug.sf.max_layer_cache_size 5
setprop debug.sf.render_hardware_layer 1
setprop debug.sf.force_software_layers 0
setprop debug.sf.enable_hardware_composition 1
setprop debug.sf.max_hardware_layers 2
setprop debug.sf.max_buffer_count 3
setprop debug.sf.background_layer_count 1
setprop debug.sf.optimize_vsync 1
setprop debug.sf.use_dynamic_vsync 1
setprop debug.sf.dynamic_vsync_threshold 1
setprop debug.sf.disable_brightness_adjustment 1
setprop debug.sf.enable_hwc_debug 1
setprop debug.sf.virtual_display_default_refresh_rate 120
setprop debug.sf.hdr_wcg_dynamic_range 0
setprop debug.sf.enable_hdr_mode 1
setprop debug.sf.force_hdr_metadata 1
setprop debug.sf.enable_touch_response 1
setprop debug.sf.enable_dynamic_refresh_rate 0
setprop debug.sf.enable_color_grading 1
setprop debug.sf.enable_dithering 0
setprop debug.sf.max_layers_for_composition 4
setprop debug.sf.disable_fps_vsync 0
setprop debug.sf.enable_full_screen 0
setprop debug.sf.use_bluetooth_hdr 0
setprop debug.sf.force_hardware_vsync 1
setprop debug.sf.enforce_hdr_display_mode 1
setprop debug.sf.adjust_brightness_for_hdr 0
setprop debug.sf.enable_gamma_correction 0
setprop debug.sf.use_seamless_refresh 1
setprop debug.sf.enable_optimized_cache 1
setprop debug.sf.hwc_use_transparent_layers 1
setprop debug.sf.skip_empty_compositions 1
setprop debug.sf.use_multiple_buffers 1
setprop debug.sf.enable_dynamic_layer_priority 0
setprop debug.sf.buffer_management_mode 1
setprop debug.sf.force_hardware_layers 0
setprop debug.sf.enable_hardware_buffer_management 1
setprop debug.sf.vsync_ignore_rate_limit 0
setprop debug.sf.max_layer_count 4
setprop debug.sf.touch_sensitivity_level 1
setprop debug.sf.touch_event_filter 1
setprop debug.sf.enable_video_hardware_accel 1
setprop debug.sf.use_video_layers_for_media 1
setprop debug.sf.force_max_refresh_rate 120
setprop debug.sf.override_min_frame_rate 120
setprop debug.sf.enable_hwc_hdr_dynamic 1
setprop debug.sf.color_space_srgb 1
setprop debug.sf.performance_mode 1
setprop debug.sf.adjust_vsync_for_performance 1
setprop debug.sf.enable_perf_debug 1
setprop debug.sf.enable_dynamic_layer_priority 0
setprop debug.sf.sync_vsync 1
setprop debug.sf.hwui.render_threads 4
setprop debug.sf.use_gl_composition 1
setprop debug.sf.gl_thread_prioritization 1
setprop debug.sf.hwui.default_framebuffer 2
setprop debug.sf.enable_advanced_vsync 1
setprop debug.sf.enable_vsync_auto_adjust 1
setprop debug.sf.display_sync 1
setprop debug.sf.high_fps.enabled 1
setprop debug.sf.use_hwc_for_fps 1
setprop debug.sf.dpm_mode 1
setprop debug.sf.disable_vsync_timer 0
setprop debug.sf.override_vsync_with_real_time 1
setprop debug.sf.hwc.disable_auto_mode_switch 1
setprop debug.sf.hwc.enable_dynamic_composition 1
setprop debug.sf.hwc.override_min_refresh_rate 120
setprop debug.sf.hwui.ssr_enabled 1
setprop debug.sf.hwui.composition 1
setprop debug.sf.hwui.ignore_early_swap 1
setprop debug.sf.hwui.early_swap_duration 0
setprop debug.sf.hwui.force_swap 0
setprop debug.sf.hwui.shadercache 0
setprop debug.sf.hwui.display_power 1
setprop debug.sf.hwui.gl_startup 1
setprop debug.sf.hwui.rendering_smoothness 1
setprop debug.sf.hwui.dynamic_texture 1
setprop debug.sf.hwui.new_ui_config 1
setprop debug.sf.hwui.enable_default_framebuffer 1
setprop debug.sf.hwui.debug_info 0
setprop debug.sf.hwui.overdraw_debug 0
setprop debug.sf.hwui.debug_fps 0
setprop debug.sf.hwui.force_enable_vsync 1
setprop debug.sf.hwui.vsync_frequency 120
setprop debug.sf.hwui.max_buffer_count 6
setprop debug.sf.hwui.max_framebuffer_size 8192
setprop debug.sf.hwui.max_composition_layers 4
setprop debug.sf.hwui.batch_render 1
setprop debug.sf.hwui.use_texture_streaming 1
setprop debug.sf.hwui.texture_streaming_size 2048
setprop debug.sf.hwui.prevent_vsync_timing 0
setprop debug.sf.hwui.use_high_quality_shader 1
setprop debug.sf.hwui.filter_shader 0
setprop debug.sf.hwui.filter_use_optimized_pipeline 1
setprop debug.sf.hwui.enable_composition_hint 1
setprop debug.sf.hwui.enable_texstream_fence 0
setprop debug.sf.hwui.force_texstream 1
setprop debug.sf.hwui.gl_no_high_quality_shader 0
setprop debug.sf.hwui.synchronize_pipeline 1
setprop debug.sf.hwui.enable_texture_optimization 1
setprop debug.sf.hwui.max_texture_cache_size 4096
setprop debug.sf.hwui.texture_cache_limit 2048
setprop debug.sf.hwui.avoid_fullscreen_draw 0
setprop debug.sf.hwui.preload_framebuffer 1
setprop debug.sf.hwui.max_color_bits 30
setprop debug.sf.hwui.use_yuv_format 1
setprop debug.sf.hwui.avoid_pre_swap 0
setprop debug.sf.hwui.fast_path_flush 1
setprop debug.sf.hwui.enable_texture_compression 1
setprop debug.sf.hwui.enable_texture_bypass 1
setprop debug.sf.hwui.enable_framebuffer_tiling 1
setprop debug.sf.hwui.gl_direct_clear 1
setprop debug.sf.hwui.gl_tiling_enabled 1
setprop debug.sf.hwui.disable_framebuffer_debug 0
setprop debug.sf.hwui.gl_disable_async_swap 0
setprop debug.sf.hwui.gl_use_texture_compression 1
setprop debug.sf.hwui.gl_enable_texture_compression 1
setprop debug.sf.hwui.gl_enable_framebuffer_compression 1
setprop debug.sf.hwui.gl_use_shadercache 1
setprop debug.sf.hwui.buffer_compression 1
setprop debug.sf.hwui.ignore_time_filter 1
setprop debug.sf.hwui.compute_shader_framebuffer 0
setprop debug.sf.hwui.optimize_texstream 1
setprop debug.sf.hwui.debug_shader 0
setprop debug.sf.hwui.debug_shader_cache 0
setprop debug.sf.hwui.debug_color_space 0
setprop debug.sf.hwui.ignore_shader 0
setprop debug.sf.hwui.debug_pipeline 0
setprop debug.sf.hwui.gl_layer_filter 1
setprop debug.sf.hwui.debug_smooth_texture_streaming 1
setprop debug.sf.hwui.extra_texture_buffer 1
setprop debug.sf.hwui.use_shader_presets 1
setprop debug.sf.hwui.extra_texture_limit 2048
setprop debug.sf.hwui.use_tile_cache 1
setprop debug.sf.hwui.disable_shader_optimization 0
setprop debug.sf.hwui.gl_use_shader_optimizer 1
setprop debug.sf.hwui.gl_shader_optimizer_cache 1
setprop debug.sf.hwui.gl_force_shader_presets 1
setprop debug.sf.hwui.shader_cache_bypass 0
setprop debug.sf.hwui.enable_hw_color_space 1
setprop debug.sf.hwui.color_space_mode 1
setprop debug.sf.hwui.hw_color_space_policy 0
setprop debug.sf.hwui.enable_texture_policy 1
setprop debug.sf.hwui.texture_policy 0
setprop debug.sf.hwui.use_reserve_texture_cache 1
setprop debug.sf.hwui.reserve_texture_cache_size 1024
setprop debug.sf.hwui.framebuffer_compression_hint 0
setprop debug.sf.hwui.optimize_framebuffer_compression 1
setprop debug.sf.hwui.use_linear_texture 1
setprop debug.sf.hwui.linear_texture_use_optimized_pipeline 1
setprop debug.sf.hwui.shader_cache_size 4096
setprop debug.sf.hwui.optimize_dynamic_texture 1
setprop debug.sf.hwui.retain_linear_texture_cache 0
setprop debug.sf.hwui.preload_texture_cache 1
setprop debug.sf.hwui.optimized_shader_usage 1
setprop debug.sf.hwui.support_hwc 1
setprop debug.sf.hwui.use_swap_hint 1
setprop debug.sf.hwui.retain_optimal_texture_cache 0
setprop debug.sf.hwui.gl_sync_framebuffer 0
setprop debug.sf.hwui.retain_texture_cache 0
setprop debug.sf.hwui.gl_sync_before_clear 1
setprop debug.sf.hwui.use_shader_presets_cache 0
setprop debug.sf.hwui.shade_texture_samples 3
setprop debug.sf.hwui.disable_large_texture 0
setprop debug.sf.hwui.disable_gpu_pipeline 0
setprop debug.sf.hwui.detailed_shader_logging 0
setprop debug.sf.hwui.texture_batch_render 0
setprop debug.sf.hwui.texture_batching 0
setprop debug.sf.hwui.color_sampler_debug 0
setprop debug.sf.hwui.gl_enable_hardware_sync 1
setprop debug.sf.hwui.remove_flush_synchronization 1
setprop debug.sf.hwui.debugger_shader_cache 0
setprop debug.sf.hwui.use_full_frame_cache 1
setprop debug.sf.hwui.shader_cache_duration 3600
setprop debug.sf.hwui.use_framebuffer_cache 1
setprop debug.sf.hwui.gl_clear_batch 1
setprop debug.sf.hwui.gl_disable_reservoir_cache 0
setprop debug.sf.hwui.shader_cache_max 512
setprop debug.sf.hwui.clear_shader_cache 0
setprop debug.sf.hwui.texture_batch_final 1
setprop debug.sf.hwui.optimal_texture_comp_cache 0
setprop debug.sf.hwui.trace_shader_cache 0
setprop debug.sf.hwui.max_batch_texture_size 2048
setprop debug.sf.hwui.prevent_batch_texture_limit 1
setprop debug.sf.hwui.batch_fence_time 250
setprop debug.sf.hwui.tiling_gpu 0
setprop debug.sf.hwui.batch_flush_limit 50
setprop debug.sf.hwui.use_prefetch_shader 0
setprop debug.sf.hwui.batch_shade_render 1
setprop debug.sf.hwui.framebuffer_tiling_size 2048
setprop debug.sf.hwui.max_texture_size 8192
setprop debug.sf.hwui.max_texture_usage 4096
setprop debug.sf.hwui.use_tiling_shader 1
setprop debug.sf.hwui.framebuffer_hint 1
setprop debug.sf.hwui.remove_clear_sync 1
setprop debug.sf.hwui.enable_clear_hint 1
setprop debug.sf.hwui.shader_cache_size_limit 0
setprop debug.sf.hwui.optimize_frame_buffer_cache 1
setprop debug.sf.hwui.use_texture_cache_hints 1
setprop debug.sf.hwui.enable_shader_cache_hints 1
setprop debug.sf.hwui.final_texture_cache 1
setprop debug.sf.hwui.texture_cache_finalize 0
setprop debug.sf.hwui.texture_cache_finalization 0
setprop debug.sf.hwui.use_optimized_frame_buffer_cache 1
} > /dev/null 2>&1
#versi1
(
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.late.sf.duration 10500000
setprop debug.sf.late.app.duration 16600000
setprop debug.sf.treat_170m_as_sRGB 1
setprop debug.sf.earlyGl.app.duration 16600000
setprop debug.sf.frame_rate_multiple_threshold 120
setprop debug.boot.fps 20
setprop debug.performance.tuning 1
settings put system view.scroll_friction 0
settings put global windowsmgr.support_low_latency_touch true
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.disable_vsync true
settings put system haptic_feedback_intensity 50
settings put global tactile_feedback_enabled 1
setprop debug.sf.set_touch_timer_ms 100
setprop debug.MultitouchSettleInterval 0.01ms
setprop debyg.MultitouchMinDistance 0.01px
setprop debug.TapInterval 0.1ms
settings put global fw.bservice_enable true
settings put global fw.bg_apps_limit 4
settings put global fw.bservice_limit 4
settings put global fw.bservice_age 10000
setprop debug.touch.pressure.scale 0.001
setprop debug.touch_move_opt 1
setprop debug.touch_vsync_opt 1
setprop debug.touch.size.bias 0
setprop debug.TapSlop1px
settings put global windowsmgr.max_events_per_sec 180
settings put global min_pointer_dur 8
settings put global product.multi_touch_enabled true
settings put global securestorage.knox false
setprop debug.security.mdpp none
setprop debug.security.mdpp.result none
settings put system af.resampler.quality 255
settings put system scrollingcache 3
setprop debug.service.lgospd.enable 0
setprop debug.service.pcsync.enable 0
setprop debug.touch.deviceTypetouchScreen
cmd device_config put input default_key_press_repeat_rate 33
cmd device_config put input filtered_accel_event_rate_hz 240
cmd device_config put input touch_screen_sample_interval_ms 8
cmd device_config put systemui cg_frame_interval_millis 4
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui cg_max_frame_skip 8
settings put system service.touch.tpf 30
settings put system lowThreshold 0
settings put system highThreshold 0
settings put system VirtualKeyQuietTime 0
settings put system KeyRepeatDelay 0
settings put system KeyRepeatTimeout 0
setprop debug.boosterorientnosync 1
settings put global sf.disable_smooth_effect true
settings put secure touch_distance_scale 0
settings put secure view_scroll_friction 0
settings put secure multi_touch_enabled 1
settings put secure assist_touch_gesture_enabled 0
settings put global maximum_obscuring_opacity_for_touch 0.5
settings put system show_touches 0
settings put global block_untrusted_touches 0
settings put system vsync.disable.fps.limit 1
settings put system table.framerate 120
setprop debug.touch.deviceType touchScreen
settings put system disable.hwc.delay 1
settings put system Touc_xRotation  360
settings put system touchswipedeadzone 5
settings put system pointer_speed 7
settings put secure long_press_timeout 300
settings put secure multi_press_timeout 300
settings put secure touch_size_scale 5
settings put secure show_rotation_suggestions 0
settings put secure touch_size_bias 5
settings put secure touch_exploration_enabled 1
settings put secure touch_orientationAware 1
settings put secure touch_pressure_scale 0.00000125
settings put system touchscreen_hovering 0
settings put system touchscreen_sensitivity_mode 3
settings put system touchscreen_pressure_calibration 1023
settings put system touchscreen_threshold 9
settings put system touchfeature.gamemode.enable true
settings put system r.setframepace 120
settings put system touch_switch_set_touchscreen 14005
settings put system touchpanel_game_switch_enable 1
settings put system touchpanel_oppo_tp_direction 1
settings put system touchpanel_oppo_tp_limit_enable 0
settings put system touchpanel_oplus_tp_limit_enable 0
settings put system touchpanel_oplus_tp_direction 1
settings put system use_dithering 0
settings put system use_dithering false
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.1
settings put global DragMinSwitchSpeed 99999.0px/s
settings put global SwipeMaxWidthRatio 1
settings put system MovementSpeedRatio 1
settings put system ZoomSpeedRatio 1
settings put system SwipeTransitionAngleCosine 3.6
settings put system mot.proximity.distance 1
settings put system PointerVelocityControlParameters 1
settings put system device.internal 1
setprop debug.performance.tuning 1
setprop debug.egl.swapinterval 90
settings put secure dev.pm.dyn_samplingrate 1
settings put system touchscreen_sensitivity 10
settings put system touchscreen_min_press_time 50
settings put system touchscreen_hevoring 0
settings put system touchscreen_gesture_mode 1
settings put system touchscreen_pointer_speed 15
settings put system touchscreen_sensitivity_threshold 9
settings put system touchscreen_double_tap_speed 75
settings put system touchscreen_sensitivity_scale 1.5
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.6
settings put system touch.orientationAware 1
settings put system SurfaceOrientation auto
settings put system touch.size.calibration geometric
settings put system touch.size.scale auto
settings put system touch.size.isSummed 1
settings put system touch.orientation.calibration auto
settings put system touch.distance.scale auto
settings put system touch.coverage.calibration octagram
settings put system touch.gesturemode spots
settings put system MovementSpeedRatio auto
settings put system pm.dyn_samplingrate 9999999999999999999999999999
settings put system touch.pressure.calibration auto
settings put system scroll.accelerated.hw true
settings put system ui.hwframes 9999999999999999999999999999
settings put system force_high_end_gfx 1
settings put system sf.disable_smooth_effect true
settings put system max_num_touch auto
settings put system view.touch_slop 0dp
settings put system maxeventspersec 9999999999999999999999999999
settings put system resampler.quality 255
settings put system touch.sampling rate 720
settings put system adaptive_touch_sensitivity speed
settings put system touch.orientationAware 0
settings put system PressureForID 0.01
settings put system QuietInterval 0.1ms
settings put system MultitouchMinDistance 1px
settings put system AIM_SENSITIVITY_TRANSITION_TIME GRADUAL
settings put system APP_SWITCH_DELAY_TIME false
settings put system AbsoluteXForID SpeedForID
settings put system AccelerationX true
settings put system AccelerationY true
settings put system DoubleTouch OEM
settings put system PowerbuttonTapping 0
settings put system touch.assistant.enabled 0
settings put system type.touch_speed true
settings put system view.touch_slop 5
settings put system MovementSpeedRatio 0.8
settings put system accuracy.control 100
settings put system view_scroll_friction 10
settings put secure multi_press_timeout 300
settings put global KeyRepeatDelay 0
settings put global KeyRepeatTimeout 0
settings put global LOSS_OF_FOCUS_BY_MOUSE_MOVEMENT DISABLED
settings put global MOUSEX_AIM_LEVEL 95%
settings put global window_animation_scale 0.3
settings put global transition_animation_scale 0.3
settings put global animator_duration_scale 0.3
) > /dev/null 2>&1

#versi 2
(
setprop debug.touch.size.bias 0
setprop debug.MultitouchSettleInterval 1ms
setprop debug.TapInterval 1ms
setprop debug.TapSlop1px
settings put global windowsmgr.max_events_per_sec 180
settings put global min_pointer_dur 8
settings put global product.multi_touch_enabled true
settings put global securestorage.knox false
setprop debug.security.mdpp none
setprop debug.security.mdpp.result none
settings put system af.resampler.quality 255
settings put system scrollingcache 3
setprop debug.service.lgospd.enable 0
setprop debug.service.pcsync.enable 0
setprop debug.touch.deviceTypetouchScreen
cmd device_config put input default_key_press_repeat_rate 33
cmd device_config put input filtered_accel_event_rate_hz 240
cmd device_config put input touch_screen_sample_interval_ms 8
cmd device_config put systemui cg_frame_interval_millis 4
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui cg_max_frame_skip 8
settings put system service.touch.tpf 30
settings put system lowThreshold 0
settings put system highThreshold 0
settings put system VirtualKeyQuietTime 0
settings put system KeyRepeatDelay 0
settings put system KeyRepeatTimeout 0
setprop debug.boosterorientnosync 1
settings put global sf.disable_smooth_effect true
settings put secure touch_distance_scale 0
settings put secure view_scroll_friction 0
settings put secure multi_touch_enabled 1
settings put secure assist_touch_gesture_enabled 0
settings put global maximum_obscuring_opacity_for_touch 0.5
settings put system show_touches 0
settings put global block_untrusted_touches 0
settings put system vsync.disable.fps.limit 1
settings put system table.framerate 120
settings put system view.scroll_friction 0.0001
setprop debug.touch.deviceType touchScreen
settings put system disable.hwc.delay 1
settings put system Touc_xRotation  360
settings put system touchswipedeadzone 5
settings put system pointer_speed 7
settings put secure long_press_timeout 300
settings put secure multi_press_timeout 300
settings put secure touch_size_scale 5
settings put secure show_rotation_suggestions 0
settings put secure touch_size_bias 5
settings put secure touch_exploration_enabled 1
settings put secure touch_orientationAware 1
settings put secure touch_pressure_scale 0.00000125
settings put system touchscreen_hovering 0
settings put system touchscreen_sensitivity_mode 3
settings put system touchscreen_pressure_calibration 1023
settings put system touchscreen_threshold 9
settings put system touchfeature.gamemode.enable true
settings put system r.setframepace 120
settings put system touch_switch_set_touchscreen 14005
settings put system touchpanel_game_switch_enable 1
settings put system touchpanel_oppo_tp_direction 1
settings put system touchpanel_oppo_tp_limit_enable 0
settings put system touchpanel_oplus_tp_limit_enable 0
settings put system touchpanel_oplus_tp_direction 1
settings put system use_dithering 0
settings put system use_dithering false
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.1
settings put global DragMinSwitchSpeed 99999.0px/s
settings put global SwipeMaxWidthRatio 1
settings put system MovementSpeedRatio 1
settings put system ZoomSpeedRatio 1
settings put system SwipeTransitionAngleCosine 3.6
settings put system mot.proximity.distance 1
settings put system PointerVelocityControlParameters 1
settings put system device.internal 1
setprop debug.performance.tuning 1
setprop debug.egl.swapinterval 90
settings put secure dev.pm.dyn_samplingrate 1
settings put system touchscreen_sensitivity 10
settings put system touchscreen_min_press_time 50
settings put system touchscreen_hevoring 0
settings put system touchscreen_gesture_mode 1
settings put system touchscreen_pointer_speed 15
settings put system touchscreen_sensitivity_threshold 9
settings put system touchscreen_double_tap_speed 75
settings put system touchscreen_sensitivity_scale 1.5
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.6
settings put system touch.orientationAware 1
settings put system SurfaceOrientation auto
settings put system touch.size.calibration geometric
settings put system touch.size.scale auto
settings put system touch.size.isSummed 1
settings put system touch.orientation.calibration auto
settings put system touch.distance.scale auto
settings put system touch.coverage.calibration octagram
settings put system touch.pressure.scale 0.0001
settings put system touch.gesturemode spots
settings put system MultitouchMinDistance auto
settings put system MovementSpeedRatio auto
settings put system pm.dyn_samplingrate 9999999999999999999999999999
settings put system touch.pressure.calibration auto
settings put system scroll.accelerated.hw true
settings put system ui.hwframes 9999999999999999999999999999
settings put system force_high_end_gfx 1
settings put system sf.disable_smooth_effect true
settings put system max_num_touch auto
settings put system view.touch_slop 0dp
settings put system maxeventspersec 9999999999999999999999999999
settings put system resampler.quality 255
settings put system touch.sampling rate 720
settings put system adaptive_touch_sensitivity speed
settings put system touch.orientationAware 0
settings put system PressureForID 0.01
settings put system QuietInterval 0.1ms
settings put system MultitouchMinDistance 1px
settings put system AIM_SENSITIVITY_TRANSITION_TIME GRADUAL
settings put system APP_SWITCH_DELAY_TIME false
settings put system AbsoluteXForID SpeedForID
settings put system AccelerationX true
settings put system AccelerationY true
settings put system DoubleTouch OEM
settings put system PowerbuttonTapping 0
settings put system touch.assistant.enabled 0
settings put system type.touch_speed true
settings put system view.touch_slop 5
settings put system MovementSpeedRatio 0.8
settings put system accuracy.control 100
settings put system view_scroll_friction 10
settings put secure multi_press_timeout 300
settings put global KeyRepeatDelay 0
settings put global KeyRepeatTimeout 0
settings put global LOSS_OF_FOCUS_BY_MOUSE_MOVEMENT DISABLED
settings put global MOUSEX_AIM_LEVEL 95%
settings put global window_animation_scale 0.3
settings put global transition_animation_scale 0.3
settings put global animator_duration_scale 0.3
) > /dev/null 2>&1