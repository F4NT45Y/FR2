z="
";vz='o.ve';oEz='nfo ';bDz='esac';dBz='info';nEz='memi';ABz='_nam';VEz='p Sw';tDz='(una';jBz='l_mt';PEz='0) "';HBz='2=$(';wz='ndor';fBz='l_un';BBz='e)';MDz='harg';bz='.ven';UBz='core';PBz='ipna';bBz='proc';yz='.soc';mEz='roc/';OCz='$2}'\''';TCz='batt';eCz='wk '\''';pz='ardw';kDz=' tr ';lBz='del)';MBz='del.';Yz='actu';CDz='atus';ZBz='cess';SBz='pnam';FDz='tatu';nDz=' | w';DEz='e | ';Kz='manu';uBz='prop';rDz='ersi';oBz='r.qt';UCz='ery_';VCz='leve';dz='soc.';Sz='nufa';OBz='o.ch';QBz='me)';Jz='cpu_';NCz='int ';QEz=' men';rz='chip';nCz=' bat';gCz='nt $';GDz='s="U';kz='ture';QDz='s="D';cDz='sens';sCz=' awk';tBz='(get';yDz='(cat';ZCz='ery ';iz='_man';nz='rop ';bEz='o | ';mCz='psys';lz='r=$(';uEz='" MB';tCz=' '\''{p';iCz='"}'\'')';pDz='kern';LCz='R==2';vCz=' $2}';uCz='rint';kCz='us=$';qz='are.';AEz=' /pr';uz='name';GEz='int(';xBz='uct.';XDz='5) s';jEz=' Swa';jz='ufac';Bz='d_br';ZDz='ull"';yBz='oplu';GCz='df -';jCz='stat';LEz=' int';UDz='4) s';mDz=''\''\n'\''';UEz='(gre';QCz='labl';JEz=' " j';iBz='el)';Nz='=$(g';bCz='ep l';az='p ro';gDz='rdwa';dCz=' | a';hCz='2 "%';Lz='fact';GBz='nal_';MCz=' {pr';DBz='.mod';cBz='/cpu';RBz='_chi';vBz=' ro.';CCz='o)';Vz='vend';pBz='i.so';BCz='uinf';oCz='tery';aCz='| gr';Pz='op r';wBz='prod';tz='qti_';KCz='k '\''N';NBz='part';rCz='us |';Fz='p Bu';gEz='free';CEz='ptim';xz='.qti';Gz='ild.';BDz='y_st';XEz='tal ';EDz='1) s';WEz='apTo';FEz=''\''{pr';ECz='l_st';fDz='o.ha';TDz='ng" ';Wz='or_m';oDz='c -l';Rz='c.ma';DDz=' in';qDz='el_v';hDz='re.s';KDz='2) s';pEz='k '\''{';hBz='sal=';eDz='ount';Zz='rer=';qEz='prin';tEz='024 ';YDz='s="F';RDz='isch';JDz=';;';XCz='dump';wDz='upti';kEz='pFre';Mz='urer';fCz='{pri';nBz='i=$(';gBz='iver';FCz='orag';HCz='h /d';sEz=' / 1';YCz='sys ';ACz='s.cp';RCz='e_st';TBz='e=$(';Uz='er)';Ez='tpro';HDz='nkno';ADz='tter';aDz='*) s';CBz='mtk_';SCz='$4}'\''';TEz='ap=$';fz='hard';VBz='s=$(';Qz='o.so';WCz='l=$(';SDz='argi';wCz=''\'')';EEz='awk ';DCz='tota';hEz='_swa';ez=')';Oz='etpr';cz='dor.';pCz=' | g';eEz='4 " ';HEz='$1/3';sDz='on=$';Cz='and=';hz='_soc';dEz=' 102';mz='getp';aBz='or /';JBz='endo';PCz='avai';gz='ware';dDz='or_c';LBz='c.mo';ZEz='c/me';iEz='p=$(';vDz='r)';Az='buil';xCz='case';IDz='wn" ';jDz='rs |';JCz='| aw';YEz='/pro';rEz='t $2';rBz='l_op';REz='it"}';Iz='D)';lCz='(dum';Tz='ctur';oz='ro.h';yCz=' $ba';Xz='anuf';qBz='c_mo';xDz='me=$';kBz='k=$(';fEz='MB"}';SEz='l_sw';eBz='mode';NDz='ing"';sz='set_';IBz='ro.v';FBz='xter';iDz='enso';NEz='%360';ICz='ata ';mBz='l_qt';VDz='s="N';KBz='r.so';BEz='oc/u';WDz='ot C';OEz='0)/6';lEz='e /p';Hz='BRAN';Dz='$(ge';ODz=' ;;';PDz='3) s';WBz='grep';aEz='minf';LDz='s="C';qCz='rep ';KEz='am "';cCz='evel';YBz='^pro';lDz=''\'','\'' ';uDz='me -';IEz='600)';EBz='el.e';cEz='$2 /';XBz=' -c ';MEz='(($1';sBz='po=$';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$z$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$z$Jz$Vz$Wz$Xz$Yz$Zz$Dz$Ez$az$bz$cz$dz$Kz$Lz$Mz$ez$z$fz$gz$hz$iz$jz$kz$lz$mz$nz$oz$pz$qz$dz$Kz$Lz$Mz$ez$z$rz$sz$tz$uz$Nz$Oz$Pz$vz$wz$xz$yz$ABz$BBz$z$rz$sz$CBz$uz$Nz$Oz$Pz$vz$wz$yz$DBz$EBz$FBz$GBz$uz$ez$z$rz$sz$CBz$uz$HBz$mz$nz$IBz$JBz$KBz$LBz$MBz$NBz$ABz$BBz$z$Jz$rz$uz$Nz$Oz$Pz$OBz$PBz$QBz$z$Jz$fz$gz$RBz$SBz$TBz$mz$nz$oz$pz$qz$rz$uz$ez$z$Jz$UBz$VBz$WBz$XBz$YBz$ZBz$aBz$bBz$cBz$dBz$ez$z$Jz$eBz$fBz$gBz$hBz$Dz$Ez$az$yz$DBz$iBz$z$Jz$eBz$jBz$kBz$mz$nz$IBz$JBz$KBz$LBz$lBz$z$Jz$eBz$mBz$nBz$mz$nz$IBz$JBz$oBz$pBz$qBz$lBz$z$Jz$eBz$rBz$sBz$tBz$uBz$vBz$wBz$xBz$yBz$ACz$BCz$CCz$z$DCz$ECz$FCz$TBz$GCz$HCz$ICz$JCz$KCz$LCz$MCz$NCz$OCz$ez$z$PCz$QCz$RCz$FCz$TBz$GCz$HCz$ICz$JCz$KCz$LCz$MCz$NCz$SCz$ez$z$TCz$UCz$VCz$WCz$XCz$YCz$TCz$ZCz$aCz$bCz$cCz$dCz$eCz$fCz$gCz$hCz$iCz$z$TCz$UCz$jCz$kCz$lCz$mCz$nCz$oCz$pCz$qCz$jCz$rCz$sCz$tCz$uCz$vCz$wCz$z$xCz$yCz$ADz$BDz$CDz$DDz$z$EDz$FDz$GDz$HDz$IDz$JDz$z$KDz$FDz$LDz$MDz$NDz$ODz$z$PDz$FDz$QDz$RDz$SDz$TDz$JDz$z$UDz$FDz$VDz$WDz$MDz$NDz$ODz$z$XDz$FDz$YDz$ZDz$ODz$z$aDz$FDz$GDz$HDz$IDz$JDz$z$bDz$z$cDz$dDz$eDz$Nz$Oz$Pz$fDz$gDz$hDz$iDz$jDz$kDz$lDz$mDz$nDz$oDz$ez$z$pDz$qDz$rDz$sDz$tDz$uDz$vDz$z$wDz$xDz$yDz$AEz$BEz$CEz$DEz$EEz$FEz$NCz$GEz$HEz$IEz$JEz$KEz$LEz$MEz$NEz$OEz$PEz$QEz$REz$wCz$z$DCz$SEz$TEz$UEz$VEz$WEz$XEz$YEz$ZEz$aEz$bEz$EEz$FEz$NCz$cEz$dEz$eEz$fEz$wCz$z$gEz$hEz$iEz$WBz$jEz$kEz$lEz$mEz$nEz$oEz$JCz$pEz$qEz$rEz$sEz$tEz$uEz$iCz"
echo ""
echo "░██████╗░█████╗░██╗░░░██╗███████╗ 
██╔════╝██╔══██╗██║░░░██║██╔════╝ 
╚█████╗░███████║╚██╗░██╔╝█████╗░░ 
░╚═══██╗██╔══██║░╚████╔╝░██╔══╝░░ 
██████╔╝██║░░██║░░╚██╔╝░░███████╗ 
╚═════╝░╚═╝░░╚═╝░░░╚═╝░░░╚══════╝ 
██████╗░░█████╗░████████╗██████╗░███████╗██╗ 
██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██╔════╝██║ 
██████╦╝███████║░░░██║░░░██████╔╝█████╗░░██║ 
██╔══██╗██╔══██║░░░██║░░░██╔══██╗██╔══╝░░██║ 
██████╦╝██║░░██║░░░██║░░░██║░░██║███████╗██║ 
╚═════╝░╚═╝░░╚═╝░░░╚═╝░░░╚═╝░░╚═╝╚══════╝╚═╝ 
"
    sleep 1
    echo "-------------------------------------------------------------------------"
    echo "  • INFORMASI DEVICE"
    echo "-------------------------------------------------------------------------"
    sleep 0.5
    echo "  • ANDROID SDK        ➜ $(getprop ro.build.version.sdk)"
    sleep 0.5
    echo "  • ANDROID VERSION    ➜ $(getprop ro.build.version.release)"
    sleep 0.5
    echo "  • DEVICE MODEL       ➜ $(getprop ro.product.model)"
    sleep 0.5
    echo "  • BRAND              ➜ $(getprop ro.product.brand)"
    sleep 0.5
    echo "  • NAMA DEVICE        ➜ $(getprop persist.sys.devicename)"
    sleep 0.5
    echo "  • HARDWARE           ➜ $(getprop ro.hardware)"
    sleep 0.5
    echo "  • GPU                ➜ $(getprop ro.opengles.version)"
    sleep 0.5
    echo "  • CPU                ➜ $(getprop ro.product.cpu.abi)"
    sleep 0.5
    echo "  • RAM                ➜ $(cat /proc/meminfo | grep MemTotal | awk '{print $2}')"
    sleep 0.5
    echo "  • RAM TERSEDIA       ➜ $(grep MemAvailable /proc/meminfo | awk '{print $2 / 1024 " MB"}')"
    sleep 0.5
    echo "  • MANUFACTURER       ➜ $cpu_manufacturer $cpu_vendor_manufacturer $hardware_soc_manufacturer"
    sleep 0.5
    echo "  • SOC NAME           ➜$chipset_qti_name $chipset_mtk_name $chipset_mtk_name2 $cpu_chipname $cpu_hardware_chipname"
    sleep 0.5
    echo "  • SOC MODEL          ➜ $cpu_model_universal $cpu_model_mtk $cpu_model_qti $cpu_model_oppo"    
    sleep 0.5
    echo "  • PENYIMPANAN TOTAL  ➜ $total_storage"
    sleep 0.5
    echo "  • PENYIMPANAN        ➜ $available_storage"
    sleep 0.5
    echo "  • VIRTUAL RAM TOTAL  ➜ $total_swap"
    sleep 0.5
    echo "  • VIRTUAL RAM BEBAS  ➜ $free_swap"
    sleep 0.5
    echo "  • BATERAI            ➜ $battery_level ($status)"
    sleep 0.5
    echo "  • JUMLAH SENSOR      ➜ $sensor_count"
    sleep 0.5
    echo "  • VERSI KERNEL       ➜ $kernel_version"
    sleep 0.5
    echo "  • UPTIME             ➜ $uptime"
    sleep 0.5
    echo "-------------------------------------------------------------------------"
    echo ""
    echo "-------------------------------------------------------------------------"
    echo "UNINSTALL MODULE"
    echo "-------------------------------------------------------------------------"
##################################################################
pm enable com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm enable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
dumpsys deviceidle whitelist -com.google.android.gms
pm disable com.google.android.gms/.chimera.GmsIntentOperationService > /dev/null 2>&1
settings delete global activity_starts_logging_enabled
settings delete global ble_scan_always_enabled
settings delete global hotword_detection_enabled
settings delete global mobile_data_always_on
settings delete global network_recommendations_enabled
settings delete global wifi_scan_always_enabled
settings delete secure adaptive_sleep
settings delete secure screensaver_activate_on_dock
settings delete secure screensaver_activate_on_sleep
settings delete secure screensaver_enabled
settings delete secure send_action_app_error
settings delete system air_motion_engine
settings delete system air_motion_wake_up
settings delete system intelligent_sleep_mode
settings delete system master_motion
settings delete system motion_engine
settings delete system nearby_scanning_enabled
settings delete system nearby_scanning_permission_allowed
settings delete system rakuten_denwa
settings delete system send_security_reports
settings delete global cached_apps_freezer
settings delete global sem_enhanced_cpu_responsiveness
settings delete global enhanced_processing
settings delete global app_standby_enabled
settings delete global adaptive_battery_management_enabled
settings delete global app_restriction_enabled
settings delete system intelligent_sleep_mode
settings delete secure adaptive_sleep
settings delete global automatic_power_save_mode
settings delete global low_power
settings delete global dynamic_power_savings_enabled
settings delete global dynamic_power_savings_disable_threshold
settings delete system master_motion
settings delete system motion_engine
settings delete system air_motion_engine
settings delete system air_motion_wake_up
settings delete system intelligent_sleep_mode
settings delete secure adaptive_sleep
settings delete secure wake_locks_enabled
settings delete secure location_scanning_interval
settings delete global wifi_sleep_policy
settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete secure doze_always_on
settings delete secure alarm_manager_constants
# Uninstall for Activity Manager Constants
settings delete global activity_manager_constants

# Uninstall for Power Management Constants
settings delete global memory_constants

# Uninstall for App Optimization
settings delete global app_process_constants

# Uninstall for Doze Mode
settings delete global doze_constants

# Uninstall for Vibration Settings
settings delete global vibration_constants

# Uninstall for Job Scheduler & Alarm Settings
settings delete global job_scheduler_constants

# Uninstall for Network Management
settings delete global network_management_constants

# Uninstall for Binder Calls Stats
settings delete global binder_calls_stats

# Uninstall for Foreground Service
settings delete global fg_service_constants

# Uninstall for Backup
settings delete secure backup_manager_constants

# Uninstall for Battery Manager
settings delete global battery_manager_constants

# Uninstall for Miscellaneous
settings delete global appop_history_parameters
settings delete global autofill_compat_mode_allowed_packages
settings delete global location_ignore_settings_package_whitelist

# Uninstall for Gaming Performance
settings delete global cpu_gpu_constants
settings delete global dynamic_frequency_scaling_constants
settings delete global gaming_memory_constants
settings delete global gaming_power_constants
pm enable --user 0 com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm enable --user 0 com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm enable com.google.android.gms/.chimera.GmsIntentOperationService > /dev/null 2>&1
settings put global activity_starts_logging_enabled 1
settings put global ble_scan_always_enabled 1
settings put global hotword_detection_enabled 1
settings put global mobile_data_always_on 1
settings put global network_recommendations_enabled 1
settings put global wifi_scan_always_enabled 1
settings delete secure adaptive_sleep
settings delete secure screensaver_activate_on_dock
settings delete secure screensaver_activate_on_sleep
settings delete secure screensaver_enabled
settings delete secure send_action_app_error
settings delete system air_motion_engine
settings delete system air_motion_wake_up
settings delete system intelligent_sleep_mode
settings delete system master_motion
settings delete system motion_engine
settings delete system nearby_scanning_enabled
settings delete system nearby_scanning_permission_allowed
settings delete system rakuten_denwa
settings delete system send_security_reports
settings delete global cached_apps_freezer
settings delete global sem_enhanced_cpu_responsiveness
settings delete global enhanced_processing
settings put global app_standby_enabled 1
settings put global adaptive_battery_management_enabled 1
settings put global app_restriction_enabled false
settings delete system intelligent_sleep_mode
settings delete secure adaptive_sleep
settings put global automatic_power_save_mode 1
settings put global low_power 0
settings put global dynamic_power_savings_enabled 1
settings delete global dynamic_power_savings_disable_threshold
settings delete system master_motion
settings delete system motion_engine
settings delete system air_motion_engine
settings delete system air_motion_wake_up
settings delete system intelligent_sleep_mode
settings delete secure adaptive_sleep
settings delete secure wake_locks_enabled
settings delete secure location_scanning_interval
settings put global wifi_sleep_policy 0
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0
settings put secure doze_always_on 0
settings delete secure alarm_manager_constants
setprop debug.sv.disable.pers.cache false
setprop debug.sv.config.disable_rtt false
setprop debug.sv.config.stats 1
setprop debug.sv.log.slow_query_threshold 100
setprop debug.sv.atrace.tags.enableflags true
setprop debug.sv.egl.profiler 1
setprop debug.sv.enable.gamed true
setprop debug.sv.enable.wl_log true
setprop debug.sv.hwc.otf 1
setprop debug.sv.hwc_dump_en 1
setprop debug.sv.mdpcomp.logs 1
setprop debug.sv.qualcomm.sns.daemon 1
setprop debug.sv.qualcomm.sns.libsensor1 1
setprop debug.sf.ddms 1
setprop debug.sf.disable_client_composition_cache 0
setprop debug.sf.dump 1
setprop debug.sv.sqlite.journalmode WAL
setprop debug.sv.test 1
setprop debug.sv.libc.debug.malloc 1
setprop debug.sv.log.shaders 1
setprop debug.sv.log.tag.all 1
setprop debug.sv.log.tag.stats_log 1
setprop debug.sv.log_ao 1
setprop debug.sv.log_frame_info 1
setprop debug.sv.logd.logpersistd.enable true
setprop debug.sv.logd.statistics 1
setprop debug.sv.media.metrics.enabled true
setprop debug.sv.media.metrics 1
setprop debug.sv.media.stagefright.log-uri 1
setprop debug.sv.net.ipv4.tcp_no_metrics_save 0
setprop debug.sv.anr.dumpthr 1
setprop debug.sv.persist.camera.debug.logfile 1
setprop debug.sv.camera.iface.logs 1
setprop debug.sv.camera.imglib.logs 1
setprop debug.sv.camera.isp.debug 1
setprop debug.sv.camera.mct.debug 1
setprop debug.sv.camera.sensor.debug 1
setprop debug.sv.data.qmi.adb_logmask 0xFFFFFFFF
setprop debug.sv.sensors.hal 1
setprop debug.sv.wfd.enable true
setprop debug.sv.disable_inline_rotator false
setprop debug.sv.disable_skip_validate false
setprop debug.sv.miui.ndcd true
setprop debug.sv.wifitracing.started 1
setprop debug.sv.fm.a2dp.conc.disabled false
setprop debug.sv.vendor.vidc.debug.level 1
setprop debug.sv.vendor.vidc.enc.disable_bframes false
setprop debug.sv.vidc.debug.level 1
setprop debug.sv.video.disable.ubwc false
cmd thermalservice override-status 1 > /dev/null 2>&1
cmd power set-fixed-performance-mode-enabled 0 > /dev/null 2>&1
cmd power set-adaptive-power-saver-enabled 1 > /dev/null 2>&1
cmd power set-mode 0
settings put global low_power 0
setprop persist.sys.bg_daemon_enable true
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0
pm enable-user --user 0 com.google.android.location.fused
pm enable-user --user 0 com.google.android.gms.location.history
pm enable-user --user 0 com.google.android.location.fused
pm enable-user --user 0 com.google.android.gms.location.history
settings put system POWER_PERFORMANCE_MODE_OPEN 0
cmd power set -fixed-performance-mode-enabled 0
cmd power set -adaptive-power-saver-enabled 1
cmd power set -mode 0
settings put system POWER_PERFORMANCE_MODE_OPEN 1
settings put system POWER_BALANCED_MODE_OPEN 0
settings put system POWER_SAVE_MODE_OPEN 0       
    echo "-------------------------------------------------------------------------"
    echo "ALL DONE"
    echo "-------------------------------------------------------------------------"