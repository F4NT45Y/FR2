
(
#Set Zram
settings put global zram_enabled 1
settings put global ram_expand_size 10240
#Maximal Zram Config 
settings put global activity_manager_constants max_cached_processes 8
settings put global app_standby_enabled true
settings put global cached_app_lru_limit 16
) > /dev/null 2>&1
(
#New
settings put global config.spcm_enable false
settings put global config.spcm_kill_skip true
settings put global config.samp_spcm_enable false
settings put global config.spcm_db_enable false
settings put global config.spcm_db_launcher false
settings put global config.spcm_preload_enable false
settings put global config.spcm_gcm_kill_enable false
settings put global config.dha_cached_max 16
settings put global config.dha_empty_max 42
settings put global config.dha_empty_init 32
settings put global config.dha_lmk_scale 0.545
settings put global config.dha_th_rate 2.3
settings put global config.sdha_apps_bg_max 64
settings put global config.sdha_apps_bg_min 8
settings put global transition_animation_scale 0.5
settings put global window_animation_scale 0.5
settings put global animator_duration_scale 0.5
# Untuk RAM 2GB - 4GB
settings put global activity_manager_constants max_cached_processes=10
settings put global activity_manager_constants max_phantom_processes 5
settings put global activity_manager_constants bg_low_mem_mult 1
settings put global activity_manager_constants cur_max_cached_processes 8
settings put global low_ram true
settings put global force_low_ram_device true
settings put system sys.haptic.low_ram true
settings put global swap_free_low_percentage 5
settings put global zram_enable true
settings put global zram_size 512
settings put global lmk_minfree 4096,8192,12288,16384,20480,24576
settings put global lmk_upgrade_pressure 80
settings put global lmk_downgrade_pressure 25
#Melegakan Ram 
am kill-all
settings put global limit_background_processes 2
settings put system vm_drop_caches 1
# Stop Tombstoned
stop tombstoned
am kill tombstoned
killall -9 tombstoned
settings put system force_all_apps_stopped 1
cmd activity force-stop "$app"
pm disable com.android.shell.tombstoned
# Reduce Resource Consumption
settings put system air_motion_engine 0
settings put system air_motion_wake_up 0
settings put global activity_starts_logging_enabled 0
settings put global ble_scan_always_enabled 0
settings put global hotword_detection_enabled 0
settings put global mobile_data_always_on 0
settings put global network_recommendations_enabled 0
settings put global wifi_scan_always_enabled 0
settings put secure adaptive_sleep 0
settings put secure screensaver_activate_on_dock 0
settings put secure screensaver_activate_on_sleep 0
settings put secure screensaver_enabled 0
settings put secure send_action_app_error 0
settings put system intelligent_sleep_mode 0
settings put system master_motion 0
settings put system motion_engine 0
settings put system nearby_scanning_enabled 0
settings put system nearby_scanning_permission_allowed 0
settings put system rakuten_denwa 0
settings put system send_security_reports 0
) > /dev/null 2>&1 &

sleep 2
(
for app in $(cmd package list packages -3 | cut -f 2 -d ":"); do
if [[ ! "$app" == "me.piebridge.brevent" ]] && \
   [[ ! "$app" == "eu.sisik.hackendebug" ]] && \
   [[ ! "$app" == "com.whatsapp" ]] && \
   [[ ! "$app" == "com.omarea.vtools" ]] && \
   [[ ! "$app" == "com.miHoYo.GenshinImpact" ]] && \
   [[ ! "$app" == "com.dts.freefiremax" ]] && \
   [[ ! "$app" == "com.dts.freefireth" ]] && \
   [[ ! "$app" == "com.tencent.ig" ]] && \
   [[ ! "$app" == "com.vexiro.tweak" ]] && \
   [[ ! "$app" == "com.mobile.legends" ]]; then
   echo "Force stop $app"
   cmd activity force-stop "$app"
   sleep 1
   echo ""
fi
done
) > /dev/null 2>&1 & 