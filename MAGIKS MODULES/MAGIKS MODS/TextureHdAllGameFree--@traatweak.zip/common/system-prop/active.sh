# Tweak
{
    #Setedit
    pm grant by4a.setedit22 android.permission.WRITE_SETTINGS
    pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
    pm grant by4a.setedit22 android.permission.WRITE_GLOBAL_SETTINGS
    
    #Tweak
    pm disable com.xiaomi.joyouse
    dumpsys deviceidle disable
    
    # Settings put
    settings put global device_name "iPhone 16 Pro Max"
    settings put global performance_mode 1 # Mode performa diaktifkan
    settings put global thermal_mode 0 # Mematikan mode thermal
    settings put system battery_saver_performance_mode 0 # Mode penghemat baterai dimatikan
    settings put global game_mode 1 #, Mode Game di Aktifkan
    settings put system game_mode_enabled 1 # Mode game diaktifkan
    settings put global game_latency 0 
    settings put global background_process_limit 4
    settings put system background_process_limit 4
    settings put global hardware_acceleration_mode 1
    settings put system rt_templimit_ceiling 100 
    settings put system tran_default_temperature_index 0 
    settings put secure game_auto_temperature_control 0
    settings put global game_temperature_control 0
    settings put global high_temp_limit 100 
    settings put global low_temp_limit 10 
    settings put global thermal_offload 0 
    settings put global thermal_throttling_enable 0
    settings put global tran_temp_battery_warning 0
    settings put system game.accelerate.hw 1
    settings put system high_performance_mode_on 1
    settings put system screen_game_mode 1 
    settings put system speed_mode 1 
    settings put system touch.feature.gamemode.enable 1 
    settings put system video.accelerate.hw 1
    settings put secure high_priority 1 
    settings put secure miui_optimization 1
    settings put secure speed_mode_enable 1
    settings put secure sysui_tuner_version 4 
    settings put secure support_highfps 1
    settings put secure thermal_temp_state_vaule 0
    settings put secure gamebooster_data_migration 1
    settings put secure gamebooster_remove_desktop_icon 1
    settings put secure gb_boosting 0
    settings put secure miui_updater_enable 0
    settings put secure pref_open_game_booster 1
    settings put global device_name "iPhone 16 Pro Max"
    settings put global dont.lower.fps 1
    settings put global enable.hw_accel 1 
    settings put global enable_hardware_acceleration 1
    settings put global foreground_mem_priority high 
    settings put global fps_governor performance
    settings put global fps_divisor -1 
    settings put global force_hw_ui 1 
    settings put global gpu.fps auto
    settings put global gm_game_mode_state 2 
    settings put global hardware_acceleration_mode 1
    settings put global hardware_accelerated_rendering_enabled 1 
    settings put global hardware_accelerated_graphics_decoding 1 
    settings put global hardware_accelerated_video_decode 1 
    settings put global hardware_accelerated_video_encode 1 
    settings put global media.sf.hwaccel 1
    settings put global os_game_assistant_panel 1 
    settings put global ram_expand_size_list 16
    settings put global restricted_device_performance 0,1
    settings put global stabilizer.fps 1
    settings put global stable.fps.enable 1
    settings put global sampling_profiler 1 
    settings put global speed_mode_on 1
    settings put global thermal_throttling_enable 0
    settings put global transsion_anti_inadvertently 0 
    settings put global transsion_brightness 0 
    settings put global transsion_game_acceleration 1 
    settings put global transsion_game_brightness 0 
    settings put global transsion_game_mode 1 
    settings put global transsion_game_mode_not_interrupt 0 
    settings put global transsion_game_tws_mode 1 
    settings put global zram_enabled 1 
    settings put global cpu_boost_on_game_enable 1
    settings put global gpu_performance_mode_enable 1
    settings put global render_resolution_quality high
    settings put global touch_boost_enable 1
    settings put global gfx_boost_enable 1
    settings put global network_latency_optimization_enable 1
    settings put global game_low_latency_mode 1 
    settings put global game_driver_mode 1
    settings put global game_driver_opt_out_apps 1
    settings put global game_bypass_charging 0 
    settings put global game_barrage_speed 2 
    settings put global game_mode 1
    settings put global game_driver_all_apps 1
    settings put global game_driver_opt_in_apps 0
    settings put global game_driver_opt_out_apps 0
    settings put global game_driver_prerelease_opt_in_apps 0
    settings put global performance_mode enabled
    settings put global game_driver_mode high_performance
    settings put global force_gpu_rendering 1
    settings put global enable_gpu_debug_layers 0
    settings put global gpu_debug_app 0
    settings put global gpu_debug_layer_app 0
    settings put global gpu_debug_layers 0
    settings put global gpu_debug_layers_vk 0
    settings put global gpu_debug_layers_gles 0
    settings put global enable_vulkan 0
    settings put global gpu_debug_layers_vulkan 0
    settings put global gpu_debug_profile_app 0
    settings put global gpu_debug_layers_gles2 0
    settings put global enable_msaa 0
    settings put global gpu_updatable_driver_enable 0
    settings put global gpu_updatable_driver_allowlist 0
    settings put global updatable_driver_all_apps 0
    settings put global updatable_driver_prerelease_opt_in_apps 0
    settings put global updatable_driver_production_allowlist 0
    settings put global updatable_driver_production_denylist null
    settings put global updatable_driver_production_opt_in_apps 0
    settings put global updatable_driver_production_opt_out_apps 0
    settings put global gpu_overdraw_show_count 4
    settings put global persist.sys.tran.otg.preference 1
    settings put system debug.force_gpu_rendering 1
    settings put global fstrim_enabled 1
    settings put global fstrim_interval 86400
    settings put global fstrim_mandatory_interval 1
    settings put global fstrim_flags 1
    settings put global fstrim_critical_interval 0
    settings put global fstrim_battery_threshold 0
    settings put global fstrim_delay 0
    settings put global fstrim_purge 1
    settings put global fpsgo_support_status enable
    settings put global fpsgo_enable 1
    settings put global fpsgo_priority 2
    settings put global fpsgo_mode 1
    settings put global fpsgo_logging 1
    settings put global fpsgo_fps_limit 144
    settings put global fpsgo_tolerance 10
    settings put global fpsgo_cpu_optimization 1
    settings put global fpsgo_gpu_optimization 1
    settings put global fpsgo_optimization_time 1440
    settings put global fpsgo_cpu_threshold 99
    settings put global fpsgo_gpu_threshold 99
    settings put global fpsgo_low_power_mode 1
    settings put global fpsgo_sensitivity 5
    settings put system mispeed_authorized_pkg_list com.tencent.mm,mm.tencent.com.comtencentmmhardcodertest
    settings put system miui_recents_show_mem_info 1
    settings put system screen_optimize_mode 1
    settings put secure freeform_window_state -1
    settings put secure support_gesture_shortcut_settings 1
    settings put secure systemui_fsgesture_support_superpower 1
    settings put secure xspace_enabled 1
    settings put system pointer_speed 7
    settings put secure sysui_tuner_version 4
    
    # Tweak Fstrim
    pm trim-caches 999G
    sm fstrim
    cmd shortcut reset-throttling
    cmd shortcut reset-all-throttling
    pm clear com.miui.powerkeeper
} > /dev/null 2>&1

# Definisikan daftar paket game
game_packages="com.je.supersus,com.ea.gp.maddennfl21mobile,com.gravity.roo.sea,com.sega.pjsekai,com.gameark.ggplay.lonsea,com.nekki.shadowfightarena,com.pubg.krmobile,com.WandaSoftware.TruckersofEurope3,com.maleo.bussimulatorid,com.gameloft.android.ANMP.GloftA9HM,com.legotca.gwb,com.natsume.home,com.winlator,com.HoYoverse.Nap,com.excelliance.multiaccounts,com.mojang.minecraftpe.patch,com.kakaogames.gdts,xyz.aethersx2.android,com.zane.stardewvalley,com.lilithgame.roc.gp,jp.konami.pesam,net.kdt.pojavlaunch.zh,com.miHoYo.GenshinImpact,com.miHoYo.bh3oversea,com.mobile.legends,com.tencent.ig,com.garena.game.codm,com.dts.freefireth,com.kurogame.gplay.punishing.grayraven.en,com.dts.freefiremax,com.mobilelegends.mi,com.proximabeta.mf.uamo,com.proximabeta.mf.liteuamo,com.netease.newspike,com.activision.callofduty.warzone,com.carxtech.sr,com.miraclegames.farlight84,com.ea.gp.fifamobile,com.levelinfinite.sgameGlobal,com.tencent.iglite,com.GlobalSoFunny.Sausage,com.netmarble.sololv,com.kurogame.wutheringwaves.global,com.blizzard.diablo.immortal,com.roblox.client,com.mobilelegends.hwag,com.AlfaBravo.CombatMaster,com.ss.android.ugc.trill,com.mojang.minecraftpe,com.garena.game.kgid,com.NTRMAN.camWithMom,net.kdt.pojavlaunch,com.gamedevltd.wwh,net.kdt.pojavlaunch.firefly"

# Fungsi untuk mendeteksi apakah paket game terpasang
is_package_installed() {
    pm list packages | grep "$1" > /dev/null
    return $?
}

# Konfigurasi perangkat untuk Gaming Performance Mode

# Mengatur pengaturan performa gaming yang berkaitan dengan grafis dan CPU/GPU

# Tweak SurfaceFlinger
cmd device_config put hwui texture_cache_size 256m  # Tingkatkan ukuran cache tekstur untuk detail lebih
cmd device_config put hwui layer_cache_size 64m    # Tingkatkan ukuran cache layer untuk performa lebih baik
cmd device_config put hwui gradient_cache_size 8m   # Tingkatkan ukuran cache gradien
cmd device_config put hwui drop_shadow_cache_size 16m  # Tingkatkan ukuran cache bayangan jatuh
cmd device_config put hwui path_cache_size 32m  # Tingkatkan ukuran cache jalur
cmd device_config put hwui shape_cache_size 8m  # Tingkatkan ukuran cache bentuk
cmd device_config put hwui fbo_cache_size 32m  # Tingkatkan ukuran cache FBO
cmd device_config put hwui render_thread_priority 1
cmd device_config put hwui disable_vsync true
cmd device_config put hwui frame_latency 0  # Kurangi latensi frame untuk responsifitas
cmd device_config put hwui enable_binder_signal true
cmd device_config put hwui enable_surface_compression true
cmd device_config put hwui enable_cache_flush true
cmd device_config put hwui enable_gpu_fallback false

# Aktifkan OpenGL untuk performa grafis yang lebih baik
cmd device_config put hwui enable_opengl true  

# Aktifkan rendering dengan OpenGL ES untuk efisiensi grafis
cmd device_config put hwui enable_opengl_es true  

# Aktifkan pengaturan 4D (jika perangkat mendukungnya) untuk pengalaman visual yang lebih mendalam
cmd device_config put hwui enable_4d_rendering true  

# Tweak tambahan untuk optimasi performa grafis
cmd device_config put hwui enable_high_quality_rendering true  # Aktifkan rendering berkualitas tinggi
cmd device_config put hwui enable_vulkan true  # Aktifkan Vulkan untuk performa grafis yang lebih baik

# Tweak Grafis Umum
cmd device_config put graphics default_mipmap_bias 0.0  # Atur bias mipmap untuk kualitas tekstur optimal
cmd device_config put graphics msaa true  # Aktifkan MSAA untuk tepi yang lebih halus
cmd device_config put graphics enable_anisotropic_filtering true  # Aktifkan anisotropic filtering untuk kualitas tekstur yang lebih baik
cmd device_config put graphics gpu_boost_enabled true  # Aktifkan GPU boost untuk performa
cmd device_config put graphics gpu_force_render true  # Paksa rendering GPU untuk semua operasi
cmd device_config put graphics gpu_trilinear_filter true  # Aktifkan trilinear filtering untuk transisi tekstur yang lebih halus
cmd device_config put graphics gpu_max_render_threads 8  # Tingkatkan jumlah thread render untuk performa yang lebih baik
cmd device_config put graphics enable_vsync false  # Nonaktifkan V-Sync untuk mengurangi lag input
cmd device_config put graphics enable_frame_limit false  # Nonaktifkan batas frame untuk FPS yang lebih tinggi
cmd device_config put graphics enable_shadow_quality ultra  # Set kualitas bayangan ke ultra untuk bayangan yang realistis
cmd device_config put graphics enable_reflection_quality ultra  # Set kualitas refleksi ke ultra untuk realisme
cmd device_config put graphics enable_lighting_effects true  # Aktifkan efek pencahayaan lanjutan
cmd device_config put graphics enable_post_processing true  # Aktifkan efek pasca-pemrosesan untuk visual yang lebih baik

# Tweak Khusus 4D Tambahan
cmd device_config put graphics depth_of_field true  # Aktifkan depth of field untuk pengalaman yang mendalam
cmd device_config put graphics render_resolution 2.0  # Sesuaikan resolusi render untuk kejernihan
cmd device_config put graphics particle_effects true  # Aktifkan efek partikel lanjutan
cmd device_config put graphics texture_resolution ultra  # Atur resolusi tekstur ke ultra

# Tweak untuk Rendering Ultra HD
cmd device_config put graphics enable_ultra_hd true  # Aktifkan rendering Ultra HD
cmd device_config put graphics ultra_hd_render_resolution 2.0  # Sesuaikan resolusi render Ultra HD
cmd device_config put graphics enable_higher_texture_resolution true  # Aktifkan resolusi tekstur lebih tinggi
cmd device_config put graphics ultra_hd_texture_quality ultra  # Atur kualitas tekstur Ultra HD ke tinggi
cmd device_config put graphics enable_advanced_lighting true  # Aktifkan pencahayaan lanjutan untuk efek realistis
cmd device_config put graphics enable_hdr true  # Aktifkan High Dynamic Range untuk warna yang lebih baik
cmd device_config put graphics enable_8k_rendering true  # Aktifkan rendering 8K (jika didukung oleh perangkat)
cmd device_config put graphics enable_high_quality_shadows true  # Aktifkan bayangan berkualitas tinggi
cmd device_config put graphics enable_bloom_effects true  # Aktifkan efek bloom untuk meningkatkan pencahayaan
cmd device_config put graphics enable_dof_4d true  # Aktifkan depth of field untuk Ultra HD 4D

# Tweak untuk Bayangan
cmd device_config put graphics enable_soft_shadows true  # Aktifkan bayangan lembut untuk transisi yang lebih halus
cmd device_config put graphics shadow_resolution ultra  # Atur resolusi bayangan ke ultra untuk detail lebih baik

# Tweak untuk Efek Stroke
cmd device_config put graphics enable_stroke_effects true  # Aktifkan efek stroke untuk garis tepi
cmd device_config put graphics stroke_thickness 2.0  # Atur ketebalan stroke untuk penekanan visual
cmd device_config put graphics stroke_quality high  # Atur kualitas stroke ke tinggi

# Tweak untuk Shader
cmd device_config put graphics enable_advanced_shaders true  # Aktifkan efek shader lanjutan untuk realisme
cmd device_config put graphics shader_quality ultra  # Atur kualitas shader ke ultra untuk rendering detail

# Tweak untuk Tekstur
cmd device_config put graphics texture_filtering_quality ultra  # Atur filtering tekstur ke ultra
cmd device_config put graphics texture_compression false  # Nonaktifkan kompresi tekstur untuk kualitas lebih tinggi
cmd device_config put graphics enable_bump_mapping true  # Aktifkan bump mapping untuk detail permukaan
cmd device_config put graphics enable_normal_mapping true  # Aktifkan normal mapping untuk tekstur yang lebih halus

# Tweak untuk Rumput
cmd device_config put graphics enable_grass_rendering true  # Aktifkan rendering rumput untuk realisme
cmd device_config put graphics grass_density high  # Atur kepadatan rumput ke tinggi untuk lebih banyak vegetasi
cmd device_config put graphics grass_quality ultra  # Atur kualitas rumput ke ultra untuk rendering detail
cmd device_config put graphics enable_grass_shadows true  # Aktifkan bayangan untuk rumput untuk kedalaman tambahan

# Tweak CPU/GPU
cmd device_config put cpu enable_thermal_throttling false
cmd device_config put cpu performance_mode_enabled true
cmd device_config put cpu sched_boost_enabled true
cmd device_config put cpu governor performance
cmd device_config put cpu set_freq_hispeed 3000000  # Set kecepatan CPU tinggi
cmd device_config put cpu enable_hyperthreading true
cmd device_config put gpu force_high_performance_mode true
cmd device_config put gpu enable_adreno_boost true
cmd device_config put gpu enable_mali_boost true
cmd device_config put gpu enable_extended_texture true
cmd device_config put gpu render_ahead_limit 4  # Batasi render ahead untuk 4D

# Tweak Frame Rate dan Refresh Rate
cmd device_config put display refresh_rate 120  # Atur refresh rate (disesuaikan untuk 4D)
cmd device_config put display frame_rate 120    # Atur frame rate (disesuaikan untuk 4D)
cmd device_config put display enable_sampling_rate true  # Aktifkan sampling rate

# Konfigurasi untuk setiap paket game yang terinstal
for pkg in $(echo "$game_packages" | tr ',' ' '); do
    if is_package_installed "$pkg"; then
        
       
        # Tambahkan pengaturan khusus jika diperlukan per paket
    else
        
        
    fi
done




# Daftar paket game
packages=(
    "com.je.supersus"
    "com.gamedevltd.wwh"
    "com.ea.gp.maddennfl21mobile"
    "com.gravity.roo.sea"
    "com.sega.pjsekai"
    "com.gameark.ggplay.lonsea"
    "com.nekki.shadowfightarena"
    "com.pubg.krmobile"
    "com.HoYoverse.hkrpgoversea"
    "com.WandaSoftware.TruckersofEurope3"
    "com.maleo.bussimulatorid"
    "com.gameloft.android.ANMP.GloftA9HM"
    "com.legotca.gwb"
    "com.natsume.home"
    "com.winlator"
    "com.HoYoverse.Nap"
    "com.excelliance.multiaccounts"
    "com.mojang.minecraftpe.patch"
    "com.kakaogames.gdts"
    "xyz.aethersx2.android"
    "com.zane.stardewvalley"
    "com.lilithgame.roc.gp"
    "jp.konami.pesam"
    "net.kdt.pojavlaunch.zh"
    "net.kdt.pojavlaunch"
    "net.kdt.pojavlaunch.firefly"
    "com.miHoYo.GenshinImpact"
    "com.miHoYo.bh3oversea"
    "com.mobile.legends"
    "com.tencent.ig"
    "com.garena.game.codm"
    "com.dts.freefireth"
    "com.kurogame.gplay.punishing.grayraven.en"
    "com.dts.freefiremax"
    "com.mobilelegends.mi"
    "com.proximabeta.mf.uamo"
    "com.proximabeta.mf.liteuamo"
    "com.netease.newspike"
    "com.activision.callofduty.warzone"
    "com.carxtech.sr"
    "com.miraclegames.farlight84"
    "com.ea.gp.fifamobile"
    "com.levelinfinite.sgameGlobal"
    "com.tencent.iglite"
    "com.GlobalSoFunny.Sausage"
    "com.netmarble.sololv"
    "com.kurogame.wutheringwaves.global"
    "com.blizzard.diablo.immortal"
    "com.roblox.client"
    "com.mobilelegends.hwag"
    "com.AlfaBravo.CombatMaster"
    "com.ss.android.ugc.trill"
    "com.mojang.minecraftpe"
    "com.garena.game.kgid"
    "com.NTRMAN.camWithMom"
)

# Fungsi untuk menghapus cache
clear_cache() {
    local pkg=$1
    rm -rf /storage/emulated/0/android/data/"$pkg"/cache
}

# Fungsi untuk memberikan izin penyimpanan
grant_storage_permissions() {
    local pkg=$1
    pm grant "$pkg" android.permission.READ_EXTERNAL_STORAGE
    pm grant "$pkg" android.permission.WRITE_EXTERNAL_STORAGE
}

# Fungsi untuk mengatur app ops
set_app_ops() {
    local pkg=$1
    cmd appops set "$pkg" RUN_ANY_IN_BACKGROUND allow
    cmd appops set "$pkg" RUN_IN_BACKGROUND allow
    cmd appops set "$pkg" START_FOREGROUND allow
    cmd appops set "$pkg" WRITE_SETTINGS allow
    cmd appops set "$pkg" READ_EXTERNAL_STORAGE allow
}

# Fungsi Untuk Mengatur Game Mode Performance
set_game_mode() {
    local pkg=$1
    cmd device_config get game_overlay "$pkg"
    cmd device_config put game_overlay "$pkg" mode=2,fps=120:mode=3,fps=120
    cmd device_config put game_overlay "$pkg" mode=2,downscaleFactor=disable:mode=3,downscaleFactor=disable
}

# Fungsi untuk mengatur pengaturan daya
set_power_settings() {
    cmd thermalservice override-status 0
    cmd power set-fixed-performance-mode-enabled true
    cmd power set-adaptive-power-saver-enabled false
    cmd power set-mode 3
}

# Setprop Fps
set_prop_fps() {
    # Tweak Vsync & Interval
    setprop debug.cpurend.vsync "false"
    setprop debug.egl.vsync_mode "false"
    setprop debug.egl.vsync "false"
    setprop debug.egl.force_vsync "false"
    setprop debug.egl.disable_vsync "true"
    setprop debug.egl.enable_vsync "false"
    setprop debug.egl.enabled_vsync "false"
    setprop debug.egl.use_vsync "false"
    setprop debug.egl.hwui.vsync "false"
    setprop debug.egl.render_ahead_sync "false"
    setprop debug.egl.no_vsync "true"
    setprop debug.egl.swapinterval "0"
    setprop debug.egl.swap_interval "0"
    setprop debug.egl.frame_interval "0"
    setprop debug.gpurend.vsync "false"
    setprop debug.game.vsync "false"
    setprop debug.gr.vsync "false"
    setprop debug.gr.buffer_swap_during_vsync "false"
    setprop debug.gr.vsync_control "false"
    setprop debug.gr.swapinterval "0"
    setprop debug.gr.swap_intervsl "0"
    setprop debug.gr.frame_interval "0"
    setprop debug.hwc.force_gpu_vsync "false"
    setprop debug.hwc.dont_use_vsync "true"
    setprop debug.hwc.force_disable_vsync "true"
    setprop debug.hwc.disable_vsync_control "true"
    setprop debug.hwc.enable_vsync_control "false"
    setprop debug.hwui.disable_vsync "true"
    setprop debug.hwui.enable_vsync "false"
    setprop debug.hwui.enabled_vsync "false"
    setprop debug.hwui.use_vsync "false"
    setprop debug.hwui.disable_vsync_phase_adjustment "true"
    setprop debug.hwui.enable_vsync_phase_adjustment "false"
    setprop debug.hwui.swapinterval "0"
    setprop debug.hwui.render_ahead_sync "false"
    setprop debug.sf.late_vsync_threshold "true"
    setprop debug.sf.stc.interval "0"
    setprop debug.sf.stc_interval "0"
    setprop debug.sf.hwui.frame_interval "0"
    setprop debug.sf.swapinterval "0"
    setprop debug.sf.swap_interval "0"
    setprop debug.sf.no_hw_vsync "true"
    setprop debug.sf.vsync "false"
    setprop debug.sf.force_fake_vsync "true"
    setprop debug.sf.swap_vsync "false"
    setprop debug.sf.vsync_trace "false"
    setprop debug.sf.phase_offset_threshold_for_next_vsync_ns "false"
    setprop debug.sf.vsync_offset_ns "false"
    setprop debug.sf.vsync_reactor_ignore_present_fences "false"
    setprop debug.sf.show_predicted_vsync "false"
    setprop debug.sf.hwc_hotplug_error_via_neg_vsync "false"
    setprop debug.sf.hwc_hdcp_via_neg_vsync "false"
    setprop debug.sf.disable_vsync_timestamps "true"
    setprop debug.sf.enable_vsync_timestamps "false"
    setprop debug.sf.enabled_vsync_timestamps "false"
    setprop debug.sf.disable_phase_offset_for_vsync "true"
    setprop debug.sf.enable_phase_offset_for_vsync "false"
    setprop debug.sf.no_vsync_phase_adjustment "true"
    setprop debug.skiagl.disable_vsync "true"
    setprop debug.skiagl.enable_vsync "false"
    setprop debug.skiagl.enabled_vsync "false"
    setprop debug.skiagl.swap_interval "0"
    setprop debug.vsync.enabled "false"
    setprop debug.vsync.enable "false"
    setprop debug.vsync.disable "true"
}

# Rendering 3D OpenGL
set_prop_hwui() {
    # Tweak HWUI
    setprop debug.hwui.render_dirty_regions "false"
    setprop debug.hwui.show_dirty_regions "false"
    setprop debug.hwui.use_skia_gl_renderer "false"
    setprop debug.hwui.force_gpu_render "true"
    setprop debug.hwui.render_quality "3"
    setprop debug.hwui.layer_cache_size "256"
    setprop debug.hwui.render_thread "true"
    setprop debug.hwui.texture_quality "high"
    setprop debug.hwui.force_gpu_for_3d "true"
    setprop debug.hwui.max_gpu_memory_usage "2048"
    setprop debug.hwui.render_thread_count "4"
    setprop debug.hwui.profile_gpu_render "true"
    setprop debug.hwui.render_priority "3"
    setprop debug.hwui.renderer "opengl"
    setprop debug.hwui.render_engine_backend "opengl"
    setprop debug.hwui.composition_type "gpu"
    setprop debug.hwui.rendering_type "opengl"
    
    # Shadow Rendering
    setprop debug.hwui.shadow_quality "high"
    setprop debug.hwui.shadow_map_size "4096"
    setprop debug.hwui.enable_dynamic_shadows "true"
    setprop debug.hwui.shadow_renderer "hardware"
    setprop debug.hwui.drop_shadow_cache_size "64"
    
    # Texture Storage
    setprop debug.hwui.texture_store_quality "high"
    setprop debug.hwui.enable_texture_compression "true"
    
    # Shader
    setprop debug.hwui.shader_quality "high"
    setprop debug.hwui.enable_advanced_shaders "true"
    
    # Grass Rendering
    setprop debug.hwui.grass_quality "high"
    setprop debug.hwui.enable_dynamic_grass "true"
    
    # Smoke Rendering
    setprop debug.hwui.smoke_effects "true"
    setprop debug.hwui.smoke_quality "high"
    setprop debug.hwui.enable_dynamic_smoke "true"
    setprop debug.hwui.smoke_particle_count "4096"
    setprop debug.hwui.smoke_texture_resolution "high"
    
    # GPU dan Debug
    setprop debug.hwui.log "0"
    setprop debug.hwui.gpu "1"
    setprop debug.hwui.gpu_opt "1"
    setprop debug.hwui.debug_all "0"
    setprop debug.hwui.disable_scissor_opt "true"
    setprop debug.hwui.show_overdraw "0"
    setprop debug.hwui.overdraw "0"
    setprop debug.hwui.force_high_dpi "true"
    setprop debug.hwui.skia_atrace_enabled "true"
    setprop debug.hwui.target_cpu_time_percent "1440"
    setprop debug.hwui.target_gpu_time_percent "1440"
    setprop debug.hwui.profile "false"
    setprop debug.hwui.fps_divisor "-1"
    setprop debug.hwui.show_non_rect_clip "false"
    setprop debug.hwui.webview_overlays_enabled "false"
    setprop debug.hwui.use_hint_manager "false"
    setprop debug.hwui.skia_tracing_enabled "true"
    setprop debug.hwui.skia_use_perfetto_track_events "false"
    setprop debug.hwui.capture_skp_enabled "false"
    setprop debug.hwui.trace_gpu_resources "true"
    setprop debug.hwui.show_layers_updates "false"
    setprop debug.hwui.skip_empty_damage "false"
    setprop debug.hwui.use_buffer_age "true"
    setprop debug.hwui.use_partial_updates "false"
    setprop debug.hwui.use_gpu_pixel_buffers "true"
    setprop debug.hwui.filter_test_overhead "false"
    setprop debug.hwui.overdraw "false"
    setprop debug.hwui.level "1"
    setprop debug.hwui.use_buffer "1"
    setprop debug.hwui.use_dirty_regions "0"
    setprop debug.hwui.skip_swaps "0"
    setprop debug.hwui.use_framebuffer "1"
    setprop debug.hwui.force_sync "0"
    setprop debug.hwui.disable_scissors "1"
    setprop debug.hwui.use_gpu "1"
    setprop debug.hwui.force_sync "0"
    setprop debug.hwui.overdraw "0"
    setprop debug.hwui.show_overdraw "0"
    setprop debug.hwui.use_triple_buffering "1"
    setprop debug.hwui.enable_debug_layers "true"
    setprop debug.hwui.use_paint_mode "false"
    setprop debug.hwui.allow_high_quality "true"
    
    # Frame Rate, Refresh Rate, dan Sampling Rate
    setprop debug.hwui.force_refresh_rate "120"
    setprop debug.hwui.refresh_rate_forced "120"
    setprop debug.hwui.profile.maxframes "120"
    setprop debug.hwui.max_fps "120"
    setprop debug.hwui.min_fps "120"
    setprop debug.hwui.frame_rate_multiple "120"
    setprop debug.hwui.max_frames "120"
    
    # Anti-Aliasing (MSAA, CSAA, General)
    setprop debug.hwui.enable_msaa "true"
    setprop debug.hwui.msaa_sample_count "4"
    setprop debug.hwui.enable_4x_msaa "true"
    setprop debug.hwui.enable_csaa "true"
    setprop debug.hwui.force_anti_aliasing "true"
    setprop debug.hwui.anti_aliasing_quality "high"
    
    # FXAA (Fast Approximate Anti-Aliasing)
    setprop debug.hwui.enable_fxaa "true"
    setprop debug.hwui.fxaa_quality "high"
    
    # TAA (Temporal Anti-Aliasing)
    setprop debug.hwui.enable_taa "true"
    setprop debug.hwui.taa_quality "high"
    
    # SSAA (Super-Sampling Anti-Aliasing)
    setprop debug.hwui.enable_ssaa "true"
    setprop debug.hwui.ssaa_quality "high"
    
    # SMAA (Subpixel Morphological Anti-Aliasing)
    setprop debug.hwui.enable_smaa "true"
    setprop debug.hwui.smaa_quality "high"
    
    # MLAA (Morphological Anti-Aliasing)
    setprop debug.hwui.enable_mlaa "true"
    setprop debug.hwui.mlaa_quality "high"
    
    # TXAA (Temporal Super-Sampling Anti-Aliasing)
    setprop debug.hwui.enable_txaa "true"
    setprop debug.hwui.txaa_quality "high"
    
    # Peningkatan Kualitas Grafik
    setprop debug.hwui.enable_high_quality_gfx "true"
    setprop debug.hwui.enable_anisotropic_filtering "true"
    setprop debug.hwui.anisotropic_filtering_quality "16x"
    setprop debug.hwui.enable_texture_filtering "true"
    setprop debug.hwui.texture_filtering_quality "high"
    
    # GPU Tracing dan Debug Rendering
    setprop debug.hwui.gpu_tracing_enabled "true"
    setprop debug.hwui.enable_gfx_debugging "true"
    setprop debug.hwui.gpu_render_tracing "true"
    setprop debug.hwui.enable_renderdoc "true"
    setprop debug.hwui.use_cache "true"

    # Enable/Disable specific rendering optimizations
    setprop debug.hwui.enable_light_caching "true"
    setprop debug.hwui.enable_hd_rendering "true"
    setprop debug.hwui.enable_ultra_hd "true"
}

# General performance enhancements
set_prop_game_performance() {
    setprop debug.performance.profile "1"
    setprop debug.performance.tuning "1"
    setprop debug.game_performance.enable "1"
    setprop debug.game.performance.mode "1"
    setprop debug.scenegraph.batching_performance "1"
    setprop debug.performance.tuning_touch "1"
    setprop debug.input.touch_sampling_rate "250"
    setprop debug.thermal.mode "performance"
    setprop debug.tracing.block_touch_buffer "1"
    setprop debug.touchscreen.latency.scale "0.5"
    setprop debug.touchscreen.fling_time "1440"
    setprop debug.touchscreen.tap_timeout "1"
    setprop debug.touchscreen.doubletap_timeout "200"
    setprop debug.touchscreen.longpress_timeout "150"
    setprop debug.input.disablesuspend "1"
    setprop debug.touch.sampling_rate "250"
    setprop debug.touch.resample_rate "250"
    setprop debug.touchscreen.sampling_rate "250"
    setprop debug.touchscreen.max_sampling_rate "250"
    setprop debug.touchscreen.min_sampling_rate "250"
    setprop debug.touchscreen.finger_count "10"
    
    # Tracing Block Touch Buffer Enhancements
    setprop debug.tracing.block_touch_buffer_size "2048"
    setprop debug.tracing.block_touch_buffer_flush_interval "500"
    setprop debug.tracing.block_touch_buffer_logging "true"
    setprop debug.tracing.block_touch_buffer_threshold "80"
    setprop debug.tracing.block_touch_buffer_timeout "250"
    setprop debug.tracing.block_touch_buffer_enabled "true"
    setprop debug.tracing.block_touch_buffer_debug_level "2"
    setprop debug.tracing.block_touch_buffer_max_entries "100"
    setprop debug.tracing.block_touch_buffer_min_free "200"
    setprop debug.tracing.block_touch_buffer_retain_last "20"
    setprop debug.tracing.block_touch_buffer_log_path "/data/touch_traces/"
    setprop debug.tracing.block_touch_buffer_auto_flush "true"
    setprop debug.tracing.block_touch_buffer_overflow_action "drop_oldest"
    setprop debug.tracing.block_touch_buffer_compression "true"
    setprop debug.tracing.block_touch_buffer_encryption "false"
    setprop debug.tracing.block_touch_buffer_sync_interval "1000"
    
    # Input Touch Enhancements
    setprop debug.input.touch_debug_level "3"
    setprop debug.input.touch_accuracy "high"
    setprop debug.input.touch_delay "0"
    setprop debug.input.touch_filtering "true"
    setprop debug.input.touch_sensitivity "5"
    setprop debug.input.touch_calibration "1"
    setprop debug.input.touch_pressure_threshold "10"
    setprop debug.input.touch_interpolation "true"
    setprop debug.input.touch_jitter_reduction "2"
    setprop debug.input.touch_multi_finger_support "true"
    
    # Touchscreen Responsiveness
    setprop debug.touchscreen.responsiveness_mode "ultra"
    setprop debug.touchscreen.response_time "100"
    setprop debug.touchscreen.adaptive_touch "true"
    setprop debug.touchscreen.dynamic_refresh_rate "true"
    setprop debug.touchscreen.low_latency "true"
    
    # Gesture Controls
    setprop debug.touchscreen.gesture_recognition "true"
    setprop debug.touchscreen.swipe_threshold "50"
    setprop debug.touchscreen.gesture_sensitivity "7"
    setprop debug.touchscreen.gesture_timeout "300"
    setprop debug.touchscreen.edge_swipe_detection "true"
    setprop debug.touchscreen.double_tap_gesture "true"
    
    # Power Management for Touch Input
    setprop debug.input.power_save_mode "disabled"
    setprop debug.input.touch_power_optimization "true"
    setprop debug.input.touch_idle_timeout "5000"
    
    # Logging and Debugging
    setprop debug.input.touch_logging "true"
    setprop debug.input.touch_log_level "4"
    setprop debug.input.touch_log_path "/data/input_touch_logs/"
    setprop debug.input.touch_log_rotation "5"
    setprop debug.input.touch_log_compression "true"
    setprop debug.input.touch_log_encryption "false"
}
    
# Set Render Engine to OpenGL
set_prop_sw_hw() {
    setprop debug.renderengine.backend "opengl"
    setprop debug.stagefright.renderengine.backend "opengl"
    setprop debug.composition.type "gpu"
    setprop debug.mediatek.composition.type "gpu"
    setprop debug.hwc.use_hwc "true"
    setprop debug.hwc.enable_composition "true"
    setprop debug.hwc.force_cpu_composition "false"
    setprop debug.hwc.composition_type "gpu"
    setprop debug.hwc.enable_built_in "true"
}

set_prop_egl() {
    setprop debug.egl.all "1"
    setprop debug.egl.buffcount "8"
    setprop debug.egl.disable_msaa "0"
    setprop debug.egl.render_fps "120"
    setprop debug.egl.refresh_rate "120"
    setprop debug.egl.traceGpuCompletion "1"
    setprop debug.egl.profiler.perfetto "1"
    setprop debug.egl.hw "1"
    setprop debug.egl.buffers "1"
    setprop debug.egl.swap "1"
    setprop debug.egl.debug "0"
    setprop debug.egl.showfps "0"
    setprop debug.egl.profiler "0"
    setprop debug.egl.trace "1"
    setprop debug.egl.log "0"
    setprop debug.egl.force_fxaa "1"
    setprop debug.egl.force_taa "1"
    setprop debug.egl.force_msaa "4"
    setprop debug.egl.force_ssaa "1"
    setprop debug.egl.force_smaa "1"
    setprop debug.egl.force_mlaa "1"
    setprop debug.egl.force_txaa "1"
    setprop debug.egl.force_csaa "1"
    setprop debug.egl.callstack "0"
    setprop debug.egl.fps "120"
    setprop debug.egl.framerate "120"
    setprop debug.egl.refresh_rate "120"
    setprop debug.egl.sampling_rate "120"
    setprop debug.egl.fps_debug "0"
    setprop debug.egl.detail_fps "120"
    setprop debug.egl.finish "0"
    setprop debug.egl.rgb888_enable "1"
    
    # Shader Tweaks for Ultra HD
    setprop debug.egl.shader_quality "high"
    setprop debug.egl.enable_shaders "1"
    
    # Smoke Effects
    setprop debug.egl.smoke_enabled "1"
    setprop debug.egl.smoke_quality "high"
    
    # Stroke Effects
    setprop debug.egl.stroke_enabled "1"
    setprop debug.egl.stroke_quality "high"
    
    # Texture Settings
    setprop debug.egl.texture_quality "high"
    setprop debug.egl.texture_filtering "anisotropic"
    
    # Shadow Settings
    setprop debug.egl.shadows_enabled "1"
    setprop debug.egl.shadow_quality "high"
    setprop debug.egl.shadow_map_size "4096"
}
    
# Tweak untuk SurfaceFlinger untuk Ultra HD
set_prop_surface_flinger() {
    # Anti-Aliasing Tweaks
    setprop debug.sf.enable_fxaa "true"  # Fast Approximate Anti-Aliasing
    setprop debug.sf.enable_txaa "true"  # Temporal Anti-Aliasing
    setprop debug.sf.enable_csaa "true"  # Coverage Sampling Anti-Aliasing
    setprop debug.sf.enable_mlaa "true"  # Morphological Anti-Aliasing
    setprop debug.sf.enable_msaa "true"  # Multi-Sample Anti-Aliasing
    setprop debug.sf.enable_ssaa "true"  # Super-Sample Anti-Aliasing
    setprop debug.sf.enable_smaa "true"  # Subpixel Morphological Anti-Aliasing

    # Shader Tweaks
    setprop debug.sf.enable_shader_quality "high"  # Set shader quality to high
    setprop debug.sf.enable_post_processing "true"  # Enable post-processing effects

    # Stroke Tweaks
    setprop debug.sf.enable_strokes "true"  # Enable stroke effects

    # Smoke Tweaks
    setprop debug.sf.enable_smoke_effects "true"  # Enable smoke effects

    # Texture Tweaks
    setprop debug.sf.texture_quality "high"  # Set texture quality to high
    setprop debug.sf.enable_texture_filtering "true"  # Enable texture filtering

    # Grass Tweaks
    setprop debug.sf.enable_grass "true"  # Enable grass rendering
    setprop debug.sf.grass_quality "high"  # Set grass quality to high

    # Shadow Tweaks
    setprop debug.sf.enable_shadows "true"  # Enable shadow rendering
    setprop debug.sf.shadow_quality "high"  # Set shadow quality to high
    
    # SF
    setprop debug.sf.use_hwcomposer "true"
    setprop debug.sf.enable_triple_buffer "true"
    setprop debug.sf.enable_persistent_buffer "true"
    setprop debug.sf.use_gpu_composition "true"
    setprop debug.sf.fps "120"
    setprop debug.sf.hw "1"
    setprop debug.sf.render_threads "8"
    setprop debug.sf.hwcomposer "1"
    setprop debug.sf.hwui.force_hw "1"
    setprop debug.sf.gpuoverlay "0"
    setprop debug.sf.perf_mode "1"
    setprop debug.sf.hw_rotation_fps_divisor "1"
    setprop debug.sf.enable_latency_mode "1"
    setprop debug.sf.enable_gl_backpressure "0"
    setprop debug.sf.latch_unverified "0"
    setprop debug.sf.showupdates "0"
    setprop debug.sf.showcpu "0"
    setprop debug.sf.showbackground "0"
    setprop debug.sf.showfps "0"
    setprop debug.sf.render_buffer_size "4"
    setprop debug.sf.show_updates "0"
    setprop debug.sf.numframebuffer "4"
    setprop debug.sf.120hz_mode "1"
    setprop debug.sf.log "1"
    setprop debug.sf.show_frame "1"
    setprop debug.sf.render "1"
    setprop debug.sf.hwui "1"
    setprop debug.sf.hwui.gpu "1"
    setprop debug.sf.hwui.cache "1"
    setprop debug.sf.hwui.layers "1"
    setprop debug.sf.hwui.buffers "1"
    setprop debug.sf.hwui.shader "1"
    setprop debug.sf.hwui.hwvs "1"
    setprop debug.sf.hwui.memory "1"
    setprop debug.sf.hwui.profile "1"
    setprop debug.sf.hwui.gpu_perf "1"
    setprop debug.sf.hwui.fps "0"
    setprop debug.sf.hwui.framerate "120"
    setprop debug.sf.hwui.refresh_rate "120"
    setprop debug.sf.hwui.sampling_rate "120"
    setprop debug.sf.hwui.fps_debug "0"
    setprop debug.sf.hwui.render_fps "120"
    setprop debug.sf.hwui.update_rate "120"
    setprop debug.sf.hwui.detail_fps "120"
    setprop debug.sf.hwui_refresh_rate "120"
    setprop debug.sf.hwui_max_fps "120"
    setprop debug.sf.hwui_min_fps "120"
    setprop debug.sf.hwui_force_refresh_rate "120"
    setprop debug.sf.hwui_frame_rate "120"
    setprop debug.sf.hwui_frame_rate_multiple "120"
    setprop debug.sf.hwui_fps_boost "120"
    setprop debug.sf.hwui_fps_throttle "120"
    setprop debug.sf.frame_rate_multiple_fences "120"
    setprop debug.sf_frame_rate_multiple_fences "120"
    setprop debug.sf.frame_rate_multiple_threshold "120"
    setprop debug.sf.low_latency "1"
    setprop debug.sf.framebuffer_latency "0"
    setprop debug.sf.framebuffer_depth "32"
    setprop debug.sf.enable_layer_caching "0"
    setprop debug.sf.gpuoverlay "0"
    setprop debug.sf.viewmotion "0"
    setprop debug.sf.enable_planner_prediction "0"
    setprop debug.sf.log_repaint "0" 
    setprop debug.sf.cpu_freq_index "8"
    setprop debug.sf.enable_hwc "1" 
    setprop debug.sf.enable_egl_backpressure "0" 
    setprop debug.sf.disable_egl_backpressure "1" 
    setprop debug.sf.cpu_comp_tiling "1" 
    setprop debug.sf.enable_adpf_gpu_hint "1"
    setprop debug.sf.recomputecrop "0" 
    setprop debug.sf.layer_timeout "0" 
    setprop debug.sf.layer_smoothness "1" 
    setprop debug.sf.swaprect "1" 
    setprop debug.sf.nobootanimation "0" 
    setprop debug.sf.buffer_fence_tracker "0" 
    setprop debug.sf.display_dejitter_log "0" 
    setprop debug.sf.display_dejitter "0" 
    setprop debug.sf.dump_buffers "0" 
    setprop debug.sf.log_transaction "0" 
    setprop debug.sf.dump_buffers.sample "0" 
    setprop debug.sf.stats "0" 
    setprop debug.sf.wdthreshold "0" 
    setprop debug.sf.wdlog "0" 
    setprop debug.sf.wdtimer "0" 
    setprop debug.sf.perf_uclamp_min "150"
    setprop debug.sf.hwui.force_hw "1" 
    setprop debug.sf.nativedump "0" 
    setprop debug.sf.gpu_comp_tiling "1" 
    setprop debug.sf.set_binder_thread_rt "0"
    setprop debug.sf.enable_hgl "0" 
    setprop debug.sf.ddms "0" 
    setprop debug.sf.dump "0" 
    setprop debug.sf.set_idle_timer_ms "0"
    setprop debug.sf.treat_170m_as_sRGB "1"
    setprop debug.sf.max_igbp_list_size "0" 
    setprop debug.sf.disable_hwc_vds "0" 
    setprop debug.sf.enable_hwc_vds "1" 
    setprop debug.sf.enable_egl_image_tracker "0" 
    setprop debug.sf.luma_sampling "0"
    setprop debug.sf.disable_client_composition_cache "1" 
    setprop debug.sf.enable_advanced_sf_phase_offset "0" 
    setprop debug.sf.enable_gl_backpressure "0" 
    setprop debug.sf.disable_backpressure "1" 
    setprop debug.sf.latch_unsignaled "0"
    setprop debug.sf.gpu_freq_index "8"
    setprop debug.sf.auto_latch_unsignaled "0" 
    setprop debug.sf.predict_hwc_composition_strategy "0" 
    setprop debug.sf.kernel_idle_timer_update_overlay "1" 
    setprop debug.sf.support_kernel_idle_timer_enabled "0"  
    setprop debug.sf.enable_transaction_tracing "1" 
    setprop debug.sf.use_phase_offsets_as_durations "0" 
    setprop debug.sf.ignore_hwc_physical_display_orientation "0" 
    setprop debug.sf.enable_adpf_cpu_hint "1"
    setprop debug.sf.pref_fps_early_gl_phase_offset_ns "12000000" 
    setprop debug.sf.early.app.duration "20000000" 
    setprop debug.sf.early.sf.duration "27600000" 
    setprop debug.sf.hwc.min.duration "23000000"
    setprop debug.sf.late.app.duration "20000000" 
    setprop debug.sf.late.sf.duration "27600000" 
    setprop debug.sf.earlyGl.sf.duration "27600000" 
    setprop debug.sf.144_fps.early.app.duration "8333333" 
    setprop debug.sf.144_fps.early.sf.duration "11500000" 
    setprop debug.sf.144_fps.earlyGl.app.duration "8333333" 
    setprop debug.sf.144_fps.earlyGl.sf.duration "11500000" 
    setprop debug.sf.144_fps.late.app.duration "8333333"
    setprop debug.sf.144_fps.late.sf.duration "11500000"
    setprop debug.sf.high_fps.early.app.duration "10000000" 
    setprop debug.sf.high_fps.early.sf.duration "13800000" 
    setprop debug.sf.high_fps.earlyGl.app.duration "10000000" 
    setprop debug.sf.high_fps.earlyGl.sf.duration "13800000" 
    setprop debug.sf.high_fps.late.app.duration "10000000" 
    setprop debug.sf.high_fps.late.sf.duration "13800000" 
    setprop debug.sf.high_fps.hwc.min.duration "8500000" 
    setprop debug.sf.high_fps_early_phase_offset_ns "6100000" 
    setprop debug.sf.high_fps_early_gl_phase_offset_ns "650000" 
    setprop debug.sf.high_fps_late_app_phase_offset_ns "10000"
    setprop debug.sf.high_fps_late_sf_phase_offset_ns "650000"
    setprop debug.sf.earlyGl.app.duration "20000000" 
    setprop debug.sf.early_gl_phase_offset_ns "3000000" 
    setprop debug.sf.early_gl_app_phase_offset_ns "15000000"  
    setprop debug.sf.early_phase_offset_ns "500000"
}

# Mengoptimalkan pengaturan GPU dan rendering untuk Ultra HD
set_prop_graphics() {
    setprop debug.gr.backend "opengl"
    setprop debug.gr.enable "1"
    setprop debug.gr.fast_timing "1"  
    setprop debug.gr.force_gpu "1"
    setprop debug.gr.render_fps "120"
    setprop debug.gr.low_latency "1"
    setprop debug.gr.max_gpu_performance "1"
    setprop debug.gr.numframebuffer "4"  
    setprop debug.gr.render "1"
    setprop debug.gr.gpu_command_buffer "1"
    setprop debug.gr.shader_debug "1"
    setprop debug.gr.gpu_profiling "1"
    setprop debug.gr.gpu_trace "1"
    setprop debug.gr.max_gpu_performance "1"
    setprop debug.gr.gpu_debug "0"
    setprop debug.gr.high_frame_rate_logging "0"
    setprop debug.gr.render_time_logging "1"
    setprop debug.gr.framebuffer_debug "0"
    setprop debug.gr.force_gpu "1"
    setprop debug.gr.detailed_frame_stats "1"
    setprop debug.gr.fps "120"
    setprop debug.gr.framerate "120"
    setprop debug.gr.refresh_rate "120"
    setprop debug.gr.sampling_rate "120"
    setprop debug.gr.fps_debug "0"
    setprop debug.gr.render_fps "120"
    setprop debug.gr.update_rate "120"
    setprop debug.gr.detail_fps "120"
    setprop debug.gr.framebuffer_latency "0"
    setprop debug.gr.framebuffer_depth "32"  
    setprop debug.gr.low_latency "1"
    
    # Existing Ultra HD graphics tweaks
    setprop debug.gr.hdr "1"  
    setprop debug.gr.anti_aliasing "4"  
    setprop debug.gr.texture_quality "0"  
    setprop debug.gr.msaa "4"  
    setprop debug.gr.anisotropic_filtering "16"  
    setprop debug.gr.texture_cache_size "512"  
    setprop debug.gr.shadow_quality "2"  
    setprop debug.gr.use_fxaa "1"  
    setprop debug.gr.mipmaps "1"  
    setprop debug.gr.gpu_boost "1"  
    
    # Additional anti-aliasing tweaks
    setprop debug.gr.taa "1"
    setprop debug.gr.ssaa "1"
    setprop debug.gr.smaa "1"
    setprop debug.gr.lmaa "1"
    setprop debug.gr.txaa "1"
    setprop debug.gr.csaa "1"
    setprop debug.gr.fxaa "1"

    # Ultra HD tweaks for Stroke, Shader, Smoke, and Grass
    setprop debug.gr.stroke_quality "3"  
    setprop debug.gr.shader_quality "3"  
    setprop debug.gr.smoke_density "3"  
    setprop debug.gr.smoke_quality "3"  
    setprop debug.gr.grass_quality "3"  
    setprop debug.gr.grass_density "3"  
}

# Tweak Tambahan
set_prop_tambahan() {
    setprop debug.gralloc.enable_fb_optim "1"
    setprop debug.gralloc.enable "1"
    setprop debug.gralloc.gfx_ubwc_disable "0"
    
    # Tweak Force 
    setprop debug.force-opengl "true"
    setprop debug.force-skiagl "false"
    
    # Tweak Trace
    setprop debug.atrace.tags.enableflags "1"
    setprop debug.enabletraces "1"
    setprop debug.trace "1"
    
    # Tweak Render
    setprop debug.qsg_renderer "1"
    setprop debug.renderer.process "compound"
    setprop debug.renderthread.reduceopstasksplitting "1"
    setprop debug.threadedOpt "1"
    
    # Other
    setprop debug.cpuprio "7"
    setprop debug.gpuprio "7"
    setprop debug.gpu.scheduler_pre.emption "1"
    setprop debug.kill_allocating_task "0"
    setprop debug.overlayui.enable "1"
    setprop debug.perfhudes "1"
    setprop debug.performance.disturb "0"
    setprop debug.performance_schema "1"
    setprop debug.performance_schema_digests_size "9950000"
    setprop debug.performance_schema_max_memory_classes "320"
    setprop debug.performance_schema_max_socket_classes "20"
    setprop debug.rs.default-CPU-driver "1"
    setprop debug.rs.default-GPU-driver "1"
    setprop debug.rs.default-CPU-buffer "262144"
}

# Iterasi melalui setiap paket
for pkg in "${packages[@]}"; do
    # Cek apakah paket terinstal
    if pm list packages | grep -q "$pkg"; then
        # Pastikan UID ditemukan untuk paket tersebut
        uid=$(pm dump "$pkg" | grep -E 'userId=[0-9]+' | cut -d= -f2)

        if [ -z "$uid" ]; then
            
            
            continue
        fi

        # Panggil fungsi untuk setiap tweak
        clear_cache "$pkg"
        grant_storage_permissions "$pkg"
        set_app_ops "$pkg"
        set_game_mode "$pkg"
        set_power_settings
        set_prop_fps
        set_prop_hwui
        set_prop_game_performance
        set_prop_sw_hw
        set_prop_egl
        set_prop_surface_flinger
        set_prop_graphics
        set_prop_tambahan

        # Notifikasi tweak sukses terpasang
        
        
    else
        
        
    fi
done

# Tweak
{
    #Setedit
    pm grant by4a.setedit22 android.permission.WRITE_SETTINGS
    pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
    pm grant by4a.setedit22 android.permission.WRITE_GLOBAL_SETTINGS
    
    #Tweak
    pm disable com.xiaomi.joyouse
    dumpsys deviceidle disable
    
    # Settings put
    settings put global performance_mode 1 # Mode performa diaktifkan
    settings put global thermal_mode 0 # Mematikan mode thermal
    settings put system battery_saver_performance_mode 0 # Mode penghemat baterai dimatikan
    settings put global game_mode 1 #, Mode Game di Aktifkan
    settings put system game_mode_enabled 1 # Mode game diaktifkan
    settings put global game_latency 0 
    settings put global background_process_limit 4
    settings put system background_process_limit 4
    settings put global hardware_acceleration_mode 1
    settings put system rt_templimit_ceiling 100 
    settings put system tran_default_temperature_index 0 
    settings put secure game_auto_temperature_control 0
    settings put global game_temperature_control 0
    settings put global high_temp_limit 100 
    settings put global low_temp_limit 10 
    settings put global thermal_offload 0 
    settings put global thermal_throttling_enable 0
    settings put global tran_temp_battery_warning 0
    settings put system game.accelerate.hw 1
    settings put system high_performance_mode_on 1
    settings put system screen_game_mode 1 
    settings put system speed_mode 1 
    settings put system touch.feature.gamemode.enable 1 
    settings put system video.accelerate.hw 1
    settings put secure high_priority 1 
    settings put secure miui_optimization 1
    settings put secure speed_mode_enable 1
    settings put secure sysui_tuner_version 4 
    settings put secure support_highfps 1
    settings put secure thermal_temp_state_vaule 0
    settings put secure gamebooster_data_migration 1
    settings put secure gamebooster_remove_desktop_icon 1
    settings put secure gb_boosting 0
    settings put secure miui_updater_enable 0
    settings put secure pref_open_game_booster 1
    settings put global device_name "iPhone 16 Pro Max"
    settings put global dont.lower.fps 1
    settings put global enable.hw_accel 1 
    settings put global enable_hardware_acceleration 1
    settings put global foreground_mem_priority high 
    settings put global fps_governor performance
    settings put global fps_divisor -1 
    settings put global force_hw_ui 1 
    settings put global gpu.fps auto
    settings put global gm_game_mode_state 2 
    settings put global hardware_acceleration_mode 1
    settings put global hardware_accelerated_rendering_enabled 1 
    settings put global hardware_accelerated_graphics_decoding 1 
    settings put global hardware_accelerated_video_decode 1 
    settings put global hardware_accelerated_video_encode 1 
    settings put global media.sf.hwaccel 1
    settings put global os_game_assistant_panel 1 
    settings put global ram_expand_size_list 16
    settings put global restricted_device_performance 0,1
    settings put global stabilizer.fps 1
    settings put global stable.fps.enable 1
    settings put global sampling_profiler 1 
    settings put global speed_mode_on 1
    settings put global thermal_throttling_enable 0
    settings put global transsion_anti_inadvertently 0 
    settings put global transsion_brightness 0 
    settings put global transsion_game_acceleration 1 
    settings put global transsion_game_brightness 0 
    settings put global transsion_game_mode 1 
    settings put global transsion_game_mode_not_interrupt 0 
    settings put global transsion_game_tws_mode 1 
    settings put global zram_enabled 1 
    settings put global cpu_boost_on_game_enable 1
    settings put global gpu_performance_mode_enable 1
    settings put global render_resolution_quality high
    settings put global touch_boost_enable 1
    settings put global gfx_boost_enable 1
    settings put global network_latency_optimization_enable 1
    settings put global game_low_latency_mode 1 
    settings put global game_driver_mode 1
    settings put global game_driver_opt_out_apps 1
    settings put global game_bypass_charging 0 
    settings put global game_barrage_speed 2 
    settings put global game_mode 1
    settings put global game_driver_all_apps 1
    settings put global game_driver_opt_in_apps 0
    settings put global game_driver_opt_out_apps 0
    settings put global game_driver_prerelease_opt_in_apps 0
    settings put global performance_mode enabled
    settings put global game_driver_mode high_performance
    settings put global force_gpu_rendering 1
    settings put global enable_gpu_debug_layers 0
    settings put global gpu_debug_app 0
    settings put global gpu_debug_layer_app 0
    settings put global gpu_debug_layers 0
    settings put global gpu_debug_layers_vk 0
    settings put global gpu_debug_layers_gles 0
    settings put global enable_vulkan 0
    settings put global gpu_debug_layers_vulkan 0
    settings put global gpu_debug_profile_app 0
    settings put global gpu_debug_layers_gles2 0
    settings put global enable_msaa 0
    settings put global gpu_updatable_driver_enable 0
    settings put global gpu_updatable_driver_allowlist 0
    settings put global updatable_driver_all_apps 0
    settings put global updatable_driver_prerelease_opt_in_apps 0
    settings put global updatable_driver_production_allowlist 0
    settings put global updatable_driver_production_denylist null
    settings put global updatable_driver_production_opt_in_apps 0
    settings put global updatable_driver_production_opt_out_apps 0
    settings put global gpu_overdraw_show_count 4
    settings put global persist.sys.tran.otg.preference 1
    settings put system debug.force_gpu_rendering 1
    settings put global fstrim_enabled 1
    settings put global fstrim_interval 86400
    settings put global fstrim_mandatory_interval 1
    settings put global fstrim_flags 1
    settings put global fstrim_critical_interval 0
    settings put global fstrim_battery_threshold 0
    settings put global fstrim_delay 0
    settings put global fstrim_purge 1
    settings put global fpsgo_support_status enable
    settings put global fpsgo_enable 1
    settings put global fpsgo_priority 2
    settings put global fpsgo_mode 1
    settings put global fpsgo_logging 1
    settings put global fpsgo_fps_limit 144
    settings put global fpsgo_tolerance 10
    settings put global fpsgo_cpu_optimization 1
    settings put global fpsgo_gpu_optimization 1
    settings put global fpsgo_optimization_time 1440
    settings put global fpsgo_cpu_threshold 99
    settings put global fpsgo_gpu_threshold 99
    settings put global fpsgo_low_power_mode 1
    settings put global fpsgo_sensitivity 5
    settings put system mispeed_authorized_pkg_list com.tencent.mm,mm.tencent.com.comtencentmmhardcodertest
    settings put system miui_recents_show_mem_info 1
    settings put system screen_optimize_mode 1
    settings put secure freeform_window_state -1
    settings put secure support_gesture_shortcut_settings 1
    settings put secure systemui_fsgesture_support_superpower 1
    settings put secure xspace_enabled 1
    settings put system pointer_speed 7
    settings put secure sysui_tuner_version 4
    
    # Tweak Fstrim
    pm trim-caches 999G
    sm fstrim
    cmd shortcut reset-throttling
    cmd shortcut reset-all-throttling
    pm clear com.miui.powerkeeper
} > /dev/null 2>&1