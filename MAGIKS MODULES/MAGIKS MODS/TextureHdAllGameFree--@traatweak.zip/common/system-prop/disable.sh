{
# Setedit permissions
pm grant by4a.setedit22 android.permission.WRITE_SETTINGS
pm grant by4a.setedit22 android.permission.WRITE_SECURE_SETTINGS
pm grant by4a.setedit22 android.permission.WRITE_GLOBAL_SETTINGS

# Disable tweaks
pm enable com.xiaomi.joyouse
dumpsys deviceidle enable

# Reset Settings or Delete
settings delete global device_name
settings delete global performance_mode # Mode performa dinonaktifkan
settings delete global thermal_mode # Mengaktifkan mode thermal
settings put system battery_saver_performance_mode 1 # Mengaktifkan mode penghemat baterai
settings put global game_mode 0 # Mode game dinonaktifkan
settings put system game_mode_enabled 0 # Mode game dinonaktifkan
settings delete global game_latency
settings delete global background_process_limit
settings delete system background_process_limit
settings delete global hardware_acceleration_mode
settings delete system rt_templimit_ceiling
settings delete system tran_default_temperature_index
settings delete secure game_auto_temperature_control
settings delete global game_temperature_control
settings delete global high_temp_limit
settings delete global low_temp_limit
settings delete global thermal_offload
settings put global thermal_throttling_enable 1 # Mengaktifkan throttling thermal
settings delete global tran_temp_battery_warning
settings put system game.accelerate.hw 0
settings put system high_performance_mode_on 0
settings put system screen_game_mode 0
settings put system speed_mode 0
settings put system touch.feature.gamemode.enable 0
settings put system video.accelerate.hw 0
settings delete secure high_priority
settings put secure miui_optimization 0
settings put secure speed_mode_enable 0
settings delete secure sysui_tuner_version
settings delete secure support_highfps
settings delete secure thermal_temp_state_vaule
settings delete secure gamebooster_data_migration
settings delete secure gamebooster_remove_desktop_icon
settings delete secure gb_boosting
settings put secure miui_updater_enable 1
settings delete secure pref_open_game_booster
settings delete global dont.lower.fps
settings delete global enable.hw_accel
settings delete global enable_hardware_acceleration
settings delete global foreground_mem_priority
settings delete global fps_governor
settings delete global fps_divisor
settings delete global force_hw_ui
settings delete global gpu.fps
settings delete global gm_game_mode_state
settings delete global hardware_acceleration_mode
settings delete global hardware_accelerated_rendering_enabled
settings delete global hardware_accelerated_graphics_decoding
settings delete global hardware_accelerated_video_decode
settings delete global hardware_accelerated_video_encode
settings delete global media.sf.hwaccel
settings delete global os_game_assistant_panel
settings delete global ram_expand_size_list
settings delete global restricted_device_performance
settings delete global stabilizer.fps
settings delete global stable.fps.enable
settings delete global sampling_profiler
settings delete global speed_mode_on
settings put global thermal_throttling_enable 1 # Mengaktifkan throttling thermal
settings delete global transsion_anti_inadvertently
settings delete global transsion_brightness
settings delete global transsion_game_acceleration
settings delete global transsion_game_brightness
settings delete global transsion_game_mode
settings delete global transsion_game_mode_not_interrupt
settings delete global transsion_game_tws_mode
settings put global zram_enabled 0
settings delete global cpu_boost_on_game_enable
settings delete global gpu_performance_mode_enable
settings delete global render_resolution_quality
settings delete global touch_boost_enable
settings delete global gfx_boost_enable
settings delete global network_latency_optimization_enable
settings put global game_low_latency_mode 0
settings put global game_driver_mode 0
settings delete global game_driver_opt_out_apps
settings put global game_bypass_charging 1 # Aktifkan pengisian daya bypass game
settings delete global game_barrage_speed
settings put global game_mode 0
settings delete global game_driver_all_apps
settings delete global game_driver_opt_in_apps
settings delete global game_driver_opt_out_apps
settings delete global game_driver_prerelease_opt_in_apps
settings delete global performance_mode
settings delete global game_driver_mode
settings delete global force_gpu_rendering
settings delete global enable_gpu_debug_layers
settings delete global gpu_debug_app
settings delete global gpu_debug_layer_app
settings delete global gpu_debug_layers
settings delete global gpu_debug_layers_vk
settings delete global gpu_debug_layers_gles
settings delete global enable_vulkan
settings delete global gpu_debug_layers_vulkan
settings delete global gpu_debug_profile_app
settings delete global gpu_debug_layers_gles2
settings delete global enable_msaa
settings delete global gpu_updatable_driver_enable
settings delete global gpu_updatable_driver_allowlist
settings delete global updatable_driver_all_apps
settings delete global updatable_driver_prerelease_opt_in_apps
settings delete global updatable_driver_production_allowlist
settings delete global updatable_driver_production_denylist
settings delete global updatable_driver_production_opt_in_apps
settings delete global updatable_driver_production_opt_out_apps
settings delete global gpu_overdraw_show_count
settings delete global persist.sys.tran.otg.preference
settings put system debug.force_gpu_rendering 0
settings delete global fstrim_enabled
settings delete global fstrim_interval
settings delete global fstrim_mandatory_interval
settings delete global fstrim_flags
settings delete global fstrim_critical_interval
settings delete global fstrim_battery_threshold
settings delete global fstrim_delay
settings delete global fstrim_purge
settings delete global fpsgo_support_status
settings delete global fpsgo_enable
settings delete global fpsgo_priority
settings delete global fpsgo_mode
settings delete global fpsgo_logging
settings delete global fpsgo_fps_limit
settings delete global fpsgo_tolerance
settings delete global fpsgo_cpu_optimization
settings delete global fpsgo_gpu_optimization
settings delete global fpsgo_optimization_time
settings delete global fpsgo_cpu_threshold
settings delete global fpsgo_gpu_threshold
settings delete global fpsgo_low_power_mode
settings delete global fpsgo_sensitivity
settings delete system mispeed_authorized_pkg_list
settings delete system miui_recents_show_mem_info
settings delete system screen_optimize_mode
settings delete secure freeform_window_state
settings delete secure support_gesture_shortcut_settings
settings delete secure systemui_fsgesture_support_superpower
settings delete secure xspace_enabled
settings delete system pointer_speed
settings delete secure sysui_tuner_version

# Tweak Fstrim
pm trim-caches 999G
sm fstrim
cmd shortcut reset-throttling
cmd shortcut reset-all-throttling
pm clear com.miui.powerkeeper
} > /dev/null 2>&1

# Definisikan daftar paket game
game_packages="com.je.supersus,com.ea.gp.maddennfl21mobile,com.gravity.roo.sea,com.sega.pjsekai,com.gameark.ggplay.lonsea,com.nekki.shadowfightarena,com.pubg.krmobile,com.WandaSoftware.TruckersofEurope3,com.maleo.bussimulatorid,com.gameloft.android.ANMP.GloftA9HM,com.legotca.gwb,com.natsume.home,com.winlator,com.HoYoverse.Nap,com.excelliance.multiaccounts,com.mojang.minecraftpe.patch,com.kakaogames.gdts,xyz.aethersx2.android,com.zane.stardewvalley,com.lilithgame.roc.gp,jp.konami.pesam,net.kdt.pojavlaunch.zh,com.miHoYo.GenshinImpact,com.miHoYo.bh3oversea,com.mobile.legends,com.tencent.ig,com.garena.game.codm,com.dts.freefireth,com.kurogame.gplay.punishing.grayraven.en,com.dts.freefiremax,com.mobilelegends.mi,com.proximabeta.mf.uamo,com.proximabeta.mf.liteuamo,com.netease.newspike,com.activision.callofduty.warzone,com.carxtech.sr,com.miraclegames.farlight84,com.ea.gp.fifamobile,com.levelinfinite.sgameGlobal,com.tencent.iglite,com.GlobalSoFunny.Sausage,com.netmarble.sololv,com.kurogame.wutheringwaves.global,com.blizzard.diablo.immortal,com.roblox.client,com.mobilelegends.hwag,com.AlfaBravo.CombatMaster,com.ss.android.ugc.trill,com.mojang.minecraftpe,com.garena.game.kgid,com.NTRMAN.camWithMom,net.kdt.pojavlaunch,com.gamedevltd.wwh,net.kdt.pojavlaunch.firefly"

# Fungsi untuk mendeteksi apakah paket game terpasang
is_package_installed() {
    pm list packages | grep "$1" > /dev/null
    return $?
}

# Konfigurasi perangkat untuk menghapus Gaming Performance Mode


# Hapus pengaturan performa gaming yang berkaitan dengan grafis dan CPU/GPU

# Tweak SurfaceFlinger
cmd device_config delete hwui texture_cache_size
cmd device_config delete hwui layer_cache_size
cmd device_config delete hwui gradient_cache_size
cmd device_config delete hwui drop_shadow_cache_size
cmd device_config delete hwui path_cache_size
cmd device_config delete hwui shape_cache_size
cmd device_config delete hwui fbo_cache_size
cmd device_config delete hwui render_thread_priority
cmd device_config delete hwui disable_vsync
cmd device_config delete hwui frame_latency
cmd device_config delete hwui enable_binder_signal
cmd device_config delete hwui enable_surface_compression
cmd device_config delete hwui enable_cache_flush
cmd device_config delete hwui enable_gpu_fallback

# Hapus pengaturan OpenGL dan Vulkan
cmd device_config delete hwui enable_opengl
cmd device_config delete hwui enable_opengl_es
cmd device_config delete hwui enable_4d_rendering
cmd device_config delete hwui enable_high_quality_rendering
cmd device_config delete hwui enable_vulkan

# Hapus Tweak Grafis Umum
cmd device_config delete graphics default_mipmap_bias
cmd device_config delete graphics msaa
cmd device_config delete graphics enable_anisotropic_filtering
cmd device_config delete graphics gpu_boost_enabled
cmd device_config delete graphics gpu_force_render
cmd device_config delete graphics gpu_trilinear_filter
cmd device_config delete graphics gpu_max_render_threads
cmd device_config delete graphics enable_vsync
cmd device_config delete graphics enable_frame_limit
cmd device_config delete graphics enable_shadow_quality
cmd device_config delete graphics enable_reflection_quality
cmd device_config delete graphics enable_lighting_effects
cmd device_config delete graphics enable_post_processing

# Hapus Tweak Khusus 4D Tambahan
cmd device_config delete graphics depth_of_field
cmd device_config delete graphics render_resolution
cmd device_config delete graphics particle_effects
cmd device_config delete graphics texture_resolution

# Hapus Tweak Rendering Ultra HD
cmd device_config delete graphics enable_ultra_hd
cmd device_config delete graphics ultra_hd_render_resolution
cmd device_config delete graphics enable_higher_texture_resolution
cmd device_config delete graphics ultra_hd_texture_quality
cmd device_config delete graphics enable_advanced_lighting
cmd device_config delete graphics enable_hdr
cmd device_config delete graphics enable_8k_rendering
cmd device_config delete graphics enable_high_quality_shadows
cmd device_config delete graphics enable_bloom_effects
cmd device_config delete graphics enable_dof_4d

# Hapus Tweak untuk Bayangan
cmd device_config delete graphics enable_soft_shadows
cmd device_config delete graphics shadow_resolution

# Hapus Tweak untuk Efek Stroke
cmd device_config delete graphics enable_stroke_effects
cmd device_config delete graphics stroke_thickness
cmd device_config delete graphics stroke_quality

# Hapus Tweak untuk Shader
cmd device_config delete graphics enable_advanced_shaders
cmd device_config delete graphics shader_quality

# Hapus Tweak untuk Tekstur
cmd device_config delete graphics texture_filtering_quality
cmd device_config delete graphics texture_compression
cmd device_config delete graphics enable_bump_mapping
cmd device_config delete graphics enable_normal_mapping

# Hapus Tweak untuk Rumput
cmd device_config delete graphics enable_grass_rendering
cmd device_config delete graphics grass_density
cmd device_config delete graphics grass_quality
cmd device_config delete graphics enable_grass_shadows

# Hapus Tweak CPU/GPU
cmd device_config delete cpu enable_thermal_throttling
cmd device_config delete cpu performance_mode_enabled
cmd device_config delete cpu sched_boost_enabled
cmd device_config delete cpu governor
cmd device_config delete cpu set_freq_hispeed
cmd device_config delete cpu enable_hyperthreading
cmd device_config delete gpu force_high_performance_mode
cmd device_config delete gpu enable_adreno_boost
cmd device_config delete gpu enable_mali_boost
cmd device_config delete gpu enable_extended_texture
cmd device_config delete gpu render_ahead_limit

# Hapus Tweak Frame Rate dan Refresh Rate
cmd device_config delete display refresh_rate
cmd device_config delete display frame_rate
cmd device_config delete display enable_sampling_rate

# Konfigurasi untuk setiap paket game yang terinstal
for pkg in $(echo "$game_packages" | tr ',' ' '); do
    if is_package_installed "$pkg"; then
        
        
        # Tambahkan penghapusan pengaturan khusus jika diperlukan per paket
    else
        
        
    fi
done

# Daftar paket game
packages=(
    "com.je.supersus"
    "com.gamedevltd.wwh"
    "com.ea.gp.maddennfl21mobile"
    "com.gravity.roo.sea"
    "com.sega.pjsekai"
    "com.gameark.ggplay.lonsea"
    "com.nekki.shadowfightarena"
    "com.pubg.krmobile"
    "com.HoYoverse.hkrpgoversea"
    "com.WandaSoftware.TruckersofEurope3"
    "com.maleo.bussimulatorid"
    "com.gameloft.android.ANMP.GloftA9HM"
    "com.legotca.gwb"
    "com.natsume.home"
    "com.winlator"
    "com.HoYoverse.Nap"
    "com.excelliance.multiaccounts"
    "com.mojang.minecraftpe.patch"
    "com.kakaogames.gdts"
    "xyz.aethersx2.android"
    "com.zane.stardewvalley"
    "com.lilithgame.roc.gp"
    "jp.konami.pesam"
    "net.kdt.pojavlaunch.zh"
    "net.kdt.pojavlaunch"
    "net.kdt.pojavlaunch.firefly"
    "com.miHoYo.GenshinImpact"
    "com.miHoYo.bh3oversea"
    "com.mobile.legends"
    "com.tencent.ig"
    "com.garena.game.codm"
    "com.dts.freefireth"
    "com.kurogame.gplay.punishing.grayraven.en"
    "com.dts.freefiremax"
    "com.mobilelegends.mi"
    "com.proximabeta.mf.uamo"
    "com.proximabeta.mf.liteuamo"
    "com.netease.newspike"
    "com.activision.callofduty.warzone"
    "com.carxtech.sr"
    "com.miraclegames.farlight84"
    "com.ea.gp.fifamobile"
    "com.levelinfinite.sgameGlobal"
    "com.tencent.iglite"
    "com.GlobalSoFunny.Sausage"
    "com.netmarble.sololv"
    "com.kurogame.wutheringwaves.global"
    "com.blizzard.diablo.immortal"
    "com.roblox.client"
    "com.mobilelegends.hwag"
    "com.AlfaBravo.CombatMaster"
    "com.ss.android.ugc.trill"
    "com.mojang.minecraftpe"
    "com.garena.game.kgid"
    "com.NTRMAN.camWithMom"
)

# Fungsi untuk memberikan izin penyimpanan
grant_storage_permissions() {
    local pkg=$1
    pm grant "$pkg" android.permission.READ_EXTERNAL_STORAGE
    pm grant "$pkg" android.permission.WRITE_EXTERNAL_STORAGE
}

# Fungsi untuk mengatur app ops
set_app_ops() {
    local pkg=$1
    cmd appops set "$pkg" RUN_ANY_IN_BACKGROUND allow
    cmd appops set "$pkg" RUN_IN_BACKGROUND allow
    cmd appops set "$pkg" START_FOREGROUND allow
    cmd appops set "$pkg" WRITE_SETTINGS allow
    cmd appops set "$pkg" READ_EXTERNAL_STORAGE allow
}

# Fungsi Untuk Mengatur Game Mode Performance
set_game_mode() {
    local pkg=$1
    cmd device_config get game_overlay "$pkg"
    cmd device_config put game_overlay "$pkg" mode=2,fps=60:mode=3,fps=60
    cmd device_config put game_overlay "$pkg" mode=2,downscaleFactor=disable:mode=3,downscaleFactor=disable
}

# Fungsi untuk mengatur pengaturan daya
set_power_settings() {
    cmd thermalservice override-status 1
    cmd power set-fixed-performance-mode-enabled false
    cmd power set-adaptive-power-saver-enabled true
    cmd power set-mode 1
}

# Fungsi untuk menghapus cache
clear_cache() {
    local pkg=$1
    rm -rf /storage/emulated/0/android/data/"$pkg"/cache
}