# © 2025 magiks Vexiro. All rights reserved.
# Version 3.6.0
#
# magiks Vexiro
# A lightweight utility app designed to enhance user experience through various system tweaks and optimizations.
#
# Developer: @traatweak
# Email: magiksvexiro@gmail.com
# Website: https://magiksvexiro.pages.dev
#
# This app is developed with a focus on efficiency, stability, and ease of use.
# All components and features are independently built to ensure maximum performance across devices.
#
# Copyright & License
# All contents within this app are protected by copyright laws.
# It is strictly prohibited to copy, modify, or redistribute this app, in whole or in part, without written permission from the developer.
# Violations will be prosecuted under applicable law.
#
# Disclaimer
# This application is provided "as is" without any warranty, express or implied.
# The user assumes full responsibility for the use of this application.
#
# Contact & Support
# For issues, suggestions, or contributions, feel free to contact us via email or visit our official website.
#
# Privacy Policy | Terms of Service
#tuning setprop for your perf+ Ui
android_properties() {
setprop debug.composition.type gpu
setprop debug.composition_type gpu
setprop debug.composition.surfaceflinger true
setprop debug.composition.enable true
setprop debug.composition.override true
setprop debug.composition.enabled true
setprop debug.composition.layer gpu
setprop debug.composition.optimization true
setprop debug.composition.max_layer_count 4
setprop debug.composition.enable_egl_swap_interval false
setprop debug.composition.prefer_hardware false
setprop debug.composition.translucent_layer true
}
android_properties > /dev/null 2>&1 
(
setprop debug.composition.type gpu
setprop debug.composition_type gpu
setprop debug.composition.surfaceflinger true
setprop debug.composition.enable true
setprop debug.composition.override true
setprop debug.composition.enabled true
setprop debug.composition.layer gpu
setprop debug.composition.optimization true
setprop debug.composition.max_layer_count 4
setprop debug.composition.enable_egl_swap_interval false
setprop debug.composition.prefer_hardware false
setprop debug.composition.translucent_layer true
) > /dev/null 2>&1 
{
setprop debug.composition.type gpu
setprop debug.composition_type gpu
setprop debug.composition.surfaceflinger true
setprop debug.composition.enable true
setprop debug.composition.override true
setprop debug.composition.enabled true
setprop debug.composition.layer gpu
setprop debug.composition.optimization true
setprop debug.composition.max_layer_count 4
setprop debug.composition.enable_egl_swap_interval false
setprop debug.composition.prefer_hardware false
setprop debug.composition.translucent_layer true
} > /dev/null 2>&1
android_properties (
   "debug.composition.type gpu"
   "debug.composition_type gpu"
   "debug.composition.surfaceflinger true"
   "debug.composition.enable true"
   "debug.composition.override true"
   "debug.composition.enabled true"
   "debug.composition.layer gpu"
   "debug.composition.optimization true"
   "debug.composition.max_layer_count 4"
   "debug.composition.enable_egl_swap_interval false"
   "debug.composition.prefer_hardware false"
   "debug.composition.translucent_layer true"
)
for prop in "${android_properties[@]}"; do
   setprop $prop > /dev/null 2>&1
done