(
#V7.0
settings delete global force_gpu_rendering 
settings delete global low_power
settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
# UI & Animation Enhancements
setprop debug.hwui.use_buffer_age ""
setprop debug.hwui.use_partial_update ""
setprop debug.hwui.drop_shadow_cache_size ""
setprop debug.hwui.fbo_cache_size ""
setprop debug.hwui.gradient_cache_size ""
setprop debug.hwui.layer_cache_size ""
setprop debug.hwui.texture_cache_size ""
setprop debug.sf.high_fps_early_gl_phase_offset_ns ""
setprop debug.sf.high_fps_early_phase_offset_ns ""
setprop debug.sf.high_fps_late_app_phase_offset_ns ""
setprop debug.sf.high_fps_late_sf_phase_offset_ns ""
settings delete global vendor.dfps.enable
settings delete global vendor.display.default_fps
settings delete global vendor.display.fod_monitor_default_fps
settings delete global vendor.display.idle_default_fps
settings delete global vendor.display.video_or_camera_fps.support
settings delete global vendor.fps.switch.defaul 
settings delete global vendor.fps.switch.thermal 
settings delete global vendor.display.disable_mitigated_fps 
settings delete global vendor.display.enable_dpps_dynamic_fps 
# Mematikan fitur yang mengganggu performa
settings delete global auto_sync 
settings delete global ble_scan_always_enabled 
settings delete global wifi_scan_always_enabled 
settings delete global hotword_detection_enabled 
settings delete global activity_starts_logging_enabled 
settings delete global network_recommendations_enabled 
settings delete secure adaptive_sleep 
settings delete secure screensaver_enabled 
settings delete secure send_action_app_error 
settings  system motion_engine 
settings delete system master_motion 
settings delete system air_motion_engine 
settings delete system air_motion_wake_up 
settings delete system send_security_reports 
settings delete system intelligent_sleep_mode 
settings delete system nearby_scanning_enabled 
settings delete system nearby_scanning_permission_allowed 
# Menonaktifkan layanan Qualcomm yang tidak diperlukan
pm enable com.qualcomm.qti.cne
pm enable com.qualcomm.location.XT
# Menonaktifkan pembatasan termal untuk performa maksimal
cmd power set-adaptive-power-saver-enabled true
cmd power set-fixed-performance-mode-enabled false
setprop debug.sf.gpu_freq_indeks ""
settings delete global surface_flinger.max_frame_buffer_acquired_buffers 3 
settings delete global surface_flinger.use_context_priority true
settings delete global surface_flinger.set_touch_timer_ms 0
settings delete global surface_flinger.use_content_detection_for_refresh_rate false
settings put global surface_flinger.game_default_frame_rate_override 90
settings put global surface_flinger.enable_frame_rate_override false
settings delete global logcat.live 
settings delete global config hw_quickpoweron
settings delete system gsm.lte.ca.support
setprop debug.hwui.disable_scissor_opt ""
settings delete global hwui.texture_cache_size
settings delete global hwui.texture_cache_flushrate
settings delete global disable_smooth_effect 
settings delete system sys.composition.type
settings delete system gpu_perf_mode
#Performa Infinity
settings delete system FPSTUNER_SWITCH
settings delete system GPUTUNER_SWITCH
settings delete system CPUTUNER_SWITCH
settings delete system NV_POWERMODE
settings delete system hw.accelerated
settings delete system video.accelerated
settings delete system game.accelerated
settings delete system ui.accelerated
settings delete system enable_hardware_accelerated
settings delete system enable_optimize_refresh_rate 
settings delete system lgospd.enable
settings delete system pcsync.enable 
settings delete system dalvik.hyperthreading
settings delete system dalvik.multithread 
#MTK Infinity X - Reset to empty
# Rendering and UI Optimizations
setprop debug.sf.disable_client_composition_cache ""
settings delete debug.sf.latch_unsignaled
setprop debug.sf.disable_backpressure ""
settings delete system use_16bpp_alpha
# MTK Performance Boosts
settings delete global mtk_perf_fast_start_win
settings delete global mtk_perf_response_time
settings delete global mtk_perf_simple_start_win
setprop debug.sf.disable_client_composition_cache ""
setprop debug.sf.disable_hw_vsync ""
setprop debug.hwui.disable_vsync ""
setprop debug.egl.hw 0
setprop debug.sf.native_mode 0system ya 
setprop debug.gralloc.gfx_ubwc_disable 0
setprop debug.video.accelerate.hw 0
setprop debug.mediatek.appgamepq_compress ""
setprop debug.mediatek.disp_decompress ""
setprop debug.mtk_tflite.target_nnapi ""
setprop debug.mtk.aee.feature ""
setprop debug.mediatek.performance ""
setprop debug.mediatek.game_pq_enable ""
setprop debug.mediatek.appgamepq ""
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold ""
#InfinityX - Reset to empty
settings delete system user_refresh_rate
settings delete system min_refresh_rate 
settings delete system peak_refresh_rate
settings delete system user_refresh_rate 
settings delete system user_refresh_rate
setprop debug.performance.tuning ""
setprop debug.composition.type ""
setprop debug.gfx.early_z ""
setprop debug.hwui.skip_empty_damage ""
setprop debug.qctwa.preservebuf ""
setprop debug.qctwa.preservebuf.comp_level ""
setprop debug.qc.hardware ""
setprop debug.qcom.hw_hmp.min_fps ""
setprop debug.qcom.hw_hmp.max_fps ""
setprop debug.qcom.pil.q6_boost ""
setprop debug.qcom.render_effect ""
setprop debug.adreno.force_rast ""
setprop debug.adreno.prefer_native_sync ""
setprop debug.adreno.q2d_decompress ""
setprop debug.rs.qcom.use_fast_math ""
setprop debug.rs.qcom.disable_expand ""
setprop debug.sf.hw ""
setprop debug.hwui.shadow.renderer ""
setprop debug.gfx.driver.1 ""
setprop debug.power_management_mode ""
setprop debug.gfx.driver ""
setprop debug.angle.overlay ""
setprop debug.hwui.target_cpu_time_percent ""
setprop debug.hwui.target_gpu_time_percent ""
setprop debug.hwui.use_hint_manager ""
setprop debug.multicore.processing ""
setprop debug.fb.rgb565 ""
setprop debug.sf.lag_adj ""
setprop debug.sf.showfps ""
setprop debug.hwui.max_frame_time ""
setprop debug.sf.disable_backpressure ""
setprop debug.hbm.direct_render_pixmaps ""
setprop debug.hwui.render_compability ""
setprop debug.heat_suppression ""
setprop debug.systemuicompilerfilter ""
setprop debug.sensor.hal ""
setprop debug.hwui.render_quality ""
setprop debug.sf.gpu_freq_index ""
setprop debug.sf.cpu_freq_index ""
setprop debug.sf.mem_freq_index ""
setprop debug.egl.force_fxaa ""
setprop debug.egl.force_taa ""
setprop debug.egl.force_msaa ""
setprop debug.egl.force_ssaa ""
setprop debug.egl.force_smaa ""
setprop debug.egl.force_mlaa ""
setprop debug.egl.force_txaa ""
setprop debug.egl.force_csaa ""
setprop debug.gpurend.vsync ""
setprop debug.cpurend.vsync ""
setprop debug.hwui.fps_divisor ""
setprop debug.redroid.fps ""
setprop debug.disable_sched_boost ""
setprop debug.gpu.cooling.callback_freq_limit ""
setprop debug.cpu.cooling.callback_freq_limit ""
setprop debug.rs.default-CPU-driver ""
setprop debug.rs.default-CPU-buffer ""
setprop debug.hwui.use_hint_manager ""
setprop debug.egl.profiler ""
setprop debug.enable.gamed ""
setprop debug.qualcomm.sns.daemon ""
setprop debug.qualcomm.sns.libsensor ""
setprop debug.sf.disable_client_composition_cache ""
#InfinityCmd - Reset to default
cmd looper_stats reset
cmd power set-adaptive-power-saver-enabled true
cmd power set-fixed-performance-mode-enabled false
cmd power set-mode 0
cmd thermalservice reset-status
dumpsys deviceidle disable
) > /dev/null 2>&1