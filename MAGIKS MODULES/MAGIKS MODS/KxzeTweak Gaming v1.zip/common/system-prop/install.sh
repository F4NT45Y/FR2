#!system/bin/sh

# Touch Responsiveness
settings put global touch.sampling_boost 1
setprop debug.touch.sampling_boost 1.0
settings put system pointer_speed 7
settings put global input.sampling_rate 1000
settings put global input.delay 0
settings put global input.resampling 1
settings put global input.low_latency_mode 1
settings put global input.high_precision_mode 1
settings put global input.predictive_input 1

# Disable Animation
settings put global window_animation_scale 0.0
settings put global transition_animation_scale 0.0
settings put global animator_duration_scale 0.0

# Disable VSync & Frame Rate Limit
setprop debug.hwui.disable_vsync true
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.choreographer.vsync false
setprop debug.sf.no_hw_vsync 1
settings put global force_gpu_rendering 1
settings put global fps.upper_bound 0
settings put global fps.lower_bound 0

# Set High Refresh Rate
settings put system min_refresh_rate 240
settings put system peak_refresh_rate 1
settings put system user_refresh_rate 1
settings put global surface_flinger.set_idle_timer_ms 0
settings put global surface_flinger.set_touch_timer_ms 0

# Overclock CPU
echo "1900000" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo "1900000" > /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
echo "1900000" > /sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq
echo "2200000" > /sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq

# Overclock GPU
echo "800000000" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq

# Kill background apps during gaming
GAME_PKGS=("com.pubg.mobile" "com.netease.newspike" "com.garena.game.codm" "com.dts.freefireth" "com.garena.game.df" "com.mobile.legends")
CPU_USAGE=$(top -b -n 1 | grep -E "${GAME_PKGS[*]}" | awk '{sum += $9} END {print int(sum)}')
if [ "$CPU_USAGE" -gt 80 ]; then
  BACKGROUND_APPS=$(dumpsys activity processes | grep -iE "cached|background" | awk '{print $2}')
  for app in $BACKGROUND_APPS; do
    am force-stop "$app"
  done
fi

# Output UBWC status for verification
getprop | grep ubwc
getprop | grep alloc

# Notifikasi Sukses
cmd notification post -S bigtext -t 'Enjoy your device'