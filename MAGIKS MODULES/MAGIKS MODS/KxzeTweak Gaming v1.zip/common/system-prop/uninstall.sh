#!/system/bin/sh

# Restore Touch Responsiveness to default
settings put global touch.sampling_boost 0
setprop debug.touch.sampling_boost 0.0
settings put system pointer_speed 0
settings put global input.sampling_rate 60
settings put global input.delay 100
settings put global input.resampling 0
settings put global input.low_latency_mode 0
settings put global input.high_precision_mode 0
settings put global input.predictive_input 0

# Enable Animations (default values: usually 1.0)
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0

# Re-enable VSync & Restore Frame Rate Settings
setprop debug.hwui.disable_vsync false
setprop debug.sf.disable_backpressure 0
setprop debug.sf.latch_unsignaled 0
setprop debug.choreographer.vsync true
setprop debug.sf.no_hw_vsync 0
settings put global force_gpu_rendering 0
settings put global fps.upper_bound 60
settings put global fps.lower_bound 30

# Restore Default Refresh Rate
settings put system min_refresh_rate 60
settings put system peak_refresh_rate 60
settings put system user_refresh_rate 60
settings put global surface_flinger.set_idle_timer_ms 1000
settings put global surface_flinger.set_touch_timer_ms 200

# Restore Default CPU Frequency
echo "1400000" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
echo "1400000" > /sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq
echo "1400000" > /sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq
echo "1800000" > /sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq

# Restore Default GPU 
echo "400000000" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq


# Output UBWC status for verification
getprop | grep ubwc
getprop | grep alloc

# Notifikasi Sukses
cmd notification post -S bigtext -t 'Enjoy your device'