(
#V7.0
settings put global force_gpu_rendering 1
settings put global low_power 0
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5
#V6.0
# UI & Animation Enhancements
setprop debug.hwui.use_buffer_age false
setprop debug.hwui.use_partial_update false
setprop debug.hwui.drop_shadow_cache_size 12
setprop debug.hwui.fbo_cache_size 12
setprop debug.hwui.gradient_cache_size 2
setprop debug.hwui.layer_cache_size 48
setprop debug.hwui.texture_cache_size 88
setprop debug.sf.high_fps_early_gl_phase_offset_ns -2000000
setprop debug.sf.high_fps_early_phase_offset_ns -4000000
setprop debug.sf.high_fps_late_app_phase_offset_ns 1000000
setprop debug.sf.high_fps_late_sf_phase_offset_ns -2000000
settings put global vendor.dfps.enable false
settings put global vendor.display.default_fps 120
settings put global vendor.display.fod_monitor_default_fps 120
settings put global vendor.display.idle_default_fps 120
settings put global vendor.display.video_or_camera_fps.support true
settings put global vendor.fps.switch.defaul true
settings put global vendor.fps.switch.thermal true
settings put global vendor.display.disable_mitigated_fps 1
settings put global vendor.display.enable_dpps_dynamic_fps 0
#V5.0
# Mematikan fitur yang mengganggu performa
settings put global auto_sync 0
settings put global ble_scan_always_enabled 0
settings put global wifi_scan_always_enabled 0
settings put global hotword_detection_enabled 0
settings put global activity_starts_logging_enabled 0
settings put global network_recommendations_enabled 0
settings put secure adaptive_sleep 0
settings put secure screensaver_enabled 0
settings put secure send_action_app_error 0
settings put system motion_engine 0
settings put system master_motion 0
settings put system air_motion_engine 0
settings put system air_motion_wake_up 0
settings put system send_security_reports 0
settings put system intelligent_sleep_mode 0
settings put system nearby_scanning_enabled 0
settings put system nearby_scanning_permission_allowed 0
# Menonaktifkan layanan Qualcomm yang tidak diperlukan
pm disable com.qualcomm.qti.cne
pm disable com.qualcomm.location.XT
# Menonaktifkan pembatasan termal untuk performa maksimal
cmd thermalservice override-status 0
cmd power set-adaptive-power-saver-enabled false
cmd power set-fixed-performance-mode-enabled true
#V4.0 Infinity X
setprop debug.sf.gpu_freq_indeks 7
settings put global surface_flinger.max_frame_buffer_acquired_buffers 3 
settings put global surface_flinger.use_context_priority true
settings put global surface_flinger.set_touch_timer_ms 0
settings put global surface_flinger.use_content_detection_for_refresh_rate false
settings put global surface_flinger.game_default_frame_rate_override 90
settings put global surface_flinger.enable_frame_rate_override false
#New
setprop debug.performance.tuning 1
settings put global logcat.live disable
settings put global config hw_quickpoweron true
settings put system gsm.lte.ca.support 1
setprop debug.hwui.disable_scissor_opt true
settings put global hwui.texture_cache_size 24
settings put global hwui.texture_cache_flushrate 0.5
settings put global disable_smooth_effect true
setprop debug.composition.type mdp
settings put system sys.composition.type mdp
settings put system gpu_perf_mode 1
#Performa Infinity
settings put system FPSTUNER_SWITCH true
settings put system GPUTUNER_SWITCH true
settings put system CPUTUNER_SWITCH true
settings put system NV_POWERMODE true
setprop debug.gpurend.vsync false
setprop debug.cpurend.vsync false
settings put system hw.accelerated 1
settings put system video.accelerated 1
settings put system game.accelerated 1
settings put system ui.accelerated 1
settings put system enable_hardware_accelerated true
settings put system enable_optimize_refresh_rate true
settings put system lgospd.enable 0
settings put system pcsync.enable 0
settings put system dalvik.hyperthreading true
settings put system dalvik.multithread true
# Rendering and UI Optimizations
setprop debug.sf.disable_client_composition_cache 1
settings put debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1
settings put system use_16bpp_alpha 1
#MTK Infinity X
# MTK Performance Boosts
settings put global mtk_perf_fast_start_win1
settings put global mtk_perf_response_time 1
settings put global mtk_perf_simple_start_win 1
setprop debug.mediatek.appgamepq_compress 1
setprop debug.mediatek.disp_decompress 1
setprop debug.mtk_tflite.target_nnapi 29
setprop debug.mtk.aee.feature 1
setprop debug.mediatek.performance 1
setprop debug.mediatek.game_pq_enable 1
setprop debug.mediatek.appgamepq 2
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 120
#InfinityX
settings put system user_refresh_rate 120
settings put system min_refresh_rate 120
settings put system peak_refresh_rate 120
settings put system user_refresh_rate infinity
settings get system user_refresh_rate
setprop debug.gfx.early_z 1
setprop debug.hwui.skip_empty_damage true
setprop debug.qctwa.preservebuf 1
setprop debug.qctwa.preservebuf.comp_level 3
setprop debug.qc.hardware 1
setprop debug.qcom.hw_hmp.min_fps -1
setprop debug.qcom.hw_hmp.max_fps -1
setprop debug.qcom.pil.q6_boost q
setprop debug.qcom.render_effect 0
setprop debug.adreno.force_rast 1
setprop debug.adreno.prefer_native_sync 1
setprop debug.adreno.q2d_decompress 1
setprop debug.rs.qcom.use_fast_math 1
setprop debug.rs.qcom.disable_expand 1
setprop debug.sf.hw 1
setprop debug.hwui.shadow.renderer monothic
setprop debug.gfx.driver.1 com.qualcomm.qti.gpudrivers.kona.api30
setprop debug.power_management_mode pref_max
setprop debug.gfx.driver 1
setprop debug.angle.overlay FPS:Vulkan*PipelineCache*
setprop debug.hwui.target_cpu_time_percent 300
setprop debug.hwui.target_gpu_time_percent 300
setprop debug.hwui.use_hint_manager true
setprop debug.multicore.processing 1
setprop debug.fb.rgb565 1
setprop debug.sf.lag_adj 0
setprop debug.sf.showfps 0
setprop debug.hwui.max_frame_time 35.55
setprop debug.sf.disable_backpressure 1
setprop debug.hbm.direct_render_pixmaps 1
setprop debug.hwui.render_compability true
setprop debug.heat_suppression 0
setprop debug.systemuicompilerfilter speed
setprop debug.sensor.hal 0
setprop debug.hwui.render_quality high
setprop debug.sf.gpu_freq_index 7
setprop debug.sf.cpu_freq_index 7
setprop debug.sf.mem_freq_index 7
setprop debug.egl.force_fxaa false
setprop debug.egl.force_taa false
setprop debug.egl.force_msaa false
setprop debug.egl.force_ssaa false
setprop debug.egl.force_smaa false
setprop debug.egl.force_mlaa false
setprop debug.egl.force_txaa false
setprop debug.egl.force_csaa false
setprop debug.hwui.fps_divisor -1
setprop debug.redroid.fps 120
setprop debug.disable_sched_boost true
setprop debug.gpu.cooling.callback_freq_limit false
setprop debug.cpu.cooling.callback_freq_limit false
setprop debug.rs.default-CPU-driver 1
setprop debug.rs.default-CPU-buffer 65536
setprop debug.hwui.use_hint_manager 1
setprop debug.egl.profiler 0
setprop debug.enable.gamed false
setprop debug.qualcomm.sns.daemon 0
setprop debug.qualcomm.sns.libsensor 1
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.disable_hw_vsync true
setprop debug.hwui.disable_vsync true
setprop debug.egl.hw 1
setprop debug.sf.native_mode 1
setprop debug.gralloc.gfx_ubwc_disable 1
setprop debug.video.accelerate.hw 1
#InfinityCmd
cmd looper_stats disable
cmd power set-adaptive-power-saver-enabled false
cmd power set-fixed-performance-mode-enabled true
cmd power set-mode 0
cmd thermalservice override-status 0
dumpsys deviceidle enable
dumpsys deviceidle force-idle
dumpsys deviceidle step deep
) > /dev/null 2>&1
cmd power set-mode 0
settings put global low_power 0
(
settings put system POWER_SAVE_PRE_HIDE_MODE performance
settings put secure speed_mode_enable 1
settings put system speed_mode 1
settings put global restricted_device_performance_enabled 0
settings put global restricted_device_performance_power_level 0
settings put global game_service_mode 2
settings put global game_mode 2
settings put global game_service_game_process_enable 1
settings put global game_process_boost_enabled 1
) > /dev/null 2>&1

(
#V9.0
settings put global product.gpu.driver 1
setprop debug.hwui.render_dirty_regions false
settings put system use_dithering 0
setprop debug.enabletr true
settings put global vold.umsdirtyratio 15
setprop debug.overlayui.enable 1
setprop debug.gralloc.gfx_ubwc_disable 0
setprop debug.sf.enable_advanced_sf_phase_offset 0
settings put system execution-mode int optimized
settings put global config.low_ram true
) > /dev/null 2>&1

(
#V8.0
settings put global ro.transsion.launcher_boost_scene_support 1
settings put system windowsmgr.max_events_per_sec 120
settings put global logcat.live disable
settings put global persist.sys.surfaceflinger.idle_reduce_framerate_enable true
settings put global persist.vendor.camera.HAL3.enabled 1
settings put global video.accelerate.hw 1
settings put system persist.sys.ui.hw true
settings put global mtk_perf_response_time 1
settings put global mtk_perf_fast_start_win 1
settings put global tran_high_temperature_fps.support 1
settings put global transsion.cpubooster.heavy_loading.support 1
settings put global esports.thermal_config.support 1
settings put global os_game_tp_esports10.support 1
settings put global game_tp_esports20.support 1
settings put global game_tp_optimization.support 1
settings put global game_network_acceleration.support 1
settings put global ro.transsion.disable_sf_sched 1
) > /dev/null 2>&1

#Percepat aplikasi 
(
settings put global iorapd.readahead.enable true
settings put global iorapd.perfetto.enable true
) > /dev/null 2>&1

#NEWV7
(
cmd device_config put activity_manager max_phantom_processes 2147483647
cmd device_config put activity_manager max_cached_processes 256
cmd device_config put activity_manager max_empty_time_millis 43200000
setprop debug.sf.gpu_comp_tiling 1
cmd thermalservice override-status 0
cmd power set-adaptive-power-saver-enabled false
cmd power set-fixed-performance-mode-enabled true
settings put global dropbox:dumpsys:procstats disabled
settings put global dropbox:dumpsys:usagestats disabled  
) > /dev/null 2>&1

#NEWV6
(
setprop debug.biner.use_async_exec 1
setprop debug.hwui.preallocate_frame true
setprop debug.rs.forcerecompile false
setprop debug.extractor.ignore_version 1
setprop debug.hwui.use_smart_batching true
setprop debug.hwui.renderthread_wakeup_ms 0
setprop debug.dls.weight 100
setprop debug.hwui.ffpe true
setprop debug.hwui.layer_cache_key_hashing true
setprop debug.art.max-threads 8
setprop debug.dex2oat.max-threads 4
setprop debug.hwui.use_gl_draw_to_create 1
setprop debug.sf.fault_native_asserts 1
setprop debug.hexcode.use.binary 1
setprop debug.sf.ignore_hwc_physical_display_orientation true
setprop debug.sf.hwc_hotplug_error_via_neg_vsyn false
) > /dev/null 2>&1

#NEWV5
(
setprop debug.hwui.compression.type ETC
setprop debug.hwui.compres.type ETC
settings put system gpu_perf_mode 1
settings put global perf.framepacing.enable false
settings put system purgeable_assets 1
setprop debug.surface_flinger.max_frame_buffer_acquired_buffers 3
) > /dev/null 2>&1

#NEWV4
(
settings put system sound_effects_enabled 1
settings put system background_settle_time 0
settings put system fgservice_min_shown_time 0
settings put system fgservice_min_report_time 0
settings put system fgservice_screen_on_before_time 0
settings put system fgservice_screen_on_after_time 0
settings put system content_provider_retain_time 0
settings put system service_usage_interaction_time 0
settings put system service_max_inactivity 0
settings put system service_bg_start_timeout 0
) > /dev/null 2>&1

#NEWV3
(
settings put system block_sda_queue_scheduler noop
settings put system block_sda_queue_read_ahead_kb 512
settings put system block_sda_queue_rotational 0
settings put system block_sda_queue_iostats 0
settings put system block_sda_queue_add_random 0
settings put system block_sda_queue_rq_affinity 1
settings put system block_sda_queue_nomerges 0
settings put system block_sda_queue_nr_requests 256
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.high_fps_early_phase_offset_ns 6100000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000
) > /dev/null 2>&1

#NEWV2
#Qualcomm
(
setprop debug.com.qc.hardware 1
setprop debug.qc.hardware true
setprop debug.qctwa.preservebuf 1
setprop debug.qctwa.statusbar 1
) > /dev/null 2>&1

#Mediatek
(
settings put global mtk_perf_simple_enable 1
settings put system mtk_perf_simple.enable 1
settings put system mtk_perfservice_support 1
settings put system mtk_sched_boost_enabled 1
settings put global mtk_power_mode_switch 1
) > /dev/null 2>&1

(
setprop debug.performance.tuning 1
setprop debug.egl.hw 1
setprop debug.tool.anrhistory 0
setprop debug.force_hw_ui true
setprop debug.hw2d.force 1
setprop debug.monitor false
setprop debug.logcat.live disable
settings put system logd.kernel false
settings put system config.htc.nocheckin 1
settings put system profiler.launch false
settings put system profilerhung.dumpdobugreport false
settings put system profiler.force_disable_err_rpt 1
settings put system profiler.force_disable_ulog 1
) > /dev/null 2>&1

#BOOSTER TWEAK
(
setprop debug.qcom_kgsl-3d0_adrenoboost enable 
settings put system simple_gpu_algorithm_parameters 1
settings put system simple_gpu_activate 1
) > /dev/null 2>&1

#TWIZZ TWEAK PERF
(
settings put system purgeable_assets 1
settings put system surface_flinger.max_frame_buffer_acquired_buffers 3
settings put system telephony.call_ring.delay 0
settings put system bq.gpu_to_cpu_unsupported 1
settings put system ril.disable.power.collapse 0
settings put system sf.compbypass.enable 0
settings put system ril.enable.a52 1
settings put system ril.enable.a53 0
settings put system hwui.render_dirty_regions false
settings put system NV_FPSLIMIT 120
settings put system NV_POWERMODE 1
settings put system NV_PROFVER 15
settings put system NV_STEREOCTRL 0
settings put system NV_STEREOSEPCHG 0
settings put system NV_STEREOSEP 25
setprop debug.egl.hw 1
setprop debug.composition.type gpu
setprop debug.sf.showcpu 0
setprop debug.sf.showcpu 0
settings put system dalvik.hyperthreading true
settings put system dalvik.multithread true
setprop debug.force_hw_ui true
setprop debug.hw2d.force 1
setprop debug.hw3d.force 1
settings put system com.qc.hardware true
setprop debug.hwui.disable_vsync true
settings put system config.disable.hw_accel false
settings put system product.gpu.driver 1
setprop debug.fb.mode 1
settings put system ui.hw 1
setprop debug.sf.disable_blurs 1
settings put system purgeable_assets 1
settings put system service.lgospd.enable 0
settings put system service.pcsync.enable 0
settings put system use_16bpp_alpha 1
settings put system android.strictmode 0
settings put system config.nocheckin 1
settings put system com.qc.hardware 1
setprop debug.qctwa.preservebuf 1
setprop debug.qctwa.statusbar 1
settings put global data.large_tcp_window_size true
settings put global ril.set.mtu1472 1
settings put system cust.tel.eons 1
settings put system config.hw_fast_dormancy 1
settings put global zygote.preload.enable 1
settings put system device_config.runtime_native.usap_pool_enabled true
settings put global quick_start_support 1
settings put system adb.notify 0
settings put system adb.enable 0
) > /dev/null 2>&1
(
# Optimize Refresh Rate
settings put global surface_flinger.use_content_detection_for_refresh_rate false
settings put global media.recorder-max-base-layer-fps 60
settings put global vendor.fps.switch.default true
settings put system vendor.disable_idle_fps true
settings put global vendor.display.default_fps 60
settings put system vendor.display.idle_default_fps 60
settings put system vendor.display.enable_optimize_refresh 1
settings put system vendor.display.video_or_camera_fps.support true
setprop debug.hwui.refresh_rate 60
setprop debug.sf.set_idle_timer_ms 500
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.high_fps_early_phase_offset_ns 2000000
setprop debug.sf.high_fps_late_app_phase_offset_ns 500000
settings put system game_driver_min_frame_rate  60
settings put system game_driver_max_frame_rate  60
settings put system game_driver_power_saving_mode 0
settings put system game_driver_frame_skip_enable 0
settings put system game_driver_vsync_enable 0
settings put system game_driver_gpu_mode 1
settings put system game_driver_gpu_mode 1
settings put system game_driver_fps_limit 60
) > /dev/null 2>&1 &

(
#Fps Injector 
setprop debug.graphics.game_default_frame_rate 60
setprop debug.graphics.game_default_frame_rate.disabled false
setprop persist.sys.gpu_perf_mode 1
setprop debug.mtk.powerhal.hint.bypass 1
setprop persist.sys.surfaceflinger.idle_reduce_framerate_enable false
setprop sys.surfaceflinger.idle_reduce_framerate_enable false
setprop debug.sf.perf_mode 1
settings put global refresh.active 1
setprop debug.hwui.disable_vsync true
setprop debug.performance.profile 1
setprop debug.perf.tuning 1
) > /dev/null 2>&1 &
(
#New  Tweak fps lock 
settings put system user_refresh_rate 60
settings put system fps_limit 60
settings put system max_refresh_rate_for_ui 60
settings put system hwui_refresh_rate 60
settings put system display_refresh_rate 60
settings put system max_refresh_rate_for_gaming 60
#Mengatur margin Fps
settings put system fstb_target_fps_margin_high_fps 20
settings put system fstb_target_fps_margin_low_fps 20
settings put system gcc_fps_margin 10
#remove Refresh rate
settings put global tran_low_battery_60hz_refresh_rate.support 0
# Lock refresh rate to 60  Hz
settings put display.refresh_rate 60
settings put system sf.refresh_rate 60
setprop persist.vendor.display.refresh_rate 60
settings put system user_refresh_rate 6p
settings put secure user_refresh_rate 60
settings put secure miui_refresh_rate 30
settings put system min_frame_rate 60
settings put system max_frame_rate 60
settings put system tran_refresh_mode 60
settings put system last_tran_refresh_mode_in_refresh_setting 60
settings put global min_fps 60
settings put global max_fps 60
settings put system tran_need_recovery_refresh_mode 60
settings put system display_min_refresh_rate 60
settings put system min_refresh_rate 60
settings put system max_refresh_rate 60
settings put system peak_refresh_rate 60
settings put secure refresh_rate_mode 60
settings put system user_refresh_rate 60
settings put system thermal_limit_refresh_rate 60
settings put system NV_FPSLIMIT 60
settings put system fps.limit.is.now locked
) > /dev/null 2>&1 &
(
# Optimize Refresh Rate
settings put global surface_flinger.use_content_detection_for_refresh_rate false
settings put global media.recorder-max-base-layer-fps 90
settings put global vendor.fps.switch.default true
settings put system vendor.disable_idle_fps true
settings put global vendor.display.default_fps 90
settings put system vendor.display.idle_default_fps 90
settings put system vendor.display.enable_optimize_refresh 1
settings put system vendor.display.video_or_camera_fps.support true
setprop debug.hwui.refresh_rate 90
setprop debug.sf.set_idle_timer_ms 500
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.high_fps_early_phase_offset_ns 2000000
setprop debug.sf.high_fps_late_app_phase_offset_ns 500000
settings put system game_driver_min_frame_rate  90
settings put system game_driver_max_frame_rate  90
settings put system game_driver_power_saving_mode 0
settings put system game_driver_frame_skip_enable 0
settings put system game_driver_vsync_enable 0
settings put system game_driver_gpu_mode 1
settings put system game_driver_gpu_mode 1
settings put system game_driver_fps_limit 90
) > /dev/null 2>&1 &

(
#Fps Injector 
setprop debug.graphics.game_default_frame_rate 90
setprop debug.graphics.game_default_frame_rate.disabled false
setprop persist.sys.gpu_perf_mode 1
setprop debug.mtk.powerhal.hint.bypass 1
setprop persist.sys.surfaceflinger.idle_reduce_framerate_enable false
setprop sys.surfaceflinger.idle_reduce_framerate_enable false
setprop debug.sf.perf_mode 1
settings put global refresh.active 1
setprop debug.hwui.disable_vsync true
setprop debug.performance.profile 1
setprop debug.perf.tuning 1
) > /dev/null 2>&1 &
(
#New  Tweak fps lock 
settings put system user_refresh_rate 90
settings put system fps_limit 90
settings put system max_refresh_rate_for_ui 90
settings put system hwui_refresh_rate 90
settings put system display_refresh_rate 90
settings put system max_refresh_rate_for_gaming 90
#Mengatur margin Fps
settings put system fstb_target_fps_margin_high_fps 20
settings put system fstb_target_fps_margin_low_fps 20
settings put system gcc_fps_margin 10
#remove Refresh rate
settings put system tran_low_battery_60hz_refresh_rate.support 0
# Lock refresh rate to 90 Hz
settings put system vendor.display.refresh_rate 90
settings put system user_refresh_rate 1
settings put system sf.refresh_rate 90
settings put secure user_refresh_rate 1
settings put secure miui_refresh_rate 90
settings put system min_frame_rate 90
settings put system max_frame_rate 90
settings put system tran_refresh_mode 90
settings put system last_tran_refresh_mode_in_refresh_setting 90
settings put global min_fps 90
settings put global max_fps 90
settings put system tran_need_recovery_refresh_mode 90
settings put system display_min_refresh_rate 90
settings put system min_refresh_rate 90
settings put system max_refresh_rate 90
settings put system peak_refresh_rate 90
settings put secure refresh_rate_mode 90
settings put system thermal_limit_refresh_rate 90
settings put system NV_FPSLIMIT 90
settings put system fps.limit.is.now locked
) > /dev/null 2>&1 &
(
# Optimize Refresh Rate
settings put global surface_flinger.use_content_detection_for_refresh_rate false
settings put global media.recorder-max-base-layer-fps 120
settings put global vendor.fps.switch.default true
settings put system vendor.disable_idle_fps true
settings put global vendor.display.default_fps 120
settings put system vendor.display.idle_default_fps 120
settings put system vendor.display.enable_optimize_refresh 1
settings put system vendor.display.video_or_camera_fps.support true
setprop debug.hwui.refresh_rate 120
setprop debug.sf.set_idle_timer_ms 500
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.high_fps_early_phase_offset_ns 2000000
setprop debug.sf.high_fps_late_app_phase_offset_ns 500000
settings put system game_driver_min_frame_rate  120
settings put system game_driver_max_frame_rate  120
settings put system game_driver_power_saving_mode 0
settings put system game_driver_frame_skip_enable 0
settings put system game_driver_vsync_enable 0
settings put system game_driver_gpu_mode 1
settings put system game_driver_gpu_mode 1
settings put system game_driver_fps_limit 120
) > /dev/null 2>&1 &

(
#Fps Injector 
setprop debug.graphics.game_default_frame_rate 120
setprop debug.graphics.game_default_frame_rate.disabled false
setprop persist.sys.gpu_perf_mode 1
setprop debug.mtk.powerhal.hint.bypass 1
setprop persist.sys.surfaceflinger.idle_reduce_framerate_enable false
setprop sys.surfaceflinger.idle_reduce_framerate_enable false
setprop debug.sf.perf_mode 1
settings put global refresh.active 1
setprop debug.hwui.disable_vsync true
setprop debug.performance.profile 1
setprop debug.perf.tuning 1
) > /dev/null 2>&1 &
(
#New Tweak Fps Lock
settings put system user_refresh_rate 120
settings put system fps_limit 120
settings put system max_refresh_rate_for_ui 120
settings put system hwui_refresh_rate 120
settings put system display_refresh_rate 120
settings put system max_refresh_rate_for_gaming 120
#Mengatur margin Fps
settings put system fstb_target_fps_margin_high_fps 20
settings put system fstb_target_fps_margin_low_fps 20
settings put system gcc_fps_margin 10
#remove Refresh rate
settings put system tran_low_battery_60hz_refresh_rate.support 0
# Lock refresh rate to 120 Hz
settings put system vendor.display.refresh_rate 120
settings put system user_refresh_rate 1
settings put system sf.refresh_rate120
settings put secure user_refresh_rate 1
settings put secure miui_refresh_rate 120
settings put system min_frame_rate 120
settings put system max_frame_rate 120
settings put system tran_refresh_mode 120
settings put system last_tran_refresh_mode_in_refresh_setting 120
settings put global min_fps 120
settings put global max_fps 120
settings put system tran_need_recovery_refresh_mode 120
settings put system display_min_refresh_rate 120
settings put system min_refresh_rate 120
settings put system max_refresh_rate 120
settings put system peak_refresh_rate 120
settings put secure refresh_rate_mode 120
settings put system thermal_limit_refresh_rate 120
settings put system NV_FPSLIMIT 120
settings put system fps.limit.is.now locked
) > /dev/null 2>&1 &
(
for sensor in cpu0 gpu0 npu0 apu0 dsp0 tpu0 vpu0 isp0 spu0 dpu0 pim0 skin pmic0 ddr0 ufs0 modem0 battery
do
    type=$(echo $sensor | tr a-z A-Z)
    cmd thermalservice inject-temperature $type light $sensor 100000
done
) > /dev/null 2>&1

(
    cmd power set-fixed-performance-mode-enabled true
    settings put system POWER_PERFORMANCE_MODE_OPEN 1
    setprop debug.performance.tuning 1
    setprop debug.sf.perf_mode 1
    cmd thermalservice override-status 0
    setprop debug.thermal.cpu_thermal_throttle.disable 1
# spoof suhu
    cmd thermalservice inject-temperature CPU light cpu0 100.000
    cmd thermalservice inject-temperature GPU light gpu0 100.000
    setprop debug.gpu.thermal.temp 110
    settings put system battery.temp_high 80
    settings put global vendor.dfps.enable false
    settings put global vendor.smart_dfps.enable false
    settings put system virtual_thermal_thermal_zone false
    settings put global thermal_throttling 0
    settings put global thermal_pwrlevel 0
    #Disabled Thermal No Root (Gimick)
    setprop debug.init.svc.thermald stopped
    setprop debug.init.svc_debug_pid.vendor.thermal-hal-2-0.mtk stopped
    setprop debug.init.svc.thermal_manager stopped
    setprop debug.init.svc.thermal_mnt_hal_service stopped
    setprop debug.init.svc.thermal-engine stopped
    setprop debug.init.svc.vendor.thermal-hal-2-0.mtk stopped
    setprop debug.init.svc.thermal_core stopped
    setprop debug.ro.boottime.thermal_core stopped
    setprop debug.ro.boottime.vendor.thermal-hal-2-0.mtk stopped
    setprop debug.ro.vendor.mtk_thermal_2_0 stopped
    setprop debug.ro.boottime.thermal_core stopped
    setprop debug.ro.boottime.thermald stopped
    setprop debug.ro.boottime.vendor.thermal-hal-2-0.mtk stopped
    setprop debug.ro.vendor.mtk_thermal_2_0 stopped
    #Peforma Thermal Tuning (Non Root)
    settings put system bench_mark_mode 1
setprop debug.thermal_status 0
setprop debug.performance.tuning 1
setprop debug.thermal.cpu_thermal_throttle.disable 1
setprop debug.thermal.ambient_sensor.disable 1
setprop debug.cooling_name_thermal-devfreq 0
setprop debug.pid.sec-thermal-1-0 stopped
setprop debug.thermal_zone.display_hotplug_control 2
setprop debug.thermal_zone.battery_hotplug_control 2
setprop debug.mediatek.appgamepq_compress 1
setprop debug.mediatek.disp_decompress 1
setprop debug.mtk_tflite.target_nnapi 27
setprop debug.thermal_zone.gpu_threshold_temp 85
setprop debug.thermal_zone.cpu_threshold_temp 80
setprop debug.thermal_zone.display_threshold_temp 75
setprop debug.thermal_zone.camera_hotplug_control 2
setprop debug.thermal_zone.battery_threshold_temp 60
setprop debug.thermal_zone.camera_threshold_temp 80
setprop debug.thermal_zone.cpu_hotplug_control 2
setprop debug.thermal_zone.gpu_hotplug_control 2
setprop debug.power.throttling.disable 1
setprop debug.thermal.gpu_shader_clock_throttle.disable 1
setprop debug.thermal.gpu_core_clock_throttle.disable 1
setprop debug.thermal.gpu_power_throttle.disable 1
setprop debug.thermal.gpu_thermal_throttle.disable 1
setprop debug.thermal.gpu_memory_throttle.disable 1
setprop debug.thermal.gpu_fan_control.disable 1
setprop debug.thermal.gpu_boost.disable 0
setprop debug.thermal.gpu_control.disable 1
setprop debug.thermal.gpu_throttle.disabled 1
setprop debug.thermal.backlight.disabled 0
setprop debug.thermal.boost.disabled 0
setprop debug.thermal.inactive_delay.disabled 1
setprop debug.thermal.throttling.disable 1
setprop debug.thermal.profile.disable 0
setprop debug.thermal.throttle_ratio.disable 1
setprop debug.thermal.turbo_ratio_limit.disable 1
setprop debug.thermal.cooling_device_state.disable 1
setprop debug.thermal.dynamic_scheduling.disable 1
setprop debug.thermal.critical_temp.disable 1
setprop debug.thermal.threshold.disable 1
setprop debug.thermal.overheat_protection.disable 1
setprop debug.thermal.alert.disable 1
setprop debug.thermal.fan.disable 1
setprop debug.thermal.shutdown.disable 1
setprop debug.thermal.balance_algorithm 0
setprop debug.thermal.performance_mode.disable 1
setprop debug.thermal.force_fan_on.disable 0
setprop debug.thermal.critical_trip_point.disable 1
setprop debug.thermal.auto_thermal_disable 1
setprop debug.thermal.zone.disabled 1
setprop debug.thermal.trip_point.disabled 1
setprop debug.thermal.suspend.disabled 1
setprop debug.thermal.thermal_policy.disable 1
setprop debug.thermal.fan_disable 1
#Peformance Stability
setprop debug.performance.tuning 1 
setprop debug.egl.force_msaa false
setprop debug.hwui.use_gpu_pixel_buffers 1
setprop debug.hwui.target_cpu_time_percent 10
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.disable_vsync true
setprop debug.hwui.level 0
setprop debug.kill_allocating_task 0
setprop debug.gralloc.gfx_ubwc_disable 0
setprop debug.rs.default-CPU-driver 1
setprop debug.rs.forcecompat 1
setprop debug.rs.max-threads 8
setprop debug.choreographer.skipwarning 30
setprop debug.choreographer.frametime false
setprop debug.display.allow_non_native_refresh_rate_override 1
setprop debug.display.render_frame_rate_is_physical_refresh_rate 1
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.enable_transaction_tracing false
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.gpu_freq_indeks 7
setprop debug.sf.use_frame_rate_priority 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_gl_backpressure 1
setprop debug.atrace.tags.enableflags 0
setprop debug.cpurend.vsync false
setprop debug.composition.type gpu
setprop debug.checkjni 0
setprop debug.atrace.tags.enableflags 0
setprop debug.gr.numframebuffers 3
) > /dev/null 2>&1
(
#Thermal Unlock
setprop debug.sys.thermal.level 0
setprop debug.sys.thermal.protection 0
setprop debug.sys.thermal.enable_detailed 0
) > /dev/null 2>&1
# Fungsi untuk mendapatkan refresh rate maksimum dari layar
get_max_refresh_rate() {
    # Ganti ini dengan metode yang benar untuk mendapatkan refresh rate layar
    echo 60,90,120 # Contoh nilai, ganti dengan implementasi yang sesuai
}

# Dapatkan refresh rate maksimum yang didukung oleh layar
max_refresh_rate=$(get_max_refresh_rate)

# Sesuaikan dengan refresh rate yang didukung
if [ "$max_refresh_rate" -ge 144 ]; then
    refresh_rate=144
elif [ "$max_refresh_rate" -ge 120 ]; then
    refresh_rate=120
elif [ "$max_refresh_rate" -ge 90 ]; then
    refresh_rate=90
else
    refresh_rate=60
fi

# Terapkan pengaturan refresh rate
cmd device_config put system display_refresh_rate $refresh_rate
settings put secure user_refresh_rate $refresh_rate
settings put secure miui_refresh_rate $refresh_rate
settings put system min_frame_rate $refresh_rate
settings put system max_frame_rate $refresh_rate
settings put system tran_refresh_mode $refresh_rate
settings put system last_tran_refresh_mode_in_refresh_setting $refresh_rate
settings put global min_fps $refresh_rate
settings put global max_fps $refresh_rate
settings put system tran_need_recovery_refresh_mode $refresh_rate
settings put system display_min_refresh_rate $refresh_rate
settings put system min_refresh_rate $refresh_rate
settings put system max_refresh_rate $refresh_rate
settings put system peak_refresh_rate $refresh_rate
settings put secure refresh_rate_mode $refresh_rate
settings put system user_refresh_rate $refresh_rate
settings put system thermal_limit_refresh_rate $refresh_rate
settings put system NV_FPSLIMIT $refresh_rate
settings put system fps.limit.is.now locked

# Redirect output ke /dev/null
> /dev/null 2>&1 &