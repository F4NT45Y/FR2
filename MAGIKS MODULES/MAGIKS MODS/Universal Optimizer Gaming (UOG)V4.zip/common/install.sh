#!/system/bin/sh
# Frame Rate Extreme Mode - By ChatGPT

# mempercepat pemerosesan lapisan gpu, performance
setprop debug.hwc.dynThreshold 0.1
setprop debug.sf.frame_rate_multiple_threshold 999
setprop debug.app.performance_restricted false

# Phase offset untuk sinkronisasi super cepat
setprop debug.sf.early_phase_offset_ns -9999999999
setprop debug.sf.early_app_phase_offset_ns -9999999999
setprop debug.sf.early_gl_phase_offset_ns -9999999999
setprop debug.sf.early_gl_app_phase_offset_ns -9999999999
setprop debug.sf.high_fps_early_phase_offset_ns -9999999999
setprop debug.sf.high_fps_early_gl_phase_offset_ns -9999999999
setprop debug.sf.high_fps_late_app_phase_offset_ns -9999999999

# Nonaktifkan pembagi FPS, paksa maksimal
setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.use_phase_offsets_as_durations 1

# RenderEngine paksa ke GL langsung, tidak Vulkan lambat
setprop debug.renderengine.backend skiaglthreaded
setprop debug.hwui.renderer skiagl
setprop debug.hwui.use_vulkan false

# Optimizasi HWUI
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.disable_scissor_opt true
setprop debug.hwui.force_dark false
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 0
setprop debug.sf.enable_hwc_vds 1
setprop debug.systemuicompilerfilter speed
setprop debug.enabletr true
setprop debug.egl.hw 1
setprop debug.gralloc.gfx_ubwc_disable 0
setprop debug.mdpcomp.logs 0
setprop debug.performance.tuning 1
setprop debug.sf.hw 1
setprop debug.gr.swapinterval 0
setprop debug.egl.swapinterval 0

#setprop gamingV2
setprop debug.sf.early.app.duration 1000000
setprop debug.sf.early.sf.duration 1000000
setprop debug.sf.late.app.duration 1000000
setprop debug.sf.late.sf.duration 1000000

#touch kayak Abang Abangan 120fps
settings put secure touch_blocking_period 0.0
settings put secure tap_duration_thershold 0.0
settings put system pointer_speed 7
settings put secure long_press_timeout 50
settings put secure multi_press_timeout 0

#refresh rate yang min_refresh_rate kalian bisa ganti disesuaikan max refresh rate kalian di pengaturan
settings put system peak_refresh_rate 1
settings put system user_refresh_rate 1
settings put system max_refresh_rate 165
settings put system min_refresh_rate 60

#tambahan biar makin gacor bre
settings put global activity_manager_constants bg_max_cached_processes=0,fg_max_cached_processes=1,cached_max_age=300000,max_cached_processes=1,max_cached_empty_processes=0,max_cached_service_processes=0,max_empty_process_time=300000,max_service_process_time=300000,max_empty_cached_processes=0,fg_service_compaction_threshold=4096,compaction_time_bg=300000,compaction_time_fg=60000,compact_full_rss_throttle=512,compact_throttle_1=4096,compact_throttle_2=8192,compact_statsd_sample_rate=1.0

echo "[✓] Game Mode: EXTREME Activated!"


cmd notification post -S bigtext -t 'SUCCESS🔥' 'Tag' "Module active ⚡