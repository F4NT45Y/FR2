game_packages="com.je.supersus,com.ea.gp.maddennfl21mobile,com.gravity.roo.sea,com.sega.pjsekai,com.gameark.ggplay.lonsea,com.nekki.shadowfightarena,com.pubg.krmobile,com.WandaSoftware.TruckersofEurope3,com.maleo.bussimulatorid,com.gameloft.android.ANMP.GloftA9HM,com.legotca.gwb,com.natsume.home,com.winlator,com.HoYoverse.Nap,com.excelliance.multiaccounts,com.mojang.minecraftpe.patch,com.kakaogames.gdts,xyz.aethersx2.android,com.zane.stardewvalley,com.lilithgame.roc.gp,jp.konami.pesam,net.kdt.pojavlaunch.zh,com.miHoYo.GenshinImpact,com.miHoYo.bh3oversea,com.mobile.legends,com.tencent.ig,com.garena.game.codm,com.dts.freefireth,com.kurogame.gplay.punishing.grayraven.en,com.dts.freefiremax,com.mobilelegends.mi,com.proximabeta.mf.uamo,com.proximabeta.mf.liteuamo,com.netease.newspike,com.activision.callofduty.warzone,com.carxtech.sr,com.miraclegames.farlight84,com.ea.gp.fifamobile,com.levelinfinite.sgameGlobal,com.tencent.iglite,com.GlobalSoFunny.Sausage,com.netmarble.sololv,com.kurogame.wutheringwaves.global,com.blizzard.diablo.immortal,com.roblox.client,com.mobilelegends.hwag,com.AlfaBravo.CombatMaster,com.ss.android.ugc.trill,com.mojang.minecraftpe,com.garena.game.kgid,com.NTRMAN.camWithMom,net.kdt.pojavlaunch,com.gamedevltd.wwh,net.kdt.pojavlaunch.firefly"
settings put global updatable_driver_prerelease_opt_in_apps "$game_packages" > /dev/null 2>&1

(
setprop debug.egl.force_msaa false; setprop debug.egl.force_fxaa false; setprop debug.egl.force_taa false; setprop debug.cpurend.vsync false; setprop debug.gpurend.vsync false; setprop debug.cpuprio 7; setprop debug.gpuprio 7; setprop debug.ioprio 7; setprop debug.hwui.target_cpu_time_percent 100; setprop debug.hwui.target_gpu_time_percent 100; setprop debug.hwui.use_hint_manager 1; setprop debug.renderer.process compound; setprop debug.hwui.disable_draw_defer true; setprop debug.hwui.disable_draw_reorder true; setprop debug.qsg_renderer 1; setprop debug.hwui.fps_divisor -1; setprop debug.sf.showfps 0; setprop debug.sf.hw 0; setprop debug.scenegraph.batching_performance 1; setprop debug.sf.disable_client_composition_cache 1; setprop debug.dev.ssrm.turbo true; setprop debug.dev.disable_sched_boost true; setprop debug.rs.default-CPU-buffer 262144; setprop debug.javafx.animation.fullspeed true; setprop debug.javafx.animation.framerate 120; setprop debug.composition.type mdp; setprop debug.gr.swapinterval 0; setprop debug.fb.rgb565 1; setprop debug.enabletr false; setprop debug.systemuicompilerfilter speed; setprop debug.rs.precision rs_fp_full; setprop debug.disable.hwacc 0; setprop debug.qctwa.preservebuf 1; setprop debug.MB.running 72; setprop debug.MB.inner.running 24; setprop debug.app.performance_restricted false; setprop debug.rs.max-threads 8; setprop debug.rs.min-threads 8; setprop debug.gr.numframebuffer 0; setprop debug.power_management_mode pref_max,setprop debug.sf.kernel_idle_timer_update_overlay true,setprop debug.sf.support_kernel_idle_timer_enabled true,setprop debug.hwui.multi_renderer.use true,setprop debug.sf.enable_fb_ubwc 1,setprop debug.hwc.perf_mode 3,setprop debug.hwui.force_async true,setprop debug.hwui.optimized_texture_upload false,setprop debug.touchscreen.latency.scale 0,5
settings put global activity_manager_constants max_cached_processes=1024
settings put system pointer_speed 7
settings put global max_cached_processes 22900
settings put global background_settle_time 0
settings put global fgservice_min_shown_time 0
settings put global fgservice_min_report_time 0
settings put global fgservice_screen_on_before_time 0
settings put global fgservice_screen_on_after_time 0
settings put global content_provider_retain_time 0
settings put global gc_timeout 0
settings put global full_pss_min_interval 0
settings put global full_pss_lowered_interval 0
settings put global power_check_interval 0
settings put global power_check_max_cpu_1 0
settings put global power_check_max_cpu_2 0
settings put global power_check_max_cpu_3 0
settings put global restricted_device_performance 1,1
settings put global activity_manager_constants max_cached_processes=0
setprop debug.app.performance_restricted true
cmd thermalservice override-status 4

# Grafik halus
setprop persist.graphics.smooth_mode 1
setprop persist.graphics.performance_boost 1
setprop persist.graphics.low_latency 1

setprop debug.hwui.renderer skiagl
setprop debug.hwui.use_vulkan true
setprop debug.sf.enable_hwc_vds true
)> /dev/null 2>&1

(
# SPOOF FAKE DEVICE NON ROOT - ROG 游戏手机 9 (Global 24117RK2CC)
settings put global device_name "ROG 游戏手机 9"
settings put system model "ROG 游戏手机 9"
settings put global ro.product.model "ROG 游戏手机 9"
settings put global ro.product.manufacturer POCO
settings put global ro.vendor.product.cpu.abilist arm64-v8a
settings put global ro.product.brand POCO
settings put global ro.product.device 24117RK2CC
settings put global ro.product.manufacturer POCO
settings put global ro.product.model 24117RK2CC
settings put global product.marketname "ROG 游戏手机 9"
settings put global ro.soc.vendor Qualcomm
settings put global ro.product.system_ext.brand POCO 
settings put global ro.product.system_ext.device 24117RK2CC
settings put global ro.product.system_ext.manufacturer POCO
settings put global ro.product.system_ext.marketname "ROG 游戏手机 9"
settings put global ro.product.vendor.cert "ROG 游戏手机 9"
settings put global ro.product.Aliases 24117RK2CC
settings put global ro.build.tf.modelnumber 24117RK2CC
settings put global ro.soc.model SM8750
settings put global ro.soc.vendor Qualcomm
settings put global ro.soc.manufacturer "Qualcomm Technologies, Inc."
settings put global ro.soc.model "Snapdragon 8 Gen 4"
settings put global ro.product.cpu.abi "arm64-v8a"
settings put global ro.product.cpu.abilist "arm64-v8a,armeabi-v7a,armeabi"
settings put global ro.product.cpu.name "Snapdragon™ 8 Gen 4"
settings put global ro.hardware.chipname "Snapdragon™ 8 Gen 4"
settings put global ro.vendor.qti.chip_name SM8750-AB
) > /dev/null 2>&1

#magiks Vexiro 
#Conserving or optimizing battery usage on devices, such as 
#smartphones or tablets, to make them last longer between 
#charges

pm disable --user 0 com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
dumpsys deviceidle whitelist -com.google.android.gms
pm disable com.google.android.gms/.chimera.GmsIntentOperationService > /dev/null 2>&1
settings put global activity_starts_logging_enabled 0
settings put global ble_scan_always_enabled 0
settings put global hotword_detection_enabled 0
settings put global mobile_data_always_on 0
settings put global network_recommendations_enabled 0
settings put global wifi_scan_always_enabled 0
settings put secure adaptive_sleep 0
settings put secure screensaver_activate_on_dock 0
settings put secure screensaver_activate_on_sleep 0
settings put secure screensaver_enabled 0
settings put secure send_action_app_error 0
settings put system air_motion_engine 0
settings put system air_motion_wake_up 0
settings put system intelligent_sleep_mode 0
settings put system master_motion 0
settings put system motion_engine 0
settings put system nearby_scanning_enabled 0
settings put system nearby_scanning_permission_allowed 0
settings put system rakuten_denwa 0
settings put system send_security_reports 0
settings put global cached_apps_freezer disabled
settings put global sem_enhanced_cpu_responsiveness 0
settings put global enhanced_processing 0
settings put global app_standby_enabled 0
settings put global adaptive_battery_management_enabled 0
settings put global app_restriction_enabled true
settings put system intelligent_sleep_mode 0
settings put secure adaptive_sleep 0
settings put global automatic_power_save_mode 0
settings put global low_power 0
settings put global dynamic_power_savings_enabled 0
settings put global dynamic_power_savings_disable_threshold 20
settings put system master_motion 0
settings put system motion_engine 0
settings put system air_motion_engine 0
settings put system air_motion_wake_up 0
settings put system intelligent_sleep_mode 0
settings put secure adaptive_sleep 0
settings put secure wake_locks_enabled 0
settings put secure location_scanning_interval 1800000
settings put global wifi_sleep_policy 2
settings put global window_animation_scale 0.85
settings put global transition_animation_scale 0.85
settings put global animator_duration_scale 0.85
settings put secure doze_always_on 1
settings put secure alarm_manager_constants 1
setprop debug.sv.disable.pers.cache true
setprop debug.sv.config.disable_rtt true
setprop debug.sv.config.stats 0
setprop debug.sv.log.slow_query_threshold 0
setprop debug.sv.atrace.tags.enableflags false
setprop debug.sv.egl.profiler 0
setprop debug.sv.enable.gamed false
setprop debug.sv.enable.wl_log false
setprop debug.sv.hwc.otf 0
setprop debug.sv.hwc_dump_en 0
setprop debug.sv.mdpcomp.logs 0
setprop debug.sv.qualcomm.sns.daemon 0
setprop debug.sv.qualcomm.sns.libsensor1 0
setprop debug.sf.ddms 0
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.dump 0
setprop debug.sv.sqlite.journalmode false
setprop debug.sv.test 0
setprop debug.sv.libc.debug.malloc 0
setprop debug.sv.log.shaders 0
setprop debug.sv.log.tag.all 0
setprop debug.sv.log.tag.stats_log 0
setprop debug.sv.log_ao 0
setprop debug.sv.log_frame_info 0
setprop debug.sv.logd.logpersistd.enable false
setprop debug.sv.logd.statistics 0
setprop debug.sv.media.metrics.enabled false
setprop debug.sv.media.metrics 0
setprop debug.sv.media.stagefright.log-uri 0
setprop debug.sv.net.ipv4.tcp_no_metrics_save 1
setprop debug.sv.anr.dumpthr 0
setprop debug.sv.persist.camera.debug.logfile 0
setprop debug.sv.camera.iface.logs 0
setprop debug.sv.camera.imglib.logs 0
setprop debug.sv.camera.isp.debug 0
setprop debug.sv.camera.mct.debug 0
setprop debug.sv.camera.sensor.debug 0
setprop debug.sv.data.qmi.adb_logmask 0
setprop debug.sv.sensors.hal 0
setprop debug.sv.wfd.enable false
setprop debug.sv.disable_inline_rotator true
setprop debug.sv.disable_skip_validate true
setprop debug.sv.miui.ndcd false
setprop debug.sv.wifitracing.started 0
setprop debug.sv.fm.a2dp.conc.disabled true
setprop debug.sv.vendor.vidc.debug.level 0
setprop debug.sv.vendor.vidc.enc.disable_bframes true
setprop debug.sv.vidc.debug.level 0
setprop debug.sv.video.disable.ubwc true
# Activity Manager Constants
settings put global activity_manager_constants "max_cached_processes=512,background_settle_time=1000,fgservice_min_shown_time=2000,fgservice_min_report_time=2000,fgservice_screen_on_before_time=2000,fgservice_screen_on_after_time=2000,content_provider_retain_time=5000,gc_timeout=10000,gc_min_interval=5000,full_pss_min_interval=10000,full_pss_lowered_interval=20000,power_check_interval=10000,power_check_max_cpu_1=60,power_check_max_cpu_2=70,power_check_max_cpu_3=80,power_check_max_cpu_4=90,service_usage_interaction_time=5000,usage_stats_interaction_interval=30000,service_restart_duration=5000,service_reset_run_duration=60000,service_min_restart_time_between=5000,service_max_inactivity=60000,service_bg_start_timeout=5000,CUR_MAX_CACHED_PROCESSES=10,CUR_MAX_EMPTY_PROCESSES=5,CUR_TRIM_EMPTY_PROCESSES=5,CUR_TRIM_CACHED_PROCESSES=5,service_min_restart_interval=2000,service_max_restart_count=3,service_memory_threshold=102400,bg_service_max_retries=1,fg_service_max_retries=2,process_lifetime=30000,service_expiry_time=60000,proc_start_timeout=2000,proc_bind_timeout=2000,proc_launch_time=3000,heavy_weight_proc_min_adjacency=500,service_restart_duration_factor=2,proc_state_cached_interval=60000,proc_state_bg_interval=120000,min_crash_interval=120000,trim_level_mod=0,service_max_runtime=300000,cpu_usage_collect_interval=60000,memory_usage_collect_interval=60000"

# Power Management Constants
settings put global memory_constants "low_memory_threshold=192000,high_memory_threshold=384000"
settings put global memory_constants "low_memory_threshold=128000,high_memory_threshold=256000"

# App Optimization
settings put global app_process_constants "bg_start_timeout=3000,fg_start_timeout=1000,app_process_max=1024"

# Doze Mode
settings put global doze_constants "doze_after_screen_off_time=300000,doze_max_idle_time=86400000"

# Vibration Settings
settings put global vibration_constants "min_vibration_time=5,max_vibration_time=100"

# Job Scheduler & Alarm Settings
settings put global job_scheduler_constants "max_job_count_active=50,max_session_count_active=50,rate_limiting_window_ms=20000"

# Network Management
settings put global network_management_constants "max_net_retries=1,net_reconnect_timeout=2000"

# Binder Calls Stats
settings put global binder_calls_stats "latency_observer_sharding_modulo=5"

# Foreground Service
settings put global fg_service_constants "fg_service_max_start_time=5000,fg_service_timeout=15000"

# Backup
settings put secure backup_manager_constants "key_value_backup_interval_milliseconds=600000"

# Battery Manager
settings put global battery_manager_constants "max_battery_saver_timeout=300"

# Miscellaneous
settings put global appop_history_parameters "mode=HISTORICAL_MODE_ENABLED,baseIntervalMillis=5000,intervalMultiplier=5"
settings put global autofill_compat_mode_allowed_packages "com.android.chrome[url_bar]:com.brave.browser[url_bar]:com.opera.browser[url_field]:com.opera.mini.native[url_bar]"
settings put global location_ignore_settings_package_whitelist "com.google.android.gms,com.google.android.dialer"

# Gaming Performance
settings put global cpu_gpu_constants "cpu_boost_threshold=50,gpu_boost_threshold=50,cpu_max_freq=1400000,gpu_max_freq=300000000,cpu_min_freq=300000,gpu_min_freq=200000000,cpu_affinity=0,1,2,3,gpu_affinity=0,1"
settings put global dynamic_frequency_scaling_constants "cpu_scaling_max=1400000,gpu_scaling_max=300000000,cpu_scaling_min=300000,gpu_scaling_min=200000000,cpu_interactive_target_load=75,gpu_interactive_target_load=75"
settings put global gaming_memory_constants "gaming_memory_alloc_size=2048,gaming_memory_optimize=true,memory_gc_threshold=100000,memory_swap_enable=true,large_cache_threshold=250000,low_memory_threshold_game=128000"
settings put global gaming_power_constants "gaming_performance_mode=false,max_cpu_performance=70,max_gpu_performance=75,cpu_power_saving_mode=true,gpu_power_saving_mode=true,disable_background_services=true,aggressive_power_saving_mode=true"

# Disable GMS packages
pm disable --user 0 com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm disable com.google.android.gms/.chimera.GmsIntentOperationService > /dev/null 2>&1

# Feature Flags (Disable)
settings put global activity_starts_logging_enabled 0
settings put global ble_scan_always_enabled 0
settings put global hotword_detection_enabled 0
settings put global mobile_data_always_on 0
settings put global network_recommendations_enabled 0
settings put global wifi_scan_always_enabled 0
settings put secure adaptive_sleep 0
settings put secure screensaver_activate_on_dock 0
settings put secure screensaver_activate_on_sleep 0
settings put secure screensaver_enabled 0
settings put secure send_action_app_error 0
settings put system air_motion_engine 0
settings put system air_motion_wake_up 0
settings put system intelligent_sleep_mode 0
settings put system master_motion 0
settings put system motion_engine 0
settings put system nearby_scanning_enabled 0
settings put system nearby_scanning_permission_allowed 0
settings put system rakuten_denwa 0
settings put system send_security_reports 0

# Background Processing & App Standby
settings put global cached_apps_freezer disabled
settings put global sem_enhanced_cpu_responsiveness 0
settings put global enhanced_processing 0
settings put global app_standby_enabled 0
settings put global adaptive_battery_management_enabled 0
settings put global app_restriction_enabled true

# Power Saving (Redundant/Consolidated)
settings put global automatic_power_save_mode 0
settings put global low_power 1 # Set low power mode
settings put global dynamic_power_savings_enabled 0
settings put global dynamic_power_savings_disable_threshold 20
settings put secure wake_locks_enabled 0
settings put secure location_scanning_interval 1800000
settings put global wifi_sleep_policy 2

# Animation Scales
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# Doze (Redundant/Consolidated)
settings put secure doze_always_on 1

# Alarm Manager
settings put secure alarm_manager_constants 1

# System Properties
setprop debug.sv.disable.pers.cache true
setprop debug.sv.config.disable_rtt true
setprop debug.sv.config.stats 0
setprop debug.sv.log.slow_query_threshold 0
setprop debug.sv.atrace.tags.enableflags false
setprop debug.sv.egl.profiler 0
setprop debug.sv.enable.gamed false
setprop debug.sv.enable.wl_log false
setprop debug.sv.hwc.otf 0
setprop debug.sv.hwc_dump_en 0
setprop debug.sv.mdpcomp.logs 0
setprop debug.sv.qualcomm.sns.daemon 0
setprop debug.sv.qualcomm.sns.libsensor1 0
setprop debug.sf.ddms 0
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.dump 0
setprop debug.sv.sqlite.journalmode false
setprop debug.sv.test 0
setprop debug.sv.libc.debug.malloc 0
setprop debug.sv.log.shaders 0
setprop debug.sv.log.tag.all 0
setprop debug.sv.log.tag.stats_log 0
setprop debug.sv.log_ao 0
setprop debug.sv.log_frame_info 0
setprop debug.sv.logd.logpersistd.enable false
setprop debug.sv.logd.statistics 0
setprop debug.sv.media.metrics.enabled false
setprop debug.sv.media.metrics 0
setprop debug.sv.media.stagefright.log-uri 0
setprop debug.sv.net.ipv4.tcp_no_metrics_save 1
setprop debug.sv.anr.dumpthr 0
setprop debug.sv.persist.camera.debug.logfile 0
setprop debug.sv.camera.iface.logs 0
setprop debug.sv.camera.imglib.logs 0
setprop debug.sv.camera.isp.debug 0
setprop debug.sv.camera.mct.debug 0
setprop debug.sv.camera.sensor.debug 0
setprop debug.sv.data.qmi.adb_logmask 0
setprop debug.sv.sensors.hal 0
setprop debug.sv.wfd.enable false
setprop debug.sv.disable_inline_rotator true
setprop debug.sv.disable_skip_validate true
setprop debug.sv.miui.ndcd false
setprop debug.sv.wifitracing.started 0
setprop debug.sv.fm.a2dp.conc.disabled true
setprop debug.sv.vendor.vidc.debug.level 0
setprop debug.sv.vendor.vidc.enc.disable_bframes true
setprop debug.sv.vidc.debug.level 0
setprop debug.sv.video.disable.ubwc true
setprop persist.sys.bg_daemon_enable false

# Thermal & Power Management Commands
cmd thermalservice override-status 0 > /dev/null 2>&1
cmd power set-fixed-performance-mode-enabled 0 > /dev/null 2>&1
cmd power set-adaptive-power-saver-enabled 1 > /dev/null 2>&1 # Enable adaptive power saver
cmd power set-mode 1 # Set to power save mode

# Location Services (Disable)
pm disable-user --user 0 com.google.android.location.fused
pm disable-user --user 0 com.google.android.gms.location.history

# Power Performance Modes (Redundant/Consolidated)
settings put system POWER_PERFORMANCE_MODE_OPEN 0
settings put system POWER_BALANCED_MODE_OPEN 1
settings put system POWER_SAVE_MODE_OPEN 1

(
#Fps Injector 
setprop debug.graphics.game_default_frame_rate 120
setprop debug.graphics.game_default_frame_rate.disabled false
setprop persist.sys.gpu_perf_mode 1
setprop debug.mtk.powerhal.hint.bypass 1
setprop persist.sys.surfaceflinger.idle_reduce_framerate_enable false
setprop sys.surfaceflinger.idle_reduce_framerate_enable false
setprop debug.sf.perf_mode 1
settings put global refresh.active 1
setprop debug.hwui.disable_vsync true
setprop debug.performance.profile 1
setprop debug.perf.tuning 1
setprop debug.hwc.dynThreshold 6.0
setprop debug.sf.frame_rate_multiple_threshold 60
setprop debug.sf.high_fps_early_phase_offset_ns -99999999
setprop debug.sf.high_fps_early_gl_phase_offset_ns -99999999
setprop debug.sf.high_fps_late_app_phase_offset_ns -99999999
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 0

#Unlock Performance Mode
cmd power set-fixed-performance-mode-enabled true
cmd power set-adaptive-power-saver-enabled false

# Game support 120 FPS
device_config put game_overlay com.netease.newspike mode=2,fps=120:mode=3,fps=60 
device_config put game_overlay com.miHoYo.GenshinImpact mode=2,fps=120:mode=3,fps=60
device_config put game_overlay com.garena.game.codm mode=2,fps=120:mode=3,fps=60
device_config put game_overlay com.riotgames.league.wildrift mode=2,fps=120:mode=3,fps=60
device_config put game_overlay com.mobile.legends mode=2,fps=120:mode=3,fps=60
device_config put game_overlay com.tencent.ig mode=2,fps=120:mode=3,fps=60
device_config put game_overlay com.mobile.legends.hwag mode=2,fps=120:mode=3,fps=60
device_config put game_overlay com.mobile.legends.mi mode=2,fps=120:mode=3,fps=60
device_config put game_overlay com.garena.game.df mode=2,fps=120:mode=3,fps=60
device_config put game_overlay com.tencent.tmgp.sgame mode=2,fps=120:mode=3,fps=60
device_config put game_overlay com.roblox.client mode=2,fps=120:mode=3,fps=60

# Game support 90 FPS
device_config put game_overlay com.dts.freefireth mode=2,fps=90:mode=3,fps=60
device_config put game_overlay com.dts.freefiremax mode=2,fps=90:mode=3,fps=60
device_config put game_overlay com.garena.game.kgvn mode=2,fps=90:mode=3,fps=60


#Set Performance Mode
cmd game mode performance com.netease.newspike
cmd game mode performance com.miHoYo.GenshinImpact
cmd game mode performance com.garena.game.codm
cmd game mode performance com.riotgames.league.wildrift
cmd game mode performance com.mobile.legends
cmd game mode performance com.tencent.ig
cmd game mode performance com.mobile.legends.hwag
cmd game mode performance com.mobile.legends.mi
cmd game mode performance com.garena.game.df
cmd game mode performance com.tencent.tmgp.sgame
cmd game mode performance com.roblox.client  
cmd game mode performance com.dts.freefireth
cmd game mode performance com.dts.freefiremax
cmd game mode performance com.garena.game.kgvn 

) > /dev/null 2>&1 &

(
settings put global touch.pressure.scale 0.1
settings put global touch.size.scale 0.1
settings put global transition_animation_scale 0
settings put global window_animation_scale 0
settings put global settings_enable_monitor_phantom_procs false
settings put system pointer_speed 5
settings put global surface_flinger.set_idle_timer_ms 0
settings put global surface_flinger.set_touch_timer_ms 0
settings put global surface_flinger.set_display_power_timer_ms 0
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.multithreaded_present true
settings put global surface_flinger.use_context_priority 1
) > /dev/null 2>&1

(
#V19
settings put system touch_sampling_rate 120
settings put system touch_size_calibration geometric
settings put system touch_stats {"min":1,"max":1}
settings put system touchX_debuggable 1
settings put system touch_boost_threshold 5
settings put system touch_feature_gamemode_enable 1
settings put system touch_input_sensitivity 1
settings put system touch_rate_control 0
settings put system touch_response_rate 1
settings put system touch_sampling_rate_override 1
settings put system touch_sensitivity 1_2
settings put system touch_slop 8
settings put system touch_switch_set_touchscreen 14005
settings put system touch_tap_sensitivity 1
settings put system touchpanel_game_switch_enable 1
) > /dev/null 2>&1

(
#V18
settings put global surface_flinger.start_graphics_allocator_service true
settings put global surface_flinger.running_without_sync_framework true
setprop debug.sf.luma_sampling 0
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.enable_layer_caching 0
setprop debug.sf.disable_client_composition_cache 1 
setprop debug.sf.enable_gl_backpressure false
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.hw 0
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.use_phase_offsets_as_durations 1
#V17SCREEN.TOUCH
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.late.sf.duration 10500000
setprop debug.sf.late.app.duration 16600000
setprop debug.sf.treat_170m_as_sRGB 1
setprop debug.sf.earlyGl.app.duration 16600000
setprop debug.sf.frame_rate_multiple_threshold 120
setprop debug.boot.fps 20
#V16 Faster Touch 
setprop debug.performance.tuning 1
settings put system view.scroll_friction 0
settings put global windowsmgr.support_low_latency_touch true
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.disable_vsync true
settings put system haptic_feedback_intensity 50
settings put global tactile_feedback_enabled 1
debug.sf.set_touch_timer_ms 100
###
setprop debug.MultitouchSettleInterval 0.01ms
setprop debyg.MultitouchMinDistance 0.01px
setprop debug.TapInterval 0.1ms
settings put global fw.bservice_enable true
settings put global fw.bg_apps_limit 4
settings put global fw.bservice_limit 4
settings put global fw.bservice_age 10000
setprop debug.touch.pressure.scale 0.001
setprop debug.touch_move_opt 1
setprop debug.touch_vsync_opt 1
setprop debug.touch.size.bias 0 
setprop debug.TapSlop1px
settings put global windowsmgr.max_events_per_sec 180
settings put global min_pointer_dur 8
settings put global product.multi_touch_enabled true
settings put global securestorage.knox false
setprop debug.security.mdpp none
setprop debug.security.mdpp.result none
settings put system af.resampler.quality 255
settings put system scrollingcache 3
setprop debug.service.lgospd.enable 0
setprop debug.service.pcsync.enable 0
setprop debug.touch.deviceTypetouchScreen
cmd device_config put input default_key_press_repeat_rate 33
cmd device_config put input filtered_accel_event_rate_hz 240
cmd device_config put input touch_screen_sample_interval_ms 8
cmd device_config put systemui cg_frame_interval_millis 4
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui cg_max_frame_skip 8
settings put system service.touch.tpf 30
settings put system lowThreshold 0
settings put system highThreshold 0
settings put system VirtualKeyQuietTime 0
settings put system KeyRepeatDelay 0
settings put system KeyRepeatTimeout 0
setprop debug.boosterorientnosync 1
settings put global sf.disable_smooth_effect true
settings put secure touch_distance_scale 0
settings put secure view_scroll_friction 0
settings put secure multi_touch_enabled 1
settings put secure assist_touch_gesture_enabled 0
settings put global maximum_obscuring_opacity_for_touch 0.5
settings put system show_touches 0
settings put global block_untrusted_touches 0
settings put system vsync.disable.fps.limit 1
settings put system table.framerate 120
setprop debug.touch.deviceType touchScreen
settings put system disable.hwc.delay 1
settings put system Touc_xRotation  360
settings put system touchswipedeadzone 5
settings put secure long_press_timeout 300
settings put secure multi_press_timeout 300
settings put secure touch_size_scale 5
settings put secure show_rotation_suggestions 0
settings put secure touch_size_bias 5
settings put secure touch_exploration_enabled 1
settings put secure touch_orientationAware 1
settings put secure touch_pressure_scale 0.00000125
settings put system touchscreen_hovering 0
settings put system touchscreen_sensitivity_mode 3
settings put system touchscreen_pressure_calibration 1023
settings put system touchscreen_threshold 9
settings put system touchfeature.gamemode.enable true
settings put system r.setframepace 120
settings put system touch_switch_set_touchscreen 14005
settings put system touchpanel_game_switch_enable 1
settings put system touchpanel_oppo_tp_direction 1
settings put system touchpanel_oppo_tp_limit_enable 0
settings put system touchpanel_oplus_tp_limit_enable 0
settings put system touchpanel_oplus_tp_direction 1
settings put system use_dithering 0
settings put system use_dithering false
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.1
settings put global DragMinSwitchSpeed 99999.0px/s
settings put global SwipeMaxWidthRatio 1
settings put system MovementSpeedRatio 1
settings put system ZoomSpeedRatio 1
settings put system SwipeTransitionAngleCosine 3.6
settings put system mot.proximity.distance 1
settings put system PointerVelocityControlParameters 1
settings put system device.internal 1
setprop debug.performance.tuning 1
setprop debug.egl.swapinterval 90
settings put secure dev.pm.dyn_samplingrate 1
settings put system touchscreen_sensitivity 10
settings put system touchscreen_min_press_time 50
settings put system touchscreen_hevoring 0
settings put system touchscreen_gesture_mode 1
settings put system touchscreen_sensitivity_threshold 9
settings put system touchscreen_double_tap_speed 75
settings put system touchscreen_sensitivity_scale 1.5
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.6
settings put system touch.orientationAware 1
settings put system SurfaceOrientation auto
settings put system touch.size.calibration geometric
settings put system touch.size.isSummed 1
settings put system touch.orientation.calibration auto
settings put system touch.distance.scale auto
settings put system touch.coverage.calibration octagram
settings put system touch.gesturemode spots
settings put system MovementSpeedRatio auto
settings put system pm.dyn_samplingrate 9999999999999999999999999999
settings put system touch.pressure.calibration auto
settings put system scroll.accelerated.hw true
settings put system ui.hwframes 9999999999999999999999999999
settings put system force_high_end_gfx 1
settings put system sf.disable_smooth_effect true
settings put system max_num_touch auto
settings put system maxeventspersec 9999999999999999999999999999
settings put system resampler.quality 255
settings put system touch.sampling rate 720
settings put system adaptive_touch_sensitivity speed
settings put system touch.orientationAware 0
settings put system PressureForID 0.01
settings put system QuietInterval 0.1ms
settings put system MultitouchMinDistance 1px
settings put system AIM_SENSITIVITY_TRANSITION_TIME GRADUAL
settings put system APP_SWITCH_DELAY_TIME false
settings put system AbsoluteXForID SpeedForID
settings put system AccelerationX true
settings put system AccelerationY true
settings put system DoubleTouch OEM
settings put system PowerbuttonTapping 0
settings put system touch.assistant.enabled 0
settings put system type.touch_speed true
settings put system MovementSpeedRatio 0.8
settings put system accuracy.control 100
settings put system view_scroll_friction 10
settings put secure multi_press_timeout 300
settings put global KeyRepeatDelay 0
settings put global KeyRepeatTimeout 0
settings put global LOSS_OF_FOCUS_BY_MOUSE_MOVEMENT DISABLED
settings put global MOUSEX_AIM_LEVEL 95%
) > /dev/null 2>&1

(
#New Tweak Fps Lock
settings put system user_refresh_rate 120
settings put system fps_limit 120
settings put system max_refresh_rate_for_ui 120
settings put system hwui_refresh_rate 120
settings put system display_refresh_rate 120
settings put system max_refresh_rate_for_gaming 120
#Mengatur margin Fps
settings put system fstb_target_fps_margin_high_fps 20
settings put system fstb_target_fps_margin_low_fps 20
settings put system gcc_fps_margin 10
#remove Refresh rate
settings put system tran_low_battery_60hz_refresh_rate.support 0
# Lock refresh rate to 120 Hz
settings put system vendor.display.refresh_rate 120
settings put system user_refresh_rate 1
settings put system sf.refresh_rate120
settings put secure user_refresh_rate 1
settings put secure miui_refresh_rate 120
settings put system min_frame_rate 120
settings put system max_frame_rate 120
settings put system tran_refresh_mode 120
settings put system last_tran_refresh_mode_in_refresh_setting 120
settings put global min_fps 120
settings put global max_fps 120
settings put system tran_need_recovery_refresh_mode 120
settings put system display_min_refresh_rate 120
settings put system min_refresh_rate 120
settings put system max_refresh_rate 120
settings put system peak_refresh_rate 120
settings put secure refresh_rate_mode 120
settings put system thermal_limit_refresh_rate 120
settings put system NV_FPSLIMIT 120
settings put system fps.limit.is.now locked
) > /dev/null 2>&1 &
{
    setprop debug.composition.type gpu
    setprop debug.composition.type c2d
    setprop debug.hwui.renderer skiagl
    setprop debug.gr.swapinterval -60
    setprop debug.gr.numframebuffers 3
    setprop debug.egl.buffcount 4
    setprop debug.egl.force_msaa 1
    setprop debug.cpurend.vsync false
    setprop debug.enabletr true
    setprop debug.overlayui.enable 1
    setprop debug.egl.hw 0
    setprop debug.gralloc.gfx_ubwc_disable 0
    setprop debug.mdpcomp.logs 0
    setprop debug.egl.hw 1
    setprop debug.egl.profiler 0
    setprop debug.performance.tuning 1
    setprop debug.sf.hw 1
    setprop debug.egl.swapinterval -60
    setprop debug.renderengine.backend skiagl
    setprop debug.renderengine.backend skiaglthreaded
    setprop debug.angle.overlay FPS:skiagl*PipelineCache*
    setprop debug.javafx.animation.framerate 120
    setprop debug.systemuicompilerfilter speed
    setprop debug.app.performance_restricted false
    setprop debug.sf.set_idle_timer_ms 30
    setprop debug.sf.disable_backpressure 1
    setprop debug.sf.latch_unsignaled 1
    setprop debug.sf.enable_hwc_vds 1
    setprop debug.sf.early_phase_offset_ns 500000
    setprop debug.sf.early_app_phase_offset_ns 500000
    setprop debug.sf.early_gl_phase_offset_ns 3000000
    setprop debug.sf.early_gl_app_phase_offset_ns 15000000
    setprop debug.sf.high_fps_early_phase_offset_ns 6100000
    setprop debug.sf.high_fps_late_sf_phase_offset_ns 8000000
    setprop debug.sf.high_fps_early_gl_phase_offset_ns 9000000
    setprop debug.sf.high_fps_late_app_phase_offset_ns 1000000
    setprop debug.sf.high_fps_late_sf_phase_offset_ns 8000000
    setprop debug.sf.high_fps_early_gl_phase_offset_ns 9000000
    setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000
    setprop debug.sf.showfps 0
    setprop debug.sf.showcpu 0
    setprop debug.sf.showbackground 0
    setprop debug.sf.shoupdates 0
} > /dev/null 2>&1

# Activity Manager Constants
settings put global activity_manager_constants "max_cached_processes=512,background_settle_time=1000,fgservice_min_shown_time=2000,fgservice_min_report_time=2000,fgservice_screen_on_before_time=2000,fgservice_screen_on_after_time=2000,content_provider_retain_time=5000,gc_timeout=10000,gc_min_interval=5000,full_pss_min_interval=10000,full_pss_lowered_interval=20000,power_check_interval=10000,power_check_max_cpu_1=60,power_check_max_cpu_2=70,power_check_max_cpu_3=80,power_check_max_cpu_4=90,service_usage_interaction_time=5000,usage_stats_interaction_interval=30000,service_restart_duration=5000,service_reset_run_duration=60000,service_min_restart_time_between=5000,service_max_inactivity=60000,service_bg_start_timeout=5000,CUR_MAX_CACHED_PROCESSES=10,CUR_MAX_EMPTY_PROCESSES=5,CUR_TRIM_EMPTY_PROCESSES=5,CUR_TRIM_CACHED_PROCESSES=5,service_min_restart_interval=2000,service_max_restart_count=3,service_memory_threshold=102400,bg_service_max_retries=1,fg_service_max_retries=2,process_lifetime=30000,service_expiry_time=60000,proc_start_timeout=2000,proc_bind_timeout=2000,proc_launch_time=3000,heavy_weight_proc_min_adjacency=500,service_restart_duration_factor=2,proc_state_cached_interval=60000,proc_state_bg_interval=120000,min_crash_interval=120000,trim_level_mod=0,service_max_runtime=300000,cpu_usage_collect_interval=60000,memory_usage_collect_interval=60000"

# Power Management Constants
settings put global memory_constants "low_memory_threshold=192000,high_memory_threshold=384000"
settings put global memory_constants "low_memory_threshold=128000,high_memory_threshold=256000"

# App Optimization
settings put global app_process_constants "bg_start_timeout=3000,fg_start_timeout=1000,app_process_max=1024"

# Doze Mode
settings put global doze_constants "doze_after_screen_off_time=300000,doze_max_idle_time=86400000"

# Vibration Settings
settings put global vibration_constants "min_vibration_time=5,max_vibration_time=100"

# Job Scheduler & Alarm Settings
settings put global job_scheduler_constants "max_job_count_active=50,max_session_count_active=50,rate_limiting_window_ms=20000"

# Network Management
settings put global network_management_constants "max_net_retries=1,net_reconnect_timeout=2000"

# Binder Calls Stats
settings put global binder_calls_stats "latency_observer_sharding_modulo=5"

# Foreground Service
settings put global fg_service_constants "fg_service_max_start_time=5000,fg_service_timeout=15000"

# Backup
settings put secure backup_manager_constants "key_value_backup_interval_milliseconds=600000"

# Battery Manager
settings put global battery_manager_constants "max_battery_saver_timeout=300"

# Miscellaneous
settings put global appop_history_parameters "mode=HISTORICAL_MODE_ENABLED,baseIntervalMillis=5000,intervalMultiplier=5"
settings put global autofill_compat_mode_allowed_packages "com.android.chrome[url_bar]:com.brave.browser[url_bar]:com.opera.browser[url_field]:com.opera.mini.native[url_bar]"
settings put global location_ignore_settings_package_whitelist "com.google.android.gms,com.google.android.dialer"

# Gaming Performance
settings put global cpu_gpu_constants "cpu_boost_threshold=50,gpu_boost_threshold=50,cpu_max_freq=1400000,gpu_max_freq=300000000,cpu_min_freq=300000,gpu_min_freq=200000000,cpu_affinity=0,1,2,3,gpu_affinity=0,1"
settings put global dynamic_frequency_scaling_constants "cpu_scaling_max=1400000,gpu_scaling_max=300000000,cpu_scaling_min=300000,gpu_scaling_min=200000000,cpu_interactive_target_load=75,gpu_interactive_target_load=75"
settings put global gaming_memory_constants "gaming_memory_alloc_size=2048,gaming_memory_optimize=true,memory_gc_threshold=100000,memory_swap_enable=true,large_cache_threshold=250000,low_memory_threshold_game=128000"
settings put global gaming_power_constants "gaming_performance_mode=false,max_cpu_performance=70,max_gpu_performance=75,cpu_power_saving_mode=true,gpu_power_saving_mode=true,disable_background_services=true,aggressive_power_saving_mode=true"

{
    dumpsys deviceidle force-idle
    settings put global battery_tip_constans app_restriction_enabled=false
    settings put global power_check_max_cpu_1 75
    settings put global power_check_max_cpu_2 75
    settings put global power_check_max_cpu_3 50
    settings put global power_check_max_cpu_4 50
    device_config put activity_manager_native_boot use_freezer true
    settings put system pointer_speed 7
    settings put global cached_apps_freezer 1
    settings put system peak_refresh_rate 120.0
    settings put system min_refresh_rate 120.0
    settings put system user_refresh_rate 120.0
    settings put global activity_manager_constants max_cached_processes 3023 
    cmd thermalservice override-status 0
    cmd power set-fixed-performance-mode-enabled true
} > /dev/null 2>&1
{
        device_config put game_overlay com.mobile.legends mode=2,skiagl=1,downscaleFactor=0.6,fps=120:mode=3,skiagl=0,downscaleFactor=0.6,fps=120
        cmd game mode performance com.mobile.legends
        cmd package compile -m speed-profile -f com.mobile.legends
        dumpsys deviceidle whitelist +com.mobile.legends
        settings delete global updatable_driver_production_opt_in_apps
        settings delete global game_driver_opt_in_apps
        settings delete global updatable_driver_production_opt_out_apps
        settings delete global updatable_driver_prerelease_opt_in_apps
        settings put global updatable_driver_prerelease_opt_in_apps "com.mobile.legends"
    } > /dev/null 2>&1
done

(
settings put global tran_low_battery_60hz_refresh_rate.support 0
settings put system surfaceflinger.idle_reduce_framerate_enable false
setprop debug.hwui.disable_scissor_opt false
setprop debug.hwui.texture_cache_flushrate 0.4
setprop debug.hwui.texture_cache_size 72
setprop debug.hwui.layer_cache_size 48
setprop debug.hwui.r_buffer_cache_size 8
setprop debug.hwui.path_cache_size 32
setprop debug.hwui.gradient_cache_size 1
setprop debug.hwui.drop_shadow_cache_size 6
setprop debug.gr.numframebuffers 3
settings put global perf.scroll_opt 1
settings put global perf.framepacing.enable 1
settings put system cpu.freq.boost 1
setprop debug.PERF_RES_NET_BT_AUDIO_LOW_LATENCY 1
setprop debug.PERF_RES_NET_WIFI_LOW_LATENCY 1
setprop debug.PERF_RES_NET_MD_WEAK_SIG_OPT 1
setprop debug.PERF_RES_NET_NETD_BOOST_UID 1
setprop debug.PERF_RES_NET_MD_HSR_MODE 1
setprop debug.PERF_RES_THERMAL_POLICY -1
#V7.0
settings put global force_gpu_rendering 1
settings put global low_power 0
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5
#V6.0
# UI & Animation Enhancements
setprop debug.sf.high_fps_early_gl_phase_offset_ns -2000000
setprop debug.sf.high_fps_early_phase_offset_ns -4000000
setprop debug.sf.high_fps_late_app_phase_offset_ns 1000000
setprop debug.sf.high_fps_late_sf_phase_offset_ns -2000000
settings put global vendor.dfps.enable false
settings put global vendor.display.default_fps 120
settings put global vendor.display.fod_monitor_default_fps 120
settings put global vendor.display.idle_default_fps 120
settings put global vendor.display.video_or_camera_fps.support true
settings put global vendor.fps.switch.defaul true
settings put global vendor.fps.switch.thermal true
settings put global vendor.display.disable_mitigated_fps 1
settings put global vendor.display.enable_dpps_dynamic_fps 0
#V5.0
# Mematikan fitur yang mengganggu performa
settings put global auto_sync 0
settings put global ble_scan_always_enabled 0
settings put global wifi_scan_always_enabled 0
settings put global hotword_detection_enabled 0
settings put global activity_starts_logging_enabled 0
settings put global network_recommendations_enabled 0
settings put secure adaptive_sleep 0
settings put secure screensaver_enabled 0
settings put secure send_action_app_error 0
settings put system motion_engine 0
settings put system master_motion 0
settings put system air_motion_engine 0
settings put system air_motion_wake_up 0
settings put system send_security_reports 0
settings put system intelligent_sleep_mode 0
settings put system nearby_scanning_enabled 0
settings put system nearby_scanning_permission_allowed 0
# Menonaktifkan layanan Qualcomm yang tidak diperlukan
pm disable com.qualcomm.qti.cne
pm disable com.qualcomm.location.XT
# Menonaktifkan pembatasan termal untuk performa maksimal
cmd thermalservice override-status 0
cmd power set-adaptive-power-saver-enabled false
cmd power set-fixed-performance-mode-enabled true
#V4.0 Infinity X
setprop debug.sf.gpu_freq_indeks 7
settings put global surface_flinger.max_frame_buffer_acquired_buffers 3 
settings put global surface_flinger.use_context_priority true
settings put global surface_flinger.set_touch_timer_ms 0
settings put global surface_flinger.use_content_detection_for_refresh_rate false
settings put global surface_flinger.game_default_frame_rate_override 90
settings put global surface_flinger.enable_frame_rate_override false
#New
setprop debug.performance.tuning 1
settings put global logcat.live disable
settings put global config hw_quickpoweron true
settings put system gsm.lte.ca.support 1
setprop debug.hwui.disable_scissor_opt true
settings put global hwui.texture_cache_size 24
settings put global hwui.texture_cache_flushrate 0.5
settings put global disable_smooth_effect true
setprop debug.composition.type mdp
settings put system sys.composition.type mdp
settings put system gpu_perf_mode 1
#Performa Infinity
settings put system FPSTUNER_SWITCH true
settings put system GPUTUNER_SWITCH true
settings put system CPUTUNER_SWITCH true
settings put system NV_POWERMODE true
setprop debug.gpurend.vsync false
setprop debug.cpurend.vsync false
settings put system hw.accelerated 1
settings put system video.accelerated 1
settings put system game.accelerated 1
settings put system ui.accelerated 1
settings put system enable_hardware_accelerated true
settings put system enable_optimize_refresh_rate true
settings put system lgospd.enable 0
settings put system pcsync.enable 0
settings put system dalvik.hyperthreading true
settings put system dalvik.multithread true
# Rendering and UI Optimizations
setprop debug.sf.disable_client_composition_cache 1
settings put debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1
settings put system use_16bpp_alpha 1
#MTK Infinity X
# MTK Performance Boosts
settings put global mtk_perf_fast_start_win1
settings put global mtk_perf_response_time 1
settings put global mtk_perf_simple_start_win 1
setprop debug.mediatek.appgamepq_compress 1
setprop debug.mediatek.disp_decompress 1
setprop debug.mtk_tflite.target_nnapi 29
setprop debug.mtk.aee.feature 1
setprop debug.mediatek.performance 1
setprop debug.mediatek.game_pq_enable 1
setprop debug.mediatek.appgamepq 2
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 120
#InfinityX
settings put system user_refresh_rate 120
settings put system min_refresh_rate 120
settings put system peak_refresh_rate 120
settings put system user_refresh_rate infinity
settings get system user_refresh_rate
setprop debug.gfx.early_z 1
setprop debug.hwui.skip_empty_damage true
setprop debug.qctwa.preservebuf 1
setprop debug.qctwa.preservebuf.comp_level 3
setprop debug.qc.hardware 1
setprop debug.qcom.hw_hmp.min_fps -1
setprop debug.qcom.hw_hmp.max_fps -1
setprop debug.qcom.pil.q6_boost q
setprop debug.qcom.render_effect 0
setprop debug.adreno.force_rast 1
setprop debug.adreno.prefer_native_sync 1
setprop debug.adreno.q2d_decompress 1
setprop debug.rs.qcom.use_fast_math 1
setprop debug.rs.qcom.disable_expand 1
setprop debug.sf.hw 1
setprop debug.hwui.shadow.renderer monothic
setprop debug.gfx.driver.1 com.qualcomm.qti.gpudrivers.kona.api30
setprop debug.power_management_mode pref_max
setprop debug.gfx.driver 1
setprop debug.angle.overlay FPS:Vulkan*PipelineCache*
setprop debug.hwui.target_cpu_time_percent 300
setprop debug.hwui.target_gpu_time_percent 300
setprop debug.hwui.use_hint_manager true
setprop debug.multicore.processing 1
setprop debug.fb.rgb565 1
setprop debug.sf.lag_adj 0
setprop debug.sf.showfps 0
setprop debug.hwui.max_frame_time 35.55
setprop debug.sf.disable_backpressure 1
setprop debug.hbm.direct_render_pixmaps 1
setprop debug.hwui.render_compability true
setprop debug.heat_suppression 0
setprop debug.systemuicompilerfilter speed
setprop debug.sensor.hal 0
setprop debug.hwui.render_quality high
setprop debug.sf.gpu_freq_index 7
setprop debug.sf.cpu_freq_index 7
setprop debug.sf.mem_freq_index 7
setprop debug.egl.force_fxaa false
setprop debug.egl.force_taa false
setprop debug.egl.force_msaa false
setprop debug.egl.force_ssaa false
setprop debug.egl.force_smaa false
setprop debug.egl.force_mlaa false
setprop debug.egl.force_txaa false
setprop debug.egl.force_csaa false
setprop debug.hwui.fps_divisor -1
setprop debug.redroid.fps 120
setprop debug.disable_sched_boost true
setprop debug.gpu.cooling.callback_freq_limit false
setprop debug.cpu.cooling.callback_freq_limit false
setprop debug.rs.default-CPU-driver 1
setprop debug.rs.default-CPU-buffer 65536
setprop debug.hwui.use_hint_manager 1
setprop debug.egl.profiler 0
setprop debug.enable.gamed false
setprop debug.qualcomm.sns.daemon 0
setprop debug.qualcomm.sns.libsensor 1
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.disable_hw_vsync true
setprop debug.hwui.disable_vsync true
setprop debug.egl.hw 1
setprop debug.sf.native_mode 1
setprop debug.gralloc.gfx_ubwc_disable 1
setprop debug.video.accelerate.hw 1
#InfinityCmd
cmd looper_stats disable
cmd power set-adaptive-power-saver-enabled false
cmd power set-fixed-performance-mode-enabled true
cmd power set-mode 0
cmd thermalservice override-status 0
dumpsys deviceidle enable
dumpsys deviceidle force-idle
dumpsys deviceidle step deep
) > /dev/null 2>&1

(
setprop debug.hwc.dynThreshold 6.0
setprop debug.sf.frame_rate_multiple_threshold 60
setprop debug.sf.high_fps_early_phase_offset_ns -99999999
setprop debug.sf.high_fps_early_gl_phase_offset_ns -99999999
setprop debug.sf.high_fps_late_app_phase_offset_ns -99999999
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 0
) > /dev/null 2>&1

# Game Booster
cmd device_confg get game_overlay "$app"
cmd thermalservice override-status 0 > /dev/null 2>&1
cmd power set-fixed-performance-mode-enabled 1 > /dev/null 2>&1
cmd power set-adaptive-power-saver-enabled 0 > /dev/null 2>&1
cmd power set-mode 0 > /dev/null 2>&1
cmd shortcut reset-throttling "$app" > /dev/null 2>&1
cmd shortcut reset-all-throttling "$app" > /dev/null 2>&1

# Remove cache and logs
rm -rf /storage/emulated/0/android/data/"$app"/cache > /dev/null 2>&1
rm -rf /data/dalvik-cache/* > /dev/null 2>&1
rm -rf /data/system/usagestats/* > /dev/null 2>&1
rm -rf /data/system/cache/* > /dev/null 2>&1
rm -rf /data/system/log/* > /dev/null 2>&1

# Trim caches
cmd package trim-caches 999G $UUID "$app" > /dev/null 2>&1
pm trim-caches 999G $UUID "$app" > /dev/null 2>&1

# Stop and kill app
cmd activity force-stop --user $USER_ID "$app" > /dev/null 2>&1
cmd activity kill --user $USER_ID "$app" > /dev/null 2>&1
cmd activity stop-app --user $USER_ID "$app" > /dev/null 2>&1
cmd activity kill-all --user $USER_ID "$app" > /dev/null 2>&1
am force-stop --user $USER_ID "$app" > /dev/null 2>&1
am kill --user $USER_ID "$app" > /dev/null 2>&1
am stop-app --user $USER_ID "$app" > /dev/null 2>&1
am kill-all --user $USER_ID "$app" > /dev/null 2>&1

# Sync
sync > /dev/null 2>&1

# Check for errors and run backup tweak if needed
if [[ $? -ne 0 ]]; then
    # Backup Tweak
    cmd thermalservice override-status 0 > /dev/null 2>&1
    cmd power set-fixed-performance-mode-enabled 1 > /dev/null 2>&1
    cmd power set-adaptive-power-saver-enabled 0 > /dev/null 2>&1
    cmd power set-mode 0 > /dev/null 2>&1
    cmd shortcut reset-throttling "$app" > /dev/null 2>&1
    cmd shortcut reset-all-throttling "$app" > /dev/null 2>&1
    
    # Remove cache and logs
    rm -rf /storage/emulated/0/android/data/"$app"/cache > /dev/null 2>&1
    rm -rf /data/dalvik-cache/* > /dev/null 2>&1
    rm -rf /data/system/usagestats/* > /dev/null 2>&1
    rm -rf /data/system/cache/* > /dev/null 2>&1
    rm -rf /data/system/log/* > /dev/null 2>&1

    # Trim caches
    cmd package trim-caches 999G "$app" > /dev/null 2>&1
    pm trim-caches 999G "$app" > /dev/null 2>&1

    # Stop and kill app for backup user
    cmd activity force-stop --user 2000 "$app" > /dev/null 2>&1
    cmd activity kill --user 2000 "$app" > /dev/null 2>&1
    cmd activity stop-app --user 2000 "$app" > /dev/null 2>&1
    cmd activity kill-all --user 2000 "$app" > /dev/null 2>&1
    am force-stop --user 2000 "$app" > /dev/null 2>&1
    am kill --user 2000 "$app" > /dev/null 2>&1
    am stop-app --user 2000 "$app" > /dev/null 2>&1
    am kill-all --user 2000 "$app" > /dev/null 2>&1
fi

pm disable --user 0 com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
dumpsys deviceidle whitelist -com.google.android.gms
pm disable com.google.android.gms/.chimera.GmsIntentOperationService > /dev/null 2>&1