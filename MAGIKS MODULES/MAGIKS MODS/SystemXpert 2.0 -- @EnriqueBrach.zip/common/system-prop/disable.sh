settings delete global updatable_driver_prerelease_opt_in_apps > /dev/null 2>&1

(
setprop debug.egl.force_msaa ""; setprop debug.egl.force_fxaa ""; setprop debug.egl.force_taa ""; setprop debug.cpurend.vsync ""; setprop debug.gpurend.vsync ""; setprop debug.cpuprio ""; setprop debug.gpuprio ""; setprop debug.ioprio ""; setprop debug.hwui.target_cpu_time_percent ""; setprop debug.hwui.target_gpu_time_percent ""; setprop debug.hwui.use_hint_manager ""; setprop debug.renderer.process ""; setprop debug.hwui.disable_draw_defer ""; setprop debug.hwui.disable_draw_reorder ""; setprop debug.qsg_renderer ""; setprop debug.hwui.fps_divisor ""; setprop debug.sf.showfps ""; setprop debug.sf.hw ""; setprop debug.scenegraph.batching_performance ""; setprop debug.sf.disable_client_composition_cache ""; setprop debug.dev.ssrm.turbo ""; setprop debug.dev.disable_sched_boost ""; setprop debug.rs.default-CPU-buffer ""; setprop debug.javafx.animation.fullspeed ""; setprop debug.javafx.animation.framerate ""; setprop debug.composition.type ""; setprop debug.gr.swapinterval ""; setprop debug.fb.rgb565 ""; setprop debug.enabletr ""; setprop debug.systemuicompilerfilter ""; setprop debug.rs.precision ""; setprop debug.disable.hwacc ""; setprop debug.qctwa.preservebuf ""; setprop debug.MB.running ""; setprop debug.MB.inner.running ""; setprop debug.app.performance_restricted ""; setprop debug.rs.max-threads ""; setprop debug.rs.min-threads ""; setprop debug.gr.numframebuffer ""; setprop debug.power_management_mode ""; setprop debug.sf.kernel_idle_timer_update_overlay ""; setprop debug.sf.support_kernel_idle_timer_enabled ""; setprop debug.hwui.multi_renderer.use ""; setprop debug.sf.enable_fb_ubwc ""; setprop debug.hwc.perf_mode ""; setprop debug.hwui.force_async ""; setprop debug.hwui.optimized_texture_upload ""; setprop debug.touchscreen.latency.scale ""
settings delete global activity_manager_constants
settings put system pointer_speed 0
settings delete global max_cached_processes
settings delete global background_settle_time
settings delete global fgservice_min_shown_time
settings delete global fgservice_min_report_time
settings delete global fgservice_screen_on_before_time
settings delete global fgservice_screen_on_after_time
settings delete global content_provider_retain_time
settings delete global gc_timeout
settings delete global full_pss_min_interval
settings delete global full_pss_lowered_interval
settings delete global power_check_interval
settings delete global power_check_max_cpu_1
settings delete global power_check_max_cpu_2
settings delete global power_check_max_cpu_3
settings delete global restricted_device_performance
settings delete global activity_manager_constants
resetprop debug.app.performance_restricted
cmd thermalservice override-status 1

setprop persist.graphics.smooth_mode 0
setprop persist.graphics.performance_boost 0
setprop persist.graphics.low_latency 0

setprop debug.hwui.renderer opengl
setprop debug.hwui.use_vulkan false
setprop debug.sf.enable_hwc_vds false
)> /dev/null 2>&1

(
#SPOFF FAKE DEVICE NON ROOT
settings delete global device_name
settings delete system model 
settings delete global ro.product.model 
settings delete global ro.product.manufacturer
settings delete global ro.vendor.product.cpu.abilist 
settings delete global ro.product.brand
settings delete global ro.product.device 
settings delete global ro.product.manufacturer
settings delete global ro.product.model 
settings delete global product.marketname 
settings delete global ro.soc.vendor Qualcomm
settings delete global ro.product.system_ext.brand 
settings delete global ro.product.system_ext.device 
settings delete global ro.product.system_ext.manufacturer
settings delete global ro.product.system_ext.marketname 
settings delete global ro.product.vendor.cert 
settings delete global ro.product.Aliases
settings delete global ro.build.tf.modelnumber
settings delete global ro.soc.model
settings delete global ro.soc.vendor
settings delete global ro.soc.manufacturer 
settings delete global ro.soc.model
settings delete global ro.product.cpu.abi
settings delete global ro.product.cpu.abilist
settings delete global ro.product.cpu.name 
settings delete global ro.hardware.chipname 
settings delete global ro.vendor.qti.chip_name
) > /dev/null 2>&1

#magiks Vexiro 
#Conserving or optimizing battery usage on devices, such as 
#smartphones or tablets, to make them last longer between 
#charges

pm enable com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm enable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
dumpsys deviceidle whitelist -com.google.android.gms
pm disable com.google.android.gms/.chimera.GmsIntentOperationService > /dev/null 2>&1
settings delete global activity_starts_logging_enabled
settings delete global ble_scan_always_enabled
settings delete global hotword_detection_enabled
settings delete global mobile_data_always_on
settings delete global network_recommendations_enabled
settings delete global wifi_scan_always_enabled
settings delete secure adaptive_sleep
settings delete secure screensaver_activate_on_dock
settings delete secure screensaver_activate_on_sleep
settings delete secure screensaver_enabled
settings delete secure send_action_app_error
settings delete system air_motion_engine
settings delete system air_motion_wake_up
settings delete system intelligent_sleep_mode
settings delete system master_motion
settings delete system motion_engine
settings delete system nearby_scanning_enabled
settings delete system nearby_scanning_permission_allowed
settings delete system rakuten_denwa
settings delete system send_security_reports
settings delete global cached_apps_freezer
settings delete global sem_enhanced_cpu_responsiveness
settings delete global enhanced_processing
settings delete global app_standby_enabled
settings delete global adaptive_battery_management_enabled
settings delete global app_restriction_enabled
settings delete system intelligent_sleep_mode
settings delete secure adaptive_sleep
settings delete global automatic_power_save_mode
settings delete global low_power
settings delete global dynamic_power_savings_enabled
settings delete global dynamic_power_savings_disable_threshold
settings delete system master_motion
settings delete system motion_engine
settings delete system air_motion_engine
settings delete system air_motion_wake_up
settings delete system intelligent_sleep_mode
settings delete secure adaptive_sleep
settings delete secure wake_locks_enabled
settings delete secure location_scanning_interval
settings delete global wifi_sleep_policy
settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete secure doze_always_on
settings delete secure alarm_manager_constants
# Uninstall for Activity Manager Constants
settings delete global activity_manager_constants

# Uninstall for Power Management Constants
settings delete global memory_constants

# Uninstall for App Optimization
settings delete global app_process_constants

# Uninstall for Doze Mode
settings delete global doze_constants

# Uninstall for Vibration Settings
settings delete global vibration_constants

# Uninstall for Job Scheduler & Alarm Settings
settings delete global job_scheduler_constants

# Uninstall for Network Management
settings delete global network_management_constants

# Uninstall for Binder Calls Stats
settings delete global binder_calls_stats

# Uninstall for Foreground Service
settings delete global fg_service_constants

# Uninstall for Backup
settings delete secure backup_manager_constants

# Uninstall for Battery Manager
settings delete global battery_manager_constants

# Uninstall for Miscellaneous
settings delete global appop_history_parameters
settings delete global autofill_compat_mode_allowed_packages
settings delete global location_ignore_settings_package_whitelist

# Uninstall for Gaming Performance
settings delete global cpu_gpu_constants
settings delete global dynamic_frequency_scaling_constants
settings delete global gaming_memory_constants
settings delete global gaming_power_constants
pm enable --user 0 com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm enable --user 0 com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm enable com.google.android.gms/.chimera.GmsIntentOperationService > /dev/null 2>&1
settings delete global activity_starts_logging_enabled
settings delete global ble_scan_always_enabled
settings delete global hotword_detection_enabled
settings delete global mobile_data_always_on
settings put global network_recommendations_enabled
settings delete global wifi_scan_always_enabled
settings delete secure adaptive_sleep
settings delete secure screensaver_activate_on_dock
settings delete secure screensaver_activate_on_sleep
settings delete secure screensaver_enabled
settings delete secure send_action_app_error
settings delete system air_motion_engine
settings delete system air_motion_wake_up
settings delete system intelligent_sleep_mode
settings delete system master_motion
settings delete system motion_engine
settings delete system nearby_scanning_enabled
settings delete system nearby_scanning_permission_allowed
settings delete system rakuten_denwa
settings delete system send_security_reports
settings delete global cached_apps_freezer
settings delete global sem_enhanced_cpu_responsiveness
settings delete global enhanced_processing
settings delete global app_standby_enabled
settings delete global adaptive_battery_management_enabled
settings delete global app_restriction_enabled
settings delete system intelligent_sleep_mode
settings delete secure adaptive_sleep
settings delete global automatic_power_save_mode
settings delete global low_power
settings delete global dynamic_power_savings_enabled
settings delete global dynamic_power_savings_disable_threshold
settings delete system master_motion
settings delete system motion_engine
settings delete system air_motion_engine
settings delete system air_motion_wake_up
settings delete system intelligent_sleep_mode
settings delete secure adaptive_sleep
settings delete secure wake_locks_enabled
settings delete secure location_scanning_interval
settings delete global wifi_sleep_policy
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0
settings delete secure doze_always_on
settings delete secure alarm_manager_constants
setprop debug.sv.disable.pers.cache false
setprop debug.sv.config.disable_rtt false
setprop debug.sv.config.stats 1
setprop debug.sv.log.slow_query_threshold 100
setprop debug.sv.atrace.tags.enableflags true
setprop debug.sv.egl.profiler 1
setprop debug.sv.enable.gamed true
setprop debug.sv.enable.wl_log true
setprop debug.sv.hwc.otf 1
setprop debug.sv.hwc_dump_en 1
setprop debug.sv.mdpcomp.logs 1
setprop debug.sv.qualcomm.sns.daemon 1
setprop debug.sv.qualcomm.sns.libsensor1 1
setprop debug.sf.ddms 1
setprop debug.sf.disable_client_composition_cache 0
setprop debug.sf.dump 1
setprop debug.sv.sqlite.journalmode WAL
setprop debug.sv.test 1
setprop debug.sv.libc.debug.malloc 1
setprop debug.sv.log.shaders 1
setprop debug.sv.log.tag.all 1
setprop debug.sv.log.tag.stats_log 1
setprop debug.sv.log_ao 1
setprop debug.sv.log_frame_info 1
setprop debug.sv.logd.logpersistd.enable true
setprop debug.sv.logd.statistics 1
setprop debug.sv.media.metrics.enabled true
setprop debug.sv.media.metrics 1
setprop debug.sv.media.stagefright.log-uri 1
setprop debug.sv.net.ipv4.tcp_no_metrics_save 0
setprop debug.sv.anr.dumpthr 1
setprop debug.sv.persist.camera.debug.logfile 1
setprop debug.sv.camera.iface.logs 1
setprop debug.sv.camera.imglib.logs 1
setprop debug.sv.camera.isp.debug 1
setprop debug.sv.camera.mct.debug 1
setprop debug.sv.camera.sensor.debug 1
setprop debug.sv.data.qmi.adb_logmask 0xFFFFFFFF
setprop debug.sv.sensors.hal 1
setprop debug.sv.wfd.enable true
setprop debug.sv.disable_inline_rotator false
setprop debug.sv.disable_skip_validate false
setprop debug.sv.miui.ndcd true
setprop debug.sv.wifitracing.started 1
setprop debug.sv.fm.a2dp.conc.disabled false
setprop debug.sv.vendor.vidc.debug.level 1
setprop debug.sv.vendor.vidc.enc.disable_bframes false
setprop debug.sv.vidc.debug.level 1
setprop debug.sv.video.disable.ubwc false
cmd thermalservice override-status 1 > /dev/null 2>&1
cmd power set-fixed-performance-mode-enabled 0 > /dev/null 2>&1
cmd power set-adaptive-power-saver-enabled 1 > /dev/null 2>&1
cmd power set-mode 0
settings delete global low_power
setprop persist.sys.bg_daemon_enable true
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0
pm enable-user --user 0 com.google.android.location.fused
pm enable-user --user 0 com.google.android.gms.location.history
pm enable-user --user 0 com.google.android.location.fused
pm enable-user --user 0 com.google.android.gms.location.history
settings put system POWER_PERFORMANCE_MODE_OPEN 0
cmd power set -fixed-performance-mode-enabled 0
cmd power set -adaptive-power-saver-enabled 1
cmd power set -mode 0
settings delete system POWER_PERFORMANCE_MODE_OPEN
settings delete system POWER_BALANCED_MODE_OPEN
settings delete system POWER_SAVE_MODE_OPEN

(
#Fps Injector 
setprop debug.graphics.game_default_frame_rate ""
setprop debug.graphics.game_default_frame_rate.disabled ""
setprop persist.sys.gpu_perf_mode ""
setprop debug.mtk.powerhal.hint.bypass ""
setprop persist.sys.surfaceflinger.idle_reduce_framerate_enable ""
setprop sys.surfaceflinger.idle_reduce_framerate_enable ""
setprop debug.sf.perf_mode ""
settings put global refresh.active ""
setprop debug.hwui.disable_vsync ""
setprop debug.performance.profile ""
setprop debug.perf.tuning ""
setprop debug.hwc.dynThreshold ""
setprop debug.sf.frame_rate_multiple_threshold ""
setprop debug.sf.high_fps_early_phase_offset_ns ""
setprop debug.sf.high_fps_early_gl_phase_offset_ns ""
setprop debug.sf.high_fps_late_app_phase_offset_ns ""
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold ""
#Unlock Performance Mode
cmd power set-fixed-performance-mode-enabled false
cmd power set-adaptive-power-saver-enabled true

# Reset Game
device_config delete game_overlay com.netease.newspike
device_config delete game_overlay com.miHoYo.GenshinImpact
device_config delete game_overlay com.garena.game.codm
device_config delete game_overlay com.riotgames.league.wildrift
device_config delete game_overlay com.mobile.legends
device_config delete game_overlay com.tencent.ig
device_config delete game_overlay com.mobile.legends.hwag
device_config delete game_overlay com.mobile.legends.mi
device_config delete game_overlay com.garena.game.df
device_config delete game_overlay com.tencent.tmgp.sgame
device_config delete game_overlay com.roblox.client
device_config delete game_overlay com.dts.freefireth
device_config delete game_overlay com.dts.freefiremax
device_config delete game_overlay com.garena.game.kgvn


#Reset Modes
cmd game mode standard com.netease.newspike
cmd game mode standard com.miHoYo.GenshinImpact
cmd game mode standard com.garena.game.codm
cmd game mode standard com.riotgames.league.wildrift
cmd game mode standard com.mobile.legends
cmd game mode standard com.tencent.ig
cmd game mode standard com.mobile.legends.hwag
cmd game mode standard com.mobile.legends.mi
cmd game mode standard com.garena.game.df
cmd game mode standard com.tencent.tmgp.sgame
cmd game mode standard com.roblox.client  
cmd game mode standard com.dts.freefireth
cmd game mode standard com.dts.freefiremax
cmd game mode standard com.garena.game.kgvn 
cmd game mode balance com.netease.newspike
cmd game mode balance com.miHoYo.GenshinImpact
cmd game mode balance com.garena.game.codm
cmd game mode balance com.riotgames.league.wildrift
cmd game mode balance com.mobile.legends
cmd game mode balance com.tencent.ig
cmd game mode balance com.mobile.legends.hwag
cmd game mode balance com.mobile.legends.mi
cmd game mode balance com.garena.game.df
cmd game mode balance com.tencent.tmgp.sgame
cmd game mode balance com.roblox.client  
cmd game mode balance com.dts.freefireth
cmd game mode balance com.dts.freefiremax
cmd game mode balance com.garena.game.kgvn 
cmd game mode reset com.netease.newspike
cmd game mode reset com.miHoYo.GenshinImpact
cmd game mode reset com.garena.game.codm
cmd game mode reset com.riotgames.league.wildrift
cmd game mode reset com.mobile.legends
cmd game mode reset com.tencent.ig
cmd game mode reset com.mobile.legends.hwag
cmd game mode reset com.mobile.legends.mi
cmd game mode reset com.garena.game.df
cmd game mode reset com.tencent.tmgp.sgame
cmd game mode reset com.roblox.client  
cmd game mode reset com.dts.freefireth
cmd game mode reset com.dts.freefiremax
cmd game mode reset com.garena.game.kgvn 
) > /dev/null 2>&1 &

(
settings delete global touch.pressure.scale
settings delete global touch.size.scale
settings put global transition_animation_scale 1.0
settings put global window_animation_scale 1.0
settings delete global settings_enable_monitor_phantom_procs
settings put system pointer_speed 0
settings delete global surface_flinger.set_idle_timer_ms
settings delete global surface_flinger.set_touch_timer_ms
settings delete global surface_flinger.set_display_power_timer_ms
setprop debug.sf.latch_unsignaled ""
setprop debug.sf.disable_backpressure ""
setprop debug.sf.multithreaded_present ""
settings delete global surface_flinger.use_context_priority
settings delete global activity_manager_constants
settings delete global memory_constants
settings delete global memory_constants
settings delete global app_process_constants
settings delete global doze_constants
settings delete global vibration_constants
settings delete global job_scheduler_constants
settings delete global network_management_constants
settings delete global binder_calls_stats
settings delete global fg_service_constants
settings delete secure backup_manager_constants
settings delete global battery_manager_constants
settings put global appop_history_parameters
settings delete global autofill_compat_mode_allowed_packages
settings delete global location_ignore_settings_package_whitelist
settings delete global cpu_gpu_constants
settings delete global dynamic_frequency_scaling_constants
settings delete global gaming_memory_constants
settings delete global gaming_power_constants
) > /dev/null 2>&1

(
#V19
settings delete system touch_sampling_rate
settings delete system touch_size_calibration
settings delete system touch_stats
settings delete system touchX_debuggable
settings delete system touch_boost_threshold
settings delete system touch_feature_gamemode_enable
settings delete system touch_input_sensitivity
settings delete system touch_rate_control
settings delete system touch_response_rate
settings delete system touch_sampling_rate_override
settings delete system touch_sensitivity
settings delete system touch_slop
settings delete system touch_switch_set_touchscreen
settings delete system touch_tap_sensitivity
settings delete system touchpanel_game_switch_enable
) > /dev/null 2>&1

(
#V18
settings delete global surface_flinger.start_graphics_allocator_service
settings delete global surface_flinger.running_without_sync_framework
setprop debug.sf.luma_sampling ""
setprop debug.sf.disable_client_composition_cache ""
setprop debug.sf.disable_backpressure ""
setprop debug.sf.enable_gl_backpressure ""
setprop debug.sf.enable_layer_caching ""
setprop debug.sf.disable_client_composition_cache ""
setprop debug.sf.enable_gl_backpressure ""
setprop debug.sf.enable_hwc_vds ""
setprop debug.sf.hw ""
setprop debug.sf.predict_hwc_composition_strategy ""
setprop debug.sf.use_phase_offsets_as_durations ""
#V17SCREEN.TOUCH
setprop debug.sf.use_phase_offsets_as_durations ""
setprop debug.sf.late.sf.duration ""
setprop debug.sf.late.app.duration ""
setprop debug.sf.treat_170m_as_sRGB ""
setprop debug.sf.earlyGl.app.duration ""
setprop debug.sf.frame_rate_multiple_threshold ""
setprop debug.boot.fps ""
#V16 Faster Touch 
setprop debug.performance.tuning ""
settings delete system view.scroll_friction
settings delete global windowsmgr.support_low_latency_touch
setprop debug.hwui.render_dirty_regions ""
setprop debug.hwui.disable_vsync ""
settings delete system haptic_feedback_intensity
settings delete global tactile_feedback_enabled
setprop debug.sf.set_touch_timer_ms ""
###
setprop debug.MultitouchSettleInterval ""
setprop debyg.MultitouchMinDistance ""
setprop debug.TapInterval ""
settings delete global fw.bservice_enable
settings delete global fw.bg_apps_limit
settings delete global fw.bservice_limit
settings delete global fw.bservice_age
setprop debug.touch.pressure.scale ""
setprop debug.touch_move_opt ""
setprop debug.touch_vsync_opt ""
setprop debug.touch.size.bias ""
setprop debug.TapSlop1px
settings delete global windowsmgr.max_events_per_sec
settings delete global min_pointer_dur
settings delete global product.multi_touch_enabled
settings delete global securestorage.knox
setprop debug.security.mdpp ""
setprop debug.security.mdpp.result ""
settings delete system af.resampler.quality
settings delete system scrollingcache
setprop debug.service.lgospd.enable ""
setprop debug.service.pcsync.enable ""
setprop debug.touch.deviceTypetouchScreen
cmd device_config delete input default_key_press_repeat_rate
cmd device_config delete input filtered_accel_event_rate_hz
cmd device_config delete input touch_screen_sample_interval_ms
cmd device_config delete systemui cg_frame_interval_millis
cmd device_config delete systemui low_power_refresh_rate_millis
cmd device_config delete systemui low_power_refresh_rate_millis
cmd device_config delete systemui cg_max_frame_skip
settings delete system service.touch.tpf
settings delete system lowThreshold
settings delete system highThreshold
settings delete system VirtualKeyQuietTime
settings delete system KeyRepeatDelay
settings delete system KeyRepeatTimeout
setprop debug.boosterorientnosync ""
settings delete global sf.disable_smooth_effect
settings delete secure touch_distance_scale
settings delete secure view_scroll_friction
settings delete secure multi_touch_enabled
settings delete secure assist_touch_gesture_enabled
settings delete global maximum_obscuring_opacity_for_touch
settings delete system show_touches
settings delete global block_untrusted_touches
settings delete system vsync.disable.fps.limit
settings delete system table.framerate
setprop debug.touch.deviceType ""
settings delete system disable.hwc.delay
settings delete system Touc_xRotation
settings delete system touchswipedeadzone
settings delete secure long_press_timeout
settings delete secure multi_press_timeout
settings delete secure touch_size_scale
settings delete secure show_rotation_suggestions
settings delete secure touch_size_bias
settings delete secure touch_exploration_enabled
settings delete secure touch_orientationAware
settings delete secure touch_pressure_scale
settings delete system touchscreen_hovering
settings delete system touchscreen_sensitivity_mode
settings delete system touchscreen_pressure_calibration
settings delete system touchscreen_threshold
settings delete system touchfeature.gamemode.enable
settings delete system r.setframepace
settings delete system touch_switch_set_touchscreen
settings delete system touchpanel_game_switch_enable
settings delete system touchpanel_oppo_tp_direction
settings delete system touchpanel_oppo_tp_limit_enable
settings delete system touchpanel_oplus_tp_limit_enable
settings delete system touchpanel_oplus_tp_direction
settings delete system use_dithering
settings delete system use_dithering
settings delete system qti.inputopts.enable
settings delete system qti.inputopts.movetouchslop
settings delete global DragMinSwitchSpeed
settings delete global SwipeMaxWidthRatio
settings delete system MovementSpeedRatio
settings delete system ZoomSpeedRatio
settings delete system SwipeTransitionAngleCosine
settings delete system mot.proximity.distance
settings delete system PointerVelocityControlParameters
settings delete system device.internal
setprop debug.performance.tuning ""
setprop debug.egl.swapinterval ""
settings delete secure dev.pm.dyn_samplingrate
settings delete system touchscreen_sensitivity
settings delete system touchscreen_min_press_time
settings delete system touchscreen_hevoring
settings delete system touchscreen_gesture_mode
settings delete system touchscreen_sensitivity_threshold
settings delete system touchscreen_double_tap_speed
settings delete system touchscreen_sensitivity_scale
settings delete system qti.inputopts.enable
settings delete system qti.inputopts.movetouchslop
settings delete system touch.orientationAware
settings delete system SurfaceOrientation
settings delete system touch.size.calibration
settings delete system touch.size.isSummed
settings delete system touch.orientation.calibration
settings delete system touch.distance.scale
settings delete system touch.coverage.calibration
settings delete system touch.gesturemode
settings delete system MovementSpeedRatio
settings delete system pm.dyn_samplingrate
settings delete system touch.pressure.calibration
settings delete system scroll.accelerated.hw
settings delete system ui.hwframes
settings delete system force_high_end_gfx
settings delete system sf.disable_smooth_effect
settings delete system max_num_touch
settings delete system maxeventspersec
settings delete system resampler.quality
settings delete system touch.sampling
settings delete system adaptive_touch_sensitivity
settings delete system touch.orientationAware
settings delete system PressureForID
settings delete system QuietInterval
settings delete system MultitouchMinDistance
settings delete system AIM_SENSITIVITY_TRANSITION_TIME
settings delete system APP_SWITCH_DELAY_TIME
settings delete system AbsoluteXForID
settings delete system AccelerationX
settings delete system AccelerationY
settings delete system DoubleTouch
settings delete system PowerbuttonTapping
settings delete system touch.assistant.enabled
settings delete system type.touch_speed
settings delete system MovementSpeedRatio
settings delete system accuracy.control
settings delete system view_scroll_friction
settings delete secure multi_press_timeout
settings delete global KeyRepeatDelay
settings delete global KeyRepeatTimeout
settings delete global LOSS_OF_FOCUS_BY_MOUSE_MOVEMENT
settings delete global MOUSEX_AIM_LEVEL
) > /dev/null 2>&1

(
#New Tweak Fps Lock
settings delete system user_refresh_rate
settings delete system fps_limit
settings delete system max_refresh_rate_for_ui
settings delete system hwui_refresh_rate
settings delete system display_refresh_rate
settings delete system max_refresh_rate_for_gaming
#Mengatur margin Fps
settings delete system fstb_target_fps_margin_high_fps
settings delete system fstb_target_fps_margin_low_fps
settings delete system gcc_fps_margin
#remove Refresh rate
settings delete system tran_low_battery_60hz_refresh_rate.support
# Lock refresh rate to 120 Hz
settings delete system vendor.display.refresh_rate
settings delete system user_refresh_rate
settings delete system sf.refresh_rate120
settings delete secure user_refresh_rate
settings delete secure miui_refresh_rate
settings delete system min_frame_rate
settings delete system max_frame_rate
settings delete system tran_refresh_mode
settings delete system last_tran_refresh_mode_in_refresh_setting
settings delete global min_fps
settings delete global max_fps
settings delete system tran_need_recovery_refresh_mode
settings delete system display_min_refresh_rate
settings delete system min_refresh_rate
settings delete system max_refresh_rate
settings delete system peak_refresh_rate
settings delete secure refresh_rate_mode
settings delete system thermal_limit_refresh_rate
settings delete system NV_FPSLIMIT
settings delete system fps.limit.is.now
) > /dev/null 2>&1 &
{
    setprop debug.composition.type ""
    setprop debug.composition.type ""
    setprop debug.hwui.renderer ""
    setprop debug.gr.swapinterval ""
    setprop debug.gr.numframebuffers ""
    setprop debug.egl.buffcount ""
    setprop debug.egl.force_msaa ""
    setprop debug.cpurend.vsync ""
    setprop debug.enabletr ""
    setprop debug.overlayui.enable ""
    setprop debug.egl.hw ""
    setprop debug.gralloc.gfx_ubwc_disable ""
    setprop debug.mdpcomp.logs ""
    setprop debug.egl.hw ""
    setprop debug.egl.profiler ""
    setprop debug.performance.tuning ""
    setprop debug.sf.hw ""
    setprop debug.egl.swapinterval ""
    setprop debug.renderengine.backend ""
    setprop debug.renderengine.backend ""
    setprop debug.angle.overlay ""
    setprop debug.javafx.animation.framerate ""
    setprop debug.systemuicompilerfilter ""
    setprop debug.app.performance_restricted ""
    setprop debug.sf.set_idle_timer_ms ""
    setprop debug.sf.disable_backpressure ""
    setprop debug.sf.latch_unsignaled ""
    setprop debug.sf.enable_hwc_vds ""
    setprop debug.sf.early_phase_offset_ns ""
    setprop debug.sf.early_app_phase_offset_ns ""
    setprop debug.sf.early_gl_phase_offset_ns ""
    setprop debug.sf.early_gl_app_phase_offset_ns ""
    setprop debug.sf.high_fps_early_phase_offset_ns ""
    setprop debug.sf.high_fps_late_sf_phase_offset_ns ""
    setprop debug.sf.high_fps_early_gl_phase_offset_ns ""
    setprop debug.sf.high_fps_late_app_phase_offset_ns ""
    setprop debug.sf.high_fps_late_sf_phase_offset_ns ""
    setprop debug.sf.high_fps_early_gl_phase_offset_ns ""
    setprop debug.sf.phase_offset_threshold_for_next_vsync_ns ""
    setprop debug.sf.showfps ""
    setprop debug.sf.showcpu ""
    setprop debug.sf.showbackground ""
    setprop debug.sf.shoupdates ""
} > /dev/null 2>&1
{
    dumpsys deviceidle unforce
    settings delete global battery_tip_constans
    settings delete global power_check_max_cpu_1
    settings delete global power_check_max_cpu_2
    settings delete global power_check_max_cpu_3
    settings delete global power_check_max_cpu_4
    device_config delete activity_manager_native_boot use_freezer
    settings delete system pointer_speed
    settings delete global cached_apps_freezer
    settings delete system peak_refresh_rate
    settings delete system min_refresh_rate
    settings delete system user_refresh_rate
    settings delete global activity_manager_constants
    cmd thermalservice reset
    cmd power set-fixed-performance-mode-enabled false
} > /dev/null 2>&1
{
        device_config delete game_overlay com.mobile.legends
        cmd game mode standard com.mobile.legends
        cmd package compile -r -f com.mobile.legends
        dumpsys deviceidle unwhitelist +com.mobile.legends
        settings delete global updatable_driver_production_opt_in_apps
        settings delete global game_driver_opt_in_apps
        settings delete global updatable_driver_production_opt_out_apps
        settings delete global updatable_driver_prerelease_opt_in_apps
    } > /dev/null 2>&1
done

(
settings delete global tran_low_battery_60hz_refresh_rate.support
settings delete system surfaceflinger.idle_reduce_framerate_enable
setprop debug.hwui.disable_scissor_opt ""
setprop debug.hwui.texture_cache_flushrate ""
setprop debug.hwui.texture_cache_size ""
setprop debug.hwui.layer_cache_size ""
setprop debug.hwui.r_buffer_cache_size ""
setprop debug.hwui.path_cache_size ""
setprop debug.hwui.gradient_cache_size ""
setprop debug.hwui.drop_shadow_cache_size ""
setprop debug.gr.numframebuffers ""
settings delete global perf.scroll_opt
settings delete global perf.framepacing.enable
settings delete system cpu.freq.boost
setprop debug.PERF_RES_NET_BT_AUDIO_LOW_LATENCY ""
setprop debug.PERF_RES_NET_WIFI_LOW_LATENCY ""
setprop debug.PERF_RES_NET_MD_WEAK_SIG_OPT ""
setprop debug.PERF_RES_NET_NETD_BOOST_UID ""
setprop debug.PERF_RES_NET_MD_HSR_MODE ""
setprop debug.PERF_RES_THERMAL_POLICY ""
#V7.0
settings delete global force_gpu_rendering
settings delete global low_power
settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
#V6.0
# UI & Animation Enhancements
setprop debug.sf.high_fps_early_gl_phase_offset_ns ""
setprop debug.sf.high_fps_early_phase_offset_ns ""
setprop debug.sf.high_fps_late_app_phase_offset_ns ""
setprop debug.sf.high_fps_late_sf_phase_offset_ns ""
settings delete global vendor.dfps.enable
settings delete global vendor.display.default_fps
settings delete global vendor.display.fod_monitor_default_fps
settings delete global vendor.display.idle_default_fps
settings delete global vendor.display.video_or_camera_fps.support
settings delete global vendor.fps.switch.defaul
settings delete global vendor.fps.switch.thermal
settings delete global vendor.display.disable_mitigated_fps
settings delete global vendor.display.enable_dpps_dynamic_fps
#V5.0
# Mematikan fitur yang mengganggu performa
settings delete global auto_sync
settings delete global ble_scan_always_enabled
settings delete global wifi_scan_always_enabled
settings delete global hotword_detection_enabled
settings delete global activity_starts_logging_enabled
settings delete global network_recommendations_enabled
settings delete secure adaptive_sleep
settings delete secure screensaver_enabled
settings delete secure send_action_app_error
settings delete system motion_engine
settings delete system master_motion
settings delete system air_motion_engine
settings delete system air_motion_wake_up
settings delete system send_security_reports
settings delete system intelligent_sleep_mode
settings delete system nearby_scanning_enabled
settings delete system nearby_scanning_permission_allowed
# Menonaktifkan layanan Qualcomm yang tidak diperlukan
pm enable com.qualcomm.qti.cne
pm enable com.qualcomm.location.XT
# Menonaktifkan pembatasan termal untuk performa maksimal
cmd thermalservice reset
cmd power set-adaptive-power-saver-enabled true
cmd power set-fixed-performance-mode-enabled false
#V4.0 Infinity X
setprop debug.sf.gpu_freq_indeks ""
settings delete global surface_flinger.max_frame_buffer_acquired_buffers
settings delete global surface_flinger.use_context_priority
settings delete global surface_flinger.set_touch_timer_ms
settings delete global surface_flinger.use_content_detection_for_refresh_rate
settings delete global surface_flinger.game_default_frame_rate_override
settings delete global surface_flinger.enable_frame_rate_override
#New
setprop debug.performance.tuning ""
settings delete global logcat.live
settings delete global config
setprop debug.hwui.disable_scissor_opt ""
settings delete system gsm.lte.ca.support
settings delete global hwui.texture_cache_size
settings delete global hwui.texture_cache_flushrate
settings delete global disable_smooth_effect
setprop debug.composition.type ""
settings delete system sys.composition.type
settings delete system gpu_perf_mode
#Performa Infinity
settings delete system FPSTUNER_SWITCH
settings delete system GPUTUNER_SWITCH
settings delete system CPUTUNER_SWITCH
settings delete system NV_POWERMODE
setprop debug.gpurend.vsync ""
setprop debug.cpurend.vsync ""
settings delete system hw.accelerated
settings delete system video.accelerated
settings delete system game.accelerated
settings delete system ui.accelerated
settings delete system enable_hardware_accelerated
settings delete system enable_optimize_refresh_rate
settings delete system lgospd.enable
settings delete system pcsync.enable
settings delete system dalvik.hyperthreading
settings delete system dalvik.multithread
# Rendering and UI Optimizations
setprop debug.sf.disable_client_composition_cache ""
settings delete debug.sf.latch_unsignaled
setprop debug.sf.disable_backpressure ""
settings delete system use_16bpp_alpha
#MTK Infinity X
# MTK Performance Boosts
settings delete global mtk_perf_fast_start_win1
settings delete global mtk_perf_response_time
settings delete global mtk_perf_simple_start_win
setprop debug.mediatek.appgamepq_compress ""
setprop debug.mediatek.disp_decompress ""
setprop debug.mtk_tflite.target_nnapi ""
setprop debug.mtk.aee.feature ""
setprop debug.mediatek.performance ""
setprop debug.mediatek.game_pq_enable ""
setprop debug.mediatek.appgamepq ""
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold ""
#InfinityX
settings delete system user_refresh_rate
settings delete system min_refresh_rate
settings delete system peak_refresh_rate
settings delete system user_refresh_rate
settings delete system user_refresh_rate
setprop debug.gfx.early_z ""
setprop debug.hwui.skip_empty_damage ""
setprop debug.qctwa.preservebuf ""
setprop debug.qctwa.preservebuf.comp_level ""
setprop debug.qc.hardware ""
setprop debug.qcom.hw_hmp.min_fps ""
setprop debug.qcom.hw_hmp.max_fps ""
setprop debug.qcom.pil.q6_boost ""
setprop debug.qcom.render_effect ""
setprop debug.adreno.force_rast ""
setprop debug.adreno.prefer_native_sync ""
setprop debug.adreno.q2d_decompress ""
setprop debug.rs.qcom.use_fast_math ""
setprop debug.rs.qcom.disable_expand ""
setprop debug.sf.hw ""
setprop debug.hwui.shadow.renderer ""
setprop debug.gfx.driver.1 ""
setprop debug.power_management_mode ""
setprop debug.gfx.driver ""
setprop debug.angle.overlay ""
setprop debug.hwui.target_cpu_time_percent ""
setprop debug.hwui.target_gpu_time_percent ""
setprop debug.hwui.use_hint_manager ""
setprop debug.multicore.processing ""
setprop debug.fb.rgb565 ""
setprop debug.sf.lag_adj ""
setprop debug.sf.showfps ""
setprop debug.hwui.max_frame_time ""
setprop debug.sf.disable_backpressure ""
setprop debug.hbm.direct_render_pixmaps ""
setprop debug.hwui.render_compability ""
setprop debug.heat_suppression ""
setprop debug.systemuicompilerfilter ""
setprop debug.sensor.hal ""
setprop debug.hwui.render_quality ""
setprop debug.sf.gpu_freq_index ""
setprop debug.sf.cpu_freq_index ""
setprop debug.sf.mem_freq_index ""
setprop debug.egl.force_fxaa ""
setprop debug.egl.force_taa ""
setprop debug.egl.force_msaa ""
setprop debug.egl.force_ssaa ""
setprop debug.egl.force_smaa ""
setprop debug.egl.force_mlaa ""
setprop debug.egl.force_txaa ""
setprop debug.egl.force_csaa ""
setprop debug.hwui.fps_divisor ""
setprop debug.redroid.fps ""
setprop debug.disable_sched_boost ""
setprop debug.gpu.cooling.callback_freq_limit ""
setprop debug.cpu.cooling.callback_freq_limit ""
setprop debug.rs.default-CPU-driver ""
setprop debug.rs.default-CPU-buffer ""
setprop debug.hwui.use_hint_manager ""
setprop debug.egl.profiler ""
setprop debug.enable.gamed ""
setprop debug.qualcomm.sns.daemon ""
setprop debug.qualcomm.sns.libsensor ""
setprop debug.sf.disable_client_composition_cache ""
setprop debug.sf.disable_client_composition_cache ""
setprop debug.sf.disable_hw_vsync ""
setprop debug.hwui.disable_vsync ""
setprop debug.egl.hw ""
setprop debug.sf.native_mode ""
setprop debug.gralloc.gfx_ubwc_disable ""
setprop debug.video.accelerate.hw ""
#InfinityCmd
cmd looper_stats enable
cmd power set-adaptive-power-saver-enabled true
cmd power set-fixed-performance-mode-enabled false
cmd power set-mode 1
cmd thermalservice reset
dumpsys deviceidle disable
dumpsys deviceidle unforce
) > /dev/null 2>&1

(
setprop debug.hwc.dynThreshold ""
setprop debug.sf.frame_rate_multiple_threshold ""
setprop debug.sf.high_fps_early_phase_offset_ns ""
setprop debug.sf.high_fps_early_gl_phase_offset_ns ""
setprop debug.sf.high_fps_late_app_phase_offset_ns ""
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold ""
) > /dev/null 2>&1

# Game Booster
cmd device_config delete game_overlay "$app"
cmd thermalservice reset > /dev/null 2>&1
cmd power set-fixed-performance-mode-enabled 0 > /dev/null 2>&1
cmd power set-adaptive-power-saver-enabled 1 > /dev/null 2>&1
cmd power set-mode 1 > /dev/null 2>&1
cmd shortcut reset-throttling "$app" > /dev/null 2>&1
cmd shortcut reset-all-throttling "$app" > /dev/null 2>&1

# Remove cache and logs
rm -rf /storage/emulated/0/android/data/"$app"/cache > /dev/null 2>&1
rm -rf /data/dalvik-cache/* > /dev/null 2>&1
rm -rf /data/system/usagestats/* > /dev/null 2>&1
rm -rf /data/system/cache/* > /dev/null 2>&1
rm -rf /data/system/log/* > /dev/null 2>&1

# Trim caches
cmd package trim-caches 0 $UUID "$app" > /dev/null 2>&1
pm trim-caches 0 $UUID "$app" > /dev/null 2>&1

# Stop and kill app
cmd activity force-stop --user $USER_ID "$app" > /dev/null 2>&1
cmd activity kill --user $USER_ID "$app" > /dev/null 2>&1
cmd activity stop-app --user $USER_ID "$app" > /dev/null 2>&1
cmd activity kill-all --user $USER_ID "$app" > /dev/null 2>&1
am force-stop --user $USER_ID "$app" > /dev/null 2>&1
am kill --user $USER_ID "$app" > /dev/null 2>&1
am stop-app --user $USER_ID "$app" > /dev/null 2>&1
am kill-all --user $USER_ID "$app" > /dev/null 2>&1

# Sync
sync > /dev/null 2>&1

# Check for errors and run backup tweak if needed
if [[ $? -ne 0 ]]; then
    # Backup Tweak
    cmd thermalservice reset > /dev/null 2>&1
    cmd power set-fixed-performance-mode-enabled 0 > /dev/null 2>&1
    cmd power set-adaptive-power-saver-enabled 1 > /dev/null 2>&1
    cmd power set-mode 1 > /dev/null 2>&1
    cmd shortcut reset-throttling "$app" > /dev/null 2>&1
    cmd shortcut reset-all-throttling "$app" > /dev/null 2>&1
    
    # Remove cache and logs
    rm -rf /storage/emulated/0/android/data/"$app"/cache > /dev/null 2>&1
    rm -rf /data/dalvik-cache/* > /dev/null 2>&1
    rm -rf /data/system/usagestats/* > /dev/null 2>&1
    rm -rf /data/system/cache/* > /dev/null 2>&1
    rm -rf /data/system/log/* > /dev/null 2>&1

    # Trim caches
    cmd package trim-caches 0 "$app" > /dev/null 2>&1
    pm trim-caches 0 "$app" > /dev/null 2>&1

    # Stop and kill app for backup user
    cmd activity force-stop --user 2000 "$app" > /dev/null 2>&1
    cmd activity kill --user 2000 "$app" > /dev/null 2>&1
    cmd activity stop-app --user 2000 "$app" > /dev/null 2>&1
    cmd activity kill-all --user 2000 "$app" > /dev/null 2>&1
    am force-stop --user 2000 "$app" > /dev/null 2>&1
    am kill --user 2000 "$app" > /dev/null 2>&1
    am stop-app --user 2000 "$app" > /dev/null 2>&1
    am kill-all --user 2000 "$app" > /dev/null 2>&1
fi

pm enable com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm enable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
dumpsys deviceidle whitelist -com.google.android.gms
pm disable com.google.android.gms/.chimera.GmsIntentOperationService > /dev/null 2>&1