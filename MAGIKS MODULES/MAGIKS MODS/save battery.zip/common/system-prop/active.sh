#magiks Vexiro 
#Conserving or optimizing battery usage on devices, such as 
#smartphones or tablets, to make them last longer between 
#charges

pm disable --user 0 com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
dumpsys deviceidle whitelist -com.google.android.gms
pm disable com.google.android.gms/.chimera.GmsIntentOperationService > /dev/null 2>&1
settings put global activity_starts_logging_enabled 0
settings put global ble_scan_always_enabled 0
settings put global hotword_detection_enabled 0
settings put global mobile_data_always_on 0
settings put global network_recommendations_enabled 0
settings put global wifi_scan_always_enabled 0
settings put secure adaptive_sleep 0
settings put secure screensaver_activate_on_dock 0
settings put secure screensaver_activate_on_sleep 0
settings put secure screensaver_enabled 0
settings put secure send_action_app_error 0
settings put system air_motion_engine 0
settings put system air_motion_wake_up 0
settings put system intelligent_sleep_mode 0
settings put system master_motion 0
settings put system motion_engine 0
settings put system nearby_scanning_enabled 0
settings put system nearby_scanning_permission_allowed 0
settings put system rakuten_denwa 0
settings put system send_security_reports 0
settings put global cached_apps_freezer disabled
settings put global sem_enhanced_cpu_responsiveness 0
settings put global enhanced_processing 0
settings put global app_standby_enabled 0
settings put global adaptive_battery_management_enabled 0
settings put global app_restriction_enabled true
settings put system intelligent_sleep_mode 0
settings put secure adaptive_sleep 0
settings put global automatic_power_save_mode 0
settings put global low_power 0
settings put global dynamic_power_savings_enabled 0
settings put global dynamic_power_savings_disable_threshold 20
settings put system master_motion 0
settings put system motion_engine 0
settings put system air_motion_engine 0
settings put system air_motion_wake_up 0
settings put system intelligent_sleep_mode 0
settings put secure adaptive_sleep 0
settings put secure wake_locks_enabled 0
settings put secure location_scanning_interval 1800000
settings put global wifi_sleep_policy 2
settings put global window_animation_scale 0.85
settings put global transition_animation_scale 0.85
settings put global animator_duration_scale 0.85
settings put secure doze_always_on 1
settings put secure alarm_manager_constants 1
setprop debug.sv.disable.pers.cache true
setprop debug.sv.config.disable_rtt true
setprop debug.sv.config.stats 0
setprop debug.sv.log.slow_query_threshold 0
setprop debug.sv.atrace.tags.enableflags false
setprop debug.sv.egl.profiler 0
setprop debug.sv.enable.gamed false
setprop debug.sv.enable.wl_log false
setprop debug.sv.hwc.otf 0
setprop debug.sv.hwc_dump_en 0
setprop debug.sv.mdpcomp.logs 0
setprop debug.sv.qualcomm.sns.daemon 0
setprop debug.sv.qualcomm.sns.libsensor1 0
setprop debug.sf.ddms 0
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.dump 0
setprop debug.sv.sqlite.journalmode false
setprop debug.sv.test 0
setprop debug.sv.libc.debug.malloc 0
setprop debug.sv.log.shaders 0
setprop debug.sv.log.tag.all 0
setprop debug.sv.log.tag.stats_log 0
setprop debug.sv.log_ao 0
setprop debug.sv.log_frame_info 0
setprop debug.sv.logd.logpersistd.enable false
setprop debug.sv.logd.statistics 0
setprop debug.sv.media.metrics.enabled false
setprop debug.sv.media.metrics 0
setprop debug.sv.media.stagefright.log-uri 0
setprop debug.sv.net.ipv4.tcp_no_metrics_save 1
setprop debug.sv.anr.dumpthr 0
setprop debug.sv.persist.camera.debug.logfile 0
setprop debug.sv.camera.iface.logs 0
setprop debug.sv.camera.imglib.logs 0
setprop debug.sv.camera.isp.debug 0
setprop debug.sv.camera.mct.debug 0
setprop debug.sv.camera.sensor.debug 0
setprop debug.sv.data.qmi.adb_logmask 0
setprop debug.sv.sensors.hal 0
setprop debug.sv.wfd.enable false
setprop debug.sv.disable_inline_rotator true
setprop debug.sv.disable_skip_validate true
setprop debug.sv.miui.ndcd false
setprop debug.sv.wifitracing.started 0
setprop debug.sv.fm.a2dp.conc.disabled true
setprop debug.sv.vendor.vidc.debug.level 0
setprop debug.sv.vendor.vidc.enc.disable_bframes true
setprop debug.sv.vidc.debug.level 0
setprop debug.sv.video.disable.ubwc true
# Activity Manager Constants
settings put global activity_manager_constants "max_cached_processes=512,background_settle_time=1000,fgservice_min_shown_time=2000,fgservice_min_report_time=2000,fgservice_screen_on_before_time=2000,fgservice_screen_on_after_time=2000,content_provider_retain_time=5000,gc_timeout=10000,gc_min_interval=5000,full_pss_min_interval=10000,full_pss_lowered_interval=20000,power_check_interval=10000,power_check_max_cpu_1=60,power_check_max_cpu_2=70,power_check_max_cpu_3=80,power_check_max_cpu_4=90,service_usage_interaction_time=5000,usage_stats_interaction_interval=30000,service_restart_duration=5000,service_reset_run_duration=60000,service_min_restart_time_between=5000,service_max_inactivity=60000,service_bg_start_timeout=5000,CUR_MAX_CACHED_PROCESSES=10,CUR_MAX_EMPTY_PROCESSES=5,CUR_TRIM_EMPTY_PROCESSES=5,CUR_TRIM_CACHED_PROCESSES=5,service_min_restart_interval=2000,service_max_restart_count=3,service_memory_threshold=102400,bg_service_max_retries=1,fg_service_max_retries=2,process_lifetime=30000,service_expiry_time=60000,proc_start_timeout=2000,proc_bind_timeout=2000,proc_launch_time=3000,heavy_weight_proc_min_adjacency=500,service_restart_duration_factor=2,proc_state_cached_interval=60000,proc_state_bg_interval=120000,min_crash_interval=120000,trim_level_mod=0,service_max_runtime=300000,cpu_usage_collect_interval=60000,memory_usage_collect_interval=60000"

# Power Management Constants
settings put global memory_constants "low_memory_threshold=192000,high_memory_threshold=384000"
settings put global memory_constants "low_memory_threshold=128000,high_memory_threshold=256000"

# App Optimization
settings put global app_process_constants "bg_start_timeout=3000,fg_start_timeout=1000,app_process_max=1024"

# Doze Mode
settings put global doze_constants "doze_after_screen_off_time=300000,doze_max_idle_time=86400000"

# Vibration Settings
settings put global vibration_constants "min_vibration_time=5,max_vibration_time=100"

# Job Scheduler & Alarm Settings
settings put global job_scheduler_constants "max_job_count_active=50,max_session_count_active=50,rate_limiting_window_ms=20000"

# Network Management
settings put global network_management_constants "max_net_retries=1,net_reconnect_timeout=2000"

# Binder Calls Stats
settings put global binder_calls_stats "latency_observer_sharding_modulo=5"

# Foreground Service
settings put global fg_service_constants "fg_service_max_start_time=5000,fg_service_timeout=15000"

# Backup
settings put secure backup_manager_constants "key_value_backup_interval_milliseconds=600000"

# Battery Manager
settings put global battery_manager_constants "max_battery_saver_timeout=300"

# Miscellaneous
settings put global appop_history_parameters "mode=HISTORICAL_MODE_ENABLED,baseIntervalMillis=5000,intervalMultiplier=5"
settings put global autofill_compat_mode_allowed_packages "com.android.chrome[url_bar]:com.brave.browser[url_bar]:com.opera.browser[url_field]:com.opera.mini.native[url_bar]"
settings put global location_ignore_settings_package_whitelist "com.google.android.gms,com.google.android.dialer"

# Gaming Performance
settings put global cpu_gpu_constants "cpu_boost_threshold=50,gpu_boost_threshold=50,cpu_max_freq=1400000,gpu_max_freq=300000000,cpu_min_freq=300000,gpu_min_freq=200000000,cpu_affinity=0,1,2,3,gpu_affinity=0,1"
settings put global dynamic_frequency_scaling_constants "cpu_scaling_max=1400000,gpu_scaling_max=300000000,cpu_scaling_min=300000,gpu_scaling_min=200000000,cpu_interactive_target_load=75,gpu_interactive_target_load=75"
settings put global gaming_memory_constants "gaming_memory_alloc_size=2048,gaming_memory_optimize=true,memory_gc_threshold=100000,memory_swap_enable=true,large_cache_threshold=250000,low_memory_threshold_game=128000"
settings put global gaming_power_constants "gaming_performance_mode=false,max_cpu_performance=70,max_gpu_performance=75,cpu_power_saving_mode=true,gpu_power_saving_mode=true,disable_background_services=true,aggressive_power_saving_mode=true"

# Disable GMS packages
pm disable --user 0 com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable --user 0 com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm disable com.google.android.gms/.chimera.GmsIntentOperationService > /dev/null 2>&1

# Feature Flags (Disable)
settings put global activity_starts_logging_enabled 0
settings put global ble_scan_always_enabled 0
settings put global hotword_detection_enabled 0
settings put global mobile_data_always_on 0
settings put global network_recommendations_enabled 0
settings put global wifi_scan_always_enabled 0
settings put secure adaptive_sleep 0
settings put secure screensaver_activate_on_dock 0
settings put secure screensaver_activate_on_sleep 0
settings put secure screensaver_enabled 0
settings put secure send_action_app_error 0
settings put system air_motion_engine 0
settings put system air_motion_wake_up 0
settings put system intelligent_sleep_mode 0
settings put system master_motion 0
settings put system motion_engine 0
settings put system nearby_scanning_enabled 0
settings put system nearby_scanning_permission_allowed 0
settings put system rakuten_denwa 0
settings put system send_security_reports 0

# Background Processing & App Standby
settings put global cached_apps_freezer disabled
settings put global sem_enhanced_cpu_responsiveness 0
settings put global enhanced_processing 0
settings put global app_standby_enabled 0
settings put global adaptive_battery_management_enabled 0
settings put global app_restriction_enabled true

# Power Saving (Redundant/Consolidated)
settings put global automatic_power_save_mode 0
settings put global low_power 1 # Set low power mode
settings put global dynamic_power_savings_enabled 0
settings put global dynamic_power_savings_disable_threshold 20
settings put secure wake_locks_enabled 0
settings put secure location_scanning_interval 1800000
settings put global wifi_sleep_policy 2

# Animation Scales
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# Doze (Redundant/Consolidated)
settings put secure doze_always_on 1

# Alarm Manager
settings put secure alarm_manager_constants 1

# System Properties
setprop debug.sv.disable.pers.cache true
setprop debug.sv.config.disable_rtt true
setprop debug.sv.config.stats 0
setprop debug.sv.log.slow_query_threshold 0
setprop debug.sv.atrace.tags.enableflags false
setprop debug.sv.egl.profiler 0
setprop debug.sv.enable.gamed false
setprop debug.sv.enable.wl_log false
setprop debug.sv.hwc.otf 0
setprop debug.sv.hwc_dump_en 0
setprop debug.sv.mdpcomp.logs 0
setprop debug.sv.qualcomm.sns.daemon 0
setprop debug.sv.qualcomm.sns.libsensor1 0
setprop debug.sf.ddms 0
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.dump 0
setprop debug.sv.sqlite.journalmode false
setprop debug.sv.test 0
setprop debug.sv.libc.debug.malloc 0
setprop debug.sv.log.shaders 0
setprop debug.sv.log.tag.all 0
setprop debug.sv.log.tag.stats_log 0
setprop debug.sv.log_ao 0
setprop debug.sv.log_frame_info 0
setprop debug.sv.logd.logpersistd.enable false
setprop debug.sv.logd.statistics 0
setprop debug.sv.media.metrics.enabled false
setprop debug.sv.media.metrics 0
setprop debug.sv.media.stagefright.log-uri 0
setprop debug.sv.net.ipv4.tcp_no_metrics_save 1
setprop debug.sv.anr.dumpthr 0
setprop debug.sv.persist.camera.debug.logfile 0
setprop debug.sv.camera.iface.logs 0
setprop debug.sv.camera.imglib.logs 0
setprop debug.sv.camera.isp.debug 0
setprop debug.sv.camera.mct.debug 0
setprop debug.sv.camera.sensor.debug 0
setprop debug.sv.data.qmi.adb_logmask 0
setprop debug.sv.sensors.hal 0
setprop debug.sv.wfd.enable false
setprop debug.sv.disable_inline_rotator true
setprop debug.sv.disable_skip_validate true
setprop debug.sv.miui.ndcd false
setprop debug.sv.wifitracing.started 0
setprop debug.sv.fm.a2dp.conc.disabled true
setprop debug.sv.vendor.vidc.debug.level 0
setprop debug.sv.vendor.vidc.enc.disable_bframes true
setprop debug.sv.vidc.debug.level 0
setprop debug.sv.video.disable.ubwc true
setprop persist.sys.bg_daemon_enable false

# Thermal & Power Management Commands
cmd thermalservice override-status 0 > /dev/null 2>&1
cmd power set-fixed-performance-mode-enabled 0 > /dev/null 2>&1
cmd power set-adaptive-power-saver-enabled 1 > /dev/null 2>&1 # Enable adaptive power saver
cmd power set-mode 1 # Set to power save mode

# Location Services (Disable)
pm disable-user --user 0 com.google.android.location.fused
pm disable-user --user 0 com.google.android.gms.location.history

# Power Performance Modes (Redundant/Consolidated)
settings put system POWER_PERFORMANCE_MODE_OPEN 0
settings put system POWER_BALANCED_MODE_OPEN 1
settings put system POWER_SAVE_MODE_OPEN 1