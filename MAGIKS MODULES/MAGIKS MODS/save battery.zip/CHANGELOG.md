# Changelog

Conserving or optimizing battery usage on devices, such as 
smartphones or tablets, to make them last longer between 
charges