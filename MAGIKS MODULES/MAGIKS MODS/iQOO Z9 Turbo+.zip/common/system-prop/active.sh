(
# SPOOF FAKE DEVICE NON ROOT - iQOO Z9 Turbo+ (Global 24117RK2CC)
settings put global device_name "iQOO Z9 Turbo+"
settings put system model "iQOO Z9 Turbo+"
settings put global ro.product.model "iQOO Z9 Turbo+"
settings put global ro.product.manufacturer POCO
settings put global ro.vendor.product.cpu.abilist arm64-v8a
settings put global ro.product.brand POCO
settings put global ro.product.device 24117RK2CC
settings put global ro.product.manufacturer POCO
settings put global ro.product.model 24117RK2CC
settings put global product.marketname "iQOO Z9 Turbo+"
settings put global ro.soc.vendor Qualcomm
settings put global ro.product.system_ext.brand POCO 
settings put global ro.product.system_ext.device 24117RK2CC
settings put global ro.product.system_ext.manufacturer POCO
settings put global ro.product.system_ext.marketname "iQOO Z9 Turbo+"
settings put global ro.product.vendor.cert "iQOO Z9 Turbo+"
settings put global ro.product.Aliases 24117RK2CC
settings put global ro.build.tf.modelnumber 24117RK2CC
settings put global ro.soc.model SM8750
settings put global ro.soc.vendor Qualcomm
settings put global ro.soc.manufacturer "Qualcomm Technologies, Inc."
settings put global ro.soc.model "Snapdragon 8 Gen 4"
settings put global ro.product.cpu.abi "arm64-v8a"
settings put global ro.product.cpu.abilist "arm64-v8a,armeabi-v7a,armeabi"
settings put global ro.product.cpu.name "Snapdragon™ 8 Gen 4"
settings put global ro.hardware.chipname "Snapdragon™ 8 Gen 4"
settings put global ro.vendor.qti.chip_name SM8750-AB
) > /dev/null 2>&1